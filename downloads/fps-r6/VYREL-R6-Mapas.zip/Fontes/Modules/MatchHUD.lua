local Players=game:GetService("Players") local Run=game:GetService("RunService") local Input=game:GetService("UserInputService")
local system=game:GetService("ReplicatedStorage"):WaitForChild("FPSSystem")
local U={} local cleanupPrevious
function U.init()
 if cleanupPrevious then cleanupPrevious() end
 local player=Players.LocalPlayer local pg=player:WaitForChild("PlayerGui") local links={} local alive=true
 local gui=Instance.new("ScreenGui") gui.Name="FPSMatchHUD" gui.IgnoreGuiInset=true gui.ResetOnSpawn=false gui.DisplayOrder=18 gui.Parent=pg
 local function connect(event,fn) table.insert(links,event:Connect(fn)) end
 local function frame(parent,name,size,pos,alpha)
  local f=Instance.new("Frame") f.Name=name f.Size=size f.Position=pos f.BackgroundColor3=Color3.fromRGB(24,26,33) f.BackgroundTransparency=alpha or .3 f.BorderSizePixel=0 f.Parent=parent return f
 end
 local function text(parent,name,value,size,pos,fontSize)
  local t=Instance.new("TextLabel") t.Name=name t.Text=value t.Size=size t.Position=pos t.BackgroundTransparency=1 t.TextColor3=Color3.fromRGB(255,255,255) t.Font=Enum.Font.GothamBold t.TextSize=fontSize t.TextStrokeTransparency=.6 t.TextStrokeColor3=Color3.fromRGB(0,0,0) t.TextXAlignment=Enum.TextXAlignment.Left t.Parent=parent return t
 end
 local function round(f,r) local c=Instance.new("UICorner") c.CornerRadius=UDim.new(0,r) c.Parent=f end
 local compact=Input.TouchEnabled or workspace.CurrentCamera and workspace.CurrentCamera.ViewportSize and workspace.CurrentCamera.ViewportSize.X<1000
 local timer=frame(gui,"RoundClock",UDim2.fromOffset(86,42),UDim2.new(.5,-43,0,8),.22) round(timer,6)
 local clock=text(timer,"Time","4:00",UDim2.fromScale(1,1),UDim2.fromScale(0,0),26) clock.TextXAlignment=Enum.TextXAlignment.Center
 local ranking=frame(gui,"Ranking",UDim2.fromOffset(500,94),UDim2.new(.5,-250,0,58),1)
 local tasks=frame(gui,"Tasks",UDim2.fromOffset(compact and 180 or 260,190),UDim2.new(0,16,.35,0),1)
 local heading=text(tasks,"Heading","Objetivos [0/3]",UDim2.new(1,0,0,30),UDim2.fromOffset(0,0),compact and 14 or 19)
 local rows={}
 for i,d in ipairs({{"Equipe uma arma",1,25},{"Elimine alvos",5,75},{"Conclua uma rodada",1,50}}) do
  local row=frame(tasks,"Task"..i,UDim2.new(1,0,0,43),UDim2.fromOffset(0,31+(i-1)*46),1)
  text(row,"Title","> "..d[1],UDim2.new(1,-48,0,20),UDim2.fromOffset(0,0),compact and 10 or 13)
  local track=frame(row,"Track",UDim2.new(1,-60,0,3),UDim2.fromOffset(14,24),.4)
  local fill=frame(track,"Fill",UDim2.fromScale(0,1),UDim2.fromScale(0,0),0) fill.BackgroundColor3=Color3.fromRGB(111,255,45)
  local count=text(row,"Count","0 / "..d[2],UDim2.fromOffset(66,15),UDim2.new(1,-110,0,28),10)
  local reward=text(row,"Reward","+"..d[3].." XP",UDim2.fromOffset(58,20),UDim2.new(1,-58,0,6),compact and 10 or 12) reward.TextColor3=Color3.fromRGB(255,222,54)
  rows[i]={fill=fill,count=count,target=d[2]}
 end
 local xp=text(tasks,"XP","XP da sessao: 0",UDim2.new(1,0,0,18),UDim2.fromOffset(14,174),10)
 local feed=frame(gui,"KillFeed",UDim2.fromOffset(compact and 210 or 360,94),UDim2.new(1,compact and -220 or -372,0,10),1)
 local board=frame(gui,"Scoreboard",UDim2.new(.7,0,.6,0),UDim2.new(.15,0,.2,0),.08) round(board,8) board.Visible=false
 text(board,"Title","PLACAR DA RODADA",UDim2.new(1,-32,0,38),UDim2.fromOffset(16,10),20)
 local boardRows=frame(board,"Players",UDim2.new(1,-32,1,-64),UDim2.fromOffset(16,58),1)
 local settings=frame(gui,"Settings",UDim2.fromOffset(300,190),UDim2.new(.5,-150,.5,-95),.05) round(settings,8) settings.Visible=false
 text(settings,"Title","AJUSTES",UDim2.new(1,-32,0,30),UDim2.fromOffset(16,10),20)
 local function button(y,fn)
  local b=Instance.new("TextButton") b.Size=UDim2.fromOffset(268,34) b.Position=UDim2.fromOffset(16,y) b.BackgroundColor3=Color3.fromRGB(48,52,63) b.TextColor3=Color3.fromRGB(255,255,255) b.Font=Enum.Font.GothamBold b.TextSize=12 b.Parent=settings round(b,4) connect(b.Activated,function() fn(b) end) return b
 end
 local vfx=button(54,function(b) player:SetAttribute("FPSVFXEnabled",player:GetAttribute("FPSVFXEnabled")==false) b.Text="EFEITOS: "..(player:GetAttribute("FPSVFXEnabled")==false and "DESLIGADOS" or "LIGADOS") end) vfx.Text="EFEITOS: "..(player:GetAttribute("FPSVFXEnabled")==false and "DESLIGADOS" or "LIGADOS")
 local fov=button(96,function(b) player:SetAttribute("FPSRunFOV",player:GetAttribute("FPSRunFOV")==false) b.Text="FOV NA CORRIDA: "..(player:GetAttribute("FPSRunFOV")==false and "DESLIGADO" or "LIGADO") end) fov.Text="FOV NA CORRIDA: "..(player:GetAttribute("FPSRunFOV")==false and "DESLIGADO" or "LIGADO")
 local close=button(138,function() settings.Visible=false end) close.Text="FECHAR" close.Modal=true
 local function menu(value)
  settings.Visible=value player:SetAttribute("FPSMenuOpen",value) Input.MouseIconEnabled=value
 end
 connect(close.Activated,function() menu(false) end)
 if compact then
  local menus=frame(gui,"Menus",UDim2.fromOffset(150,28),UDim2.new(0,16,.29,0),1)
  for i,d in ipairs({{"PLACAR",function() board.Visible=not board.Visible end},{"AJUSTES",function() menu(not settings.Visible) end}}) do
   local b=Instance.new("TextButton") b.Text=d[1] b.Size=UDim2.fromOffset(70,26) b.Position=UDim2.fromOffset((i-1)*76,0) b.BackgroundTransparency=.4 b.BackgroundColor3=Color3.fromRGB(24,26,33) b.TextColor3=Color3.fromRGB(255,255,255) b.Font=Enum.Font.GothamBold b.TextSize=10 b.Parent=menus connect(b.Activated,d[2])
  end
 end
 connect(Input.InputBegan,function(i,processed)
  if processed or Input:GetFocusedTextBox() or player:GetAttribute("FPSGameMenu")==true then return end
  if i.KeyCode==Enum.KeyCode.Tab then board.Visible=true elseif i.KeyCode==Enum.KeyCode.V then tasks.Visible=not tasks.Visible elseif i.KeyCode==Enum.KeyCode.M then menu(not settings.Visible) end
 end)
 connect(Input.InputEnded,function(i) if i.KeyCode==Enum.KeyCode.Tab then board.Visible=false end end)
 local messages={} local thumbs={} local signature="" local accumulated=1
 local function sorted()
  local list={} for _,p in ipairs(Players:GetPlayers()) do if p:GetAttribute("FPSMatchId")==player:GetAttribute("FPSMatchId") then table.insert(list,p) end end
  table.sort(list,function(a,b) local x,y=a:GetAttribute("FPSRoundKills") or 0,b:GetAttribute("FPSRoundKills") or 0 if x==y then return a.UserId<b.UserId end return x>y end)
  return list
 end
 local function refresh()
  if not alive then return end
  local left=math.max(0,math.ceil((player:GetAttribute("FPSMatchEnd") and player:GetAttribute("FPSMatchEnd")>0 and player:GetAttribute("FPSMatchEnd") or system:GetAttribute("FPSRoundEnd") or workspace:GetServerTimeNow())-workspace:GetServerTimeNow()))
  clock.Text=player:GetAttribute("FPSMode")=="Training" and "TREINO" or string.format("%d:%02d",math.floor(left/60),left%60) clock.TextSize=player:GetAttribute("FPSMode")=="Training" and 16 or 26
  local progress={player:GetAttribute("FPSHasEquipped") and 1 or 0,player:GetAttribute("FPSKills") or 0,player:GetAttribute("FPSRounds") or 0} local done=0
  for i,row in ipairs(rows) do local n=math.min(progress[i],row.target) row.count.Text=n.." / "..row.target row.fill.Size=UDim2.fromScale(n/row.target,1) if n>=row.target then done+=1 end end
  heading.Text="Objetivos ["..done.."/3]" xp.Text="XP da sessao: "..(player:GetAttribute("FPSXP") or 0)
  local list=sorted() local ids={} for _,p in ipairs(list) do table.insert(ids,p.UserId..":"..(p:GetAttribute("FPSRoundKills") or 0)) end
  local key=table.concat(ids,",")
  if key~=signature then
   signature=key ranking:ClearAllChildren() boardRows:ClearAllChildren()
   local max=compact and 5 or 10 local width=compact and 40 or 56 local gap=compact and 6 or 10 local count=math.min(max,#list)
   ranking.Size=UDim2.fromOffset(count*(width+gap),94) ranking.Position=UDim2.new(.5,-count*(width+gap)/2,0,58)
   for i,p in ipairs(list) do
    if i<=max then
     local card=frame(ranking,"Rank"..i,UDim2.fromOffset(width,64),UDim2.fromOffset((i-1)*(width+gap),15),0) card.BackgroundColor3=i==1 and Color3.fromRGB(119,82,21) or Color3.fromRGB(91,40,149) round(card,9)
     local rank=text(card,"Rank","#"..i,UDim2.new(1,0,0,20),UDim2.fromOffset(0,-20),16) rank.TextXAlignment=Enum.TextXAlignment.Center
     local initial=text(card,"Initial",string.sub(p.DisplayName or p.Name,1,1),UDim2.fromScale(1,1),UDim2.fromScale(0,0),24) initial.TextXAlignment=Enum.TextXAlignment.Center
     local pic=Instance.new("ImageLabel") pic.Name="Avatar" pic.Size=UDim2.fromScale(1,1) pic.BackgroundTransparency=1 pic.Parent=card
     if thumbs[p.UserId] then pic.Image=thumbs[p.UserId] initial.Visible=false else
      task.spawn(function() local ok,url=pcall(function() return Players:GetUserThumbnailAsync(p.UserId,Enum.ThumbnailType.HeadShot,Enum.ThumbnailSize.Size100x100) end) if ok then thumbs[p.UserId]=url if alive and pic.Parent then pic.Image=url initial.Visible=false end end end)
     end
     local score=text(card,"Score",tostring(p:GetAttribute("FPSRoundKills") or 0),UDim2.new(1,0,0,32),UDim2.fromOffset(0,48),compact and 24 or 32) score.TextXAlignment=Enum.TextXAlignment.Center score.ZIndex=3
    end
    if i<=12 then text(boardRows,"Player"..i,string.format("%d.  %s    %d",i,p.DisplayName or p.Name,p:GetAttribute("FPSRoundKills") or 0),UDim2.new(1,0,0,26),UDim2.fromOffset(0,(i-1)*28),16) end
   end
  end
  for i=#messages,1,-1 do if workspace:GetServerTimeNow()-messages[i].at>5 then messages[i].frame:Destroy() table.remove(messages,i) end end
  for i,m in ipairs(messages) do m.frame.Position=UDim2.fromOffset(0,(i-1)*29) end
 end
 connect(system.Remotes:WaitForChild("MatchFeed").OnClientEvent,function(attacker,victim,critical,arena)
  if arena and arena~=player:GetAttribute("FPSMatchId") then return end
  if type(attacker)~="string" or type(victim)~="string" then return end
  local row=frame(feed,"Elimination",UDim2.new(1,0,0,25),UDim2.fromOffset(0,0),.18) round(row,4)
  local label=text(row,"Names",attacker.."   [VETOR] "..(critical and "* " or "")..victim,UDim2.new(1,-12,1,0),UDim2.fromOffset(6,0),compact and 10 or 13) label.TextTruncate=Enum.TextTruncate.AtEnd
  table.insert(messages,1,{frame=row,at=workspace:GetServerTimeNow()}) if #messages>3 then messages[#messages].frame:Destroy() table.remove(messages) end refresh()
 end)
 connect(Run.Heartbeat,function(dt) accumulated+=dt if accumulated>=.25 then accumulated=0 refresh() end end)
 refresh()
 local function cleanup() alive=false player:SetAttribute("FPSMenuOpen",false) for _,c in ipairs(links) do c:Disconnect() end gui:Destroy() end
 cleanupPrevious=cleanup return cleanup
end
return U
