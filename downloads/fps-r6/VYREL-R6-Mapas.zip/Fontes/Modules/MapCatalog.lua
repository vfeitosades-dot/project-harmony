-- Original environments inspired by architectural and FPS layout research.
return {
 Order={"SOLARA","GLACIER","HOSHIMA"},
 Maps={
  SOLARA={Name="SOLARA",Theme="TEMPLO / JARDINS",Tagline="A memoria da pedra. O calor do confronto.",Description="Arcos de arenito, patios ajardinados e rotas laterais entre ruinas.",Color={232,180,103},Materials="Arenito / tijolo / madeira / vegetacao"},
  GLACIER={Name="GLACIER",Theme="PORTO / POLAR",Tagline="Aco frio. Decisoes rapidas.",Description="Conteineres de carga, neve e uma plataforma industrial com duas rotas de flanco.",Color={114,214,246},Materials="Neve / metal / chapa / gelo"},
  HOSHIMA={Name="HOSHIMA",Theme="DISTRITO / NEON",Tagline="A cidade nunca deixa de observar.",Description="Mercado noturno, fachadas iluminadas e vielas conectadas a uma praca central.",Color={224,120,228},Materials="Asfalto / tijolo / madeira / vidro"}
 }
}
