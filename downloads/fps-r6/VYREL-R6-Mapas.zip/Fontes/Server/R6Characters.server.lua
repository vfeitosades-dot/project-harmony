local Players=game:GetService("Players")
local Physics=game:GetService("PhysicsService")
local System=game:GetService("ReplicatedStorage").FPSSystem
local C=require(System.Modules.WeaponConfig)
local Avatar=require(System.Modules.AvatarAppearance) local World=require(System.Modules.WorldService)
local spawning={} local bound={}
local function spawn(p)
 if not p.Parent or spawning[p] then return end spawning[p]=true
 local id=p.UserId
 -- Clientes locais do Studio usam IDs negativos. O criador e uma referencia opcional.
 if id<=0 and game.CreatorType==Enum.CreatorType.User and game.CreatorId>0 then id=game.CreatorId end
 local model,err=Avatar.Create(id)
 if not p.Parent then if model then model:Destroy() end Avatar.Clear(id) spawning[p]=nil return end
 if not model then spawning[p]=nil warn("[R6] Avatar indisponivel: "..tostring(err)) task.delay(3,function() spawn(p) end) return end
 local old=p.Character model.Name=p.Name
 local root=model:FindFirstChild("HumanoidRootPart") local h=model:FindFirstChildOfClass("Humanoid")
 if not root or not h then model:Destroy() spawning[p]=nil return end
 model.PrimaryPart=root h.DisplayName=p.DisplayName h.WalkSpeed=p:GetAttribute("FPSMode")=="Lobby" and 0 or C.WalkSpeed h.UseJumpPower=true h.JumpPower=50
 for _,v in ipairs(model:GetDescendants()) do if v:IsA("BasePart") then v.CollisionGroup="Characters" if v.Parent and v.Parent:IsA("Accessory") then v.CanQuery=false end end end
 model.Parent=workspace
 if not World.Place(p,model,true) then model:Destroy() spawning[p]=nil task.delay(.5,function() if p.Parent then spawn(p) end end) return end
 p.Character=model
 if old then old:Destroy() end spawning[p]=nil
 h.Died:Connect(function() task.delay(3,function() if p.Parent and p.Character==model then spawn(p) end end) end)
 if model:GetAttribute("AppearanceFallback") then warn("[R6] Aparencia neutra temporaria; nao foi possivel carregar a conta "..id) end
end
pcall(function() Physics:RegisterCollisionGroup("Characters") end)
pcall(function() Physics:RegisterCollisionGroup("FPSViewModel") end)
Physics:CollisionGroupSetCollidable("Characters","Characters",false)
Physics:CollisionGroupSetCollidable("FPSViewModel","Characters",false)
Physics:CollisionGroupSetCollidable("FPSViewModel","Default",false)
Physics:CollisionGroupSetCollidable("FPSViewModel","FPSViewModel",false)
Players.CharacterAutoLoads=false
local function add(p) p.CameraMode=Enum.CameraMode.LockFirstPerson p.CameraMinZoomDistance=.5 p.CameraMaxZoomDistance=.5 if bound[p] then return end bound[p]=true task.spawn(spawn,p) end
Players.PlayerAdded:Connect(add)
Players.PlayerRemoving:Connect(function(p) spawning[p]=nil bound[p]=nil Avatar.Clear(p.UserId) end)
for _,p in ipairs(Players:GetPlayers()) do add(p) end

-- Recover from falling or leaving arena bounds; never leave a live player below the map.
local rescueElapsed=0
game:GetService("RunService").Heartbeat:Connect(function(dt)
 rescueElapsed+=dt if rescueElapsed<.5 then return end rescueElapsed=0
 for _,p in ipairs(Players:GetPlayers()) do local model=p.Character local h=model and model:FindFirstChildOfClass("Humanoid")
  if h and h.Health>0 and World.OutOfBounds(p,model) then World.Place(p,model,true) end
 end
end)
