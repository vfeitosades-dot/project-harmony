# Pesquisa visual e de sistemas - VYREL

Referencias consultadas em 03/11/2026; usadas para analise, sem importar artes ou personagens.

- Loja RIVALS: https://robloxrivals.fandom.com/wiki/Shop
  Resultado indexado e imagens de loja: categorias, catalogo, chaves, itens possuidos e desbloqueio. A pagina direta retornou 402.
- Imagem da loja (abas e grade de itens): https://progameguides.com/roblox/roblox-rivals-update-13/
- Economia de chaves / desbloqueios: https://play.google.com/store/apps/editorial?hl=en-US&id=mc_games_editorialevergreen_postinstall_all_about_rivals_in_roblox_gamehub_fcp
- Agentes oficiais VALORANT: https://playvalorant.com/en-us/agents/
- Tipos de habilidades: https://wiki.playvalorant.com/en-us/Abilities
- Referencia do menu enviada pelo usuario: navegacao superior, grande area central e paineis laterais.

VYREL: menu, modelos e habilidades originais. Loja usa creditos de jogo e compra deterministica; nao depende de IDs de produtos pagos. Treino permite experimentar armamento. Sem roupas de personagem impostas ao avatar.

## Mapas e spawns — pesquisa de 04/11/2026

- Riot, The Art of VALORANT Map Environments: https://playvalorant.com/en-us/news/dev/the-art-of-valorant-map-environments/
  Separar rotas jogaveis, arquitetura e acabamento; priorizar leitura dos personagens e desempenho.
- Riot, Deep Dive Into Icebox 4.04 Changes: https://playvalorant.com/en-us/news/game-updates/deep-dive-into-icebox-4-04-changes/
  Referencia visual de neve, carga, guindastes, rotas industriais e clareza de cobertura.
- Riot, galeria de mapas: https://playvalorant.com/en-gb/maps/
  Referencias de patios de templo e ambientes urbanos; imagens de Lotus e Icebox foram pesquisadas.
- Roblox Creator Hub, Greybox your environment: https://create.roblox.com/docs/tutorials/curriculums/environmental-art/greybox-your-environment
  Zonas de spawn opostas, tres rotas principais e conexoes laterais.

Solara, Glacier e Hoshima usam geometrias e nomes proprios. As imagens de referencia nao foram importadas como texturas. O lugar usa materiais e relevos nativos Roblox (arenito, neve, metal, asfalto, tijolo e madeira), sem depender de IDs de imagens ou modelos externos.
