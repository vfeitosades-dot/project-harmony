# VYREL — FPS R6

Abra **VYREL_R6.rbxlx** no Roblox Studio e use Play. Os cenários iniciais já aparecem no editor; os nove modelos também estão disponíveis separadamente no ZIP. Ao iniciar Play, WorldService reconstrói as arenas a partir das fontes e cria os bots. Alterações no mapa devem ser feitas em WorldService, pois a cópia visível no editor é substituída no Play. O avatar mantém sua aparência, convertido para R6, e a câmera fica em primeira pessoa. Não exige importar meshes ou cadastrar IDs de animação.

## Atualização do menu

Correção da inicialização: a linha visual agora se chama `SelectionLine` e é acessada com `FindFirstChild`, sem conflitar com a propriedade booleana nativa `GuiButton.Selected`. O teste reproduziu a falha anterior (`attempt to index boolean with Visible`) e verifica as sete abas com essa propriedade presente.

Cursor liberado durante o menu e restaurado ao jogar; captura modal reduzida a 1 pixel; camadas decorativas sem captura de cliques; botões com entrada explícita. O carregamento opcional do PlayerModule não bloqueia os eventos da GUI. Sincronização sem alterações mantém os botões existentes. Nova tela inicial, prévias 3D nos cards e rolagem em telas pequenas.

## Revisão de spawn, HUD e acabamento

- Entrada protegida nos quatro modos: o personagem permanece ancorado enquanto o cliente confirma o próprio personagem, o token atual e o piso do cenário. A física só é liberada após a validação do servidor. A troca de mapas invalida confirmações antigas. Há retorno ao menu durante o carregamento.
- Posicionamento compensa `HumanoidRootPart.PivotOffset`, evitando alinhar o pivô no lugar da raiz. Colisões de torso/cabeça e do grupo Characters com o chão são normalizadas. A recuperação também detecta personagens presos logo abaixo do piso.
- A câmera de jogo volta sempre a Custom, com CameraSubject no Humanoid e primeira pessoa fixa, em vez de restaurar uma câmera de editor. Avatares mantêm roupa, cores e acessórios; só a física e o rig R6 são tratados.
- HUD inspirado na pesquisa visual de RIVALS: barra verde com animação de vida, munição grande com reserva, quatro slots reais (arma primária, pistola, Q e E), silhuetas do catálogo, ranking com retratos, marcador de headshot e direção do dano. Q/E/C continuam na faixa de habilidades.
- As 12 armas receberam acabamentos, bordas, ferragens e marca própria. Os nove mapas receberam detalhes de acabamento; as lojas de Hoshima têm passagem interna e montanhas/icebergs usam silhuetas angulares.
- Efeitos adicionais: fumaça de disparo, cartucho, poeira por material, indicação de dano, anel de entrada e brilho suave. Efeitos não aplicam força física. A proteção de nascimento termina ao disparar.

O teste `test_spawn_guard.luau` cobre piso atrasado, pivô deslocado, token antigo, os quatro modos, câmera iniciada em Fixed e recuperação sob o chão. Esse teste simula as APIs e não substitui a execução no Studio.

## Expansão a partir das referências

**Agora são 9 mapas.** Foram acrescentados seis cenários:

- **SAHRA:** cidade desértica, casas alaranjadas com portas e interiores, terraços ligados por pontes, escadas e praça com fonte.
- **NEXUS:** arena futurista com plataformas circulares elevadas, passarelas e rampas, torres orbitais e neon azul/violeta.
- **MARINA:** complexo industrial no oceano, galpões atravessáveis, guindastes, passarelas e navio ao fundo.
- **BASTION:** mapa clássico com castelo, studs, ameias, pontes, árvores geométricas e montanhas triangulares.
- **VERANO:** bairro colorido com ruas, carros, árvores, fachadas com entradas, varandas e acesso aos terraços.
- **FREIGHT:** pátio de contêineres coloridos, túneis atravessáveis, nervuras metálicas e caminhos superiores.

A aba **MAPAS** permite consultar os nove cenários e suas prévias 3D. Cada votação oferece **3 candidatos**; o servidor percorre um baralho dos nove mapas e depois embaralha novamente. Só aceita votos nos candidatos daquela rodada. Os mapas anteriores permanecem disponíveis.

`Mapas/*.rbxmx` contém os nove modelos independentes, ancorados e editáveis, sem scripts. Para editar um modelo isolado, insira-o pelo Explorer/Insert from File em um lugar vazio no Studio. A experiência principal reconstrói seus mapas pelas fontes em `WorldService` e `MapArchitecture`; alterar apenas a cópia de um cenário no Workspace não modifica o gerador.

## Mapas anteriores, votação e spawns

- **SOLARA:** templo e jardins, arcos de arenito, palmeiras, pátios e santuário central.
- **GLACIER:** porto polar, contêineres com nervuras, neve, guindastes e plataformas de carga.
- **HOSHIMA:** mercado noturno, lojas com letreiros, lanternas, tijolos, asfalto e neon.
- Geometria própria e materiais nativos texturizados, com iluminação local por tema. As referências de VALORANT/Roblox constam em Referencias.md; não são cópias exatas dos mapas pesquisados.
- Iniciar uma nova sessão de casual ou treino abre votação com três candidatos do catálogo de nove mapas. No ranqueado, os dois humanos votam após o pareamento. Cada pessoa tem um voto e pode mudá-lo. O prazo é de 12 s, reduzido a cerca de 4 s se todos votarem; empates e ausência de votos são resolvidos pelo servidor entre os candidatos empatados. Cancelar a votação ranqueada não perde Elo. Entrar em uma sessão já em andamento mantém o mapa atual. Testar uma arma pela loja abre treino imediatamente.
- Ao terminar a rodada casual, os participantes voltam à votação para escolher a próxima arena. Duelo ranqueado mantém sua arena até o fim, sem bots.
- Casual e ranqueado têm 12 posições por lado, com checagem de piso e espaço livre para o corpo R6. Reservas temporárias reduzem sobreposição; distância, visibilidade dos inimigos e aliados próximos influenciam a escolha. O treino usa posições próprias, próximas aos alvos. Teleporte move o modelo completo, zera velocidade e concede proteção breve. Personagens vivos que caem fora da arena são reposicionados.
- As 12 armas receberam novas proporções e detalhes por família, incluindo madeira, metal escuro, carregadores, miras abertas, lunetas, ferrolhos, bombas e coronhas. Blender e geometria nativa usam o mesmo catálogo.

## Conteúdo

- Menu animado: Início, Jogar, Arsenal, Operadores, Loja e Carreira. Armas em prévia 3D, preços, itens possuídos, compra, equipamento e teste gratuito no treinamento.
- Loja com créditos de jogo, destaque diário com desconto de 20% e compras determinadas pelo servidor. Sem sorteios ou cobrança de Robux. Começa com 500 CR, ION, VETOR C4 e NOMAD P9. Cada outro operador custa 220 CR.
- 12 armas com geometrias próprias: VETOR C4, KESTREL K7, LYRA B9, FERAL S5, PULSAR V2, BASIL A1, ARGO D6, TORQ M8, MAREA P8, RUPTURA D2, VESPER H50 e NOMAD P9. Rifles, SMGs, sniper, DMR, LMG, duas escopetas e duas pistolas. Modelos estilizados com referências de construção reais; não são réplicas oficiais de fabricantes.
- Dano maior na cabeça, cadências e recargas distintas, escopetas com vários projéteis, disparo semiautomático ou automático por arma, reserva de munição e troca entre primária/secundária.
- Pose da arma à direita, apoio da mão esquerda, idle, caminhada, corrida, salto, aterrissagem, recarga, inspeção, recoil, dash e gestos de habilidades. As poses do corpo são aplicadas no servidor para os demais jogadores. A apresentação em primeira pessoa usa braços próprios sem colisões.
- VFX de tiro, impacto, rastros, hitmarker, eliminação, dash e habilidades. Informação privada só é enviada para quem pode recebê-la. Sons próprios ainda não foram fornecidos: o catálogo de áudio fica vazio, sem sons externos obrigatórios.

## Modos

**Casual:** arena PvE cooperativa com rodadas de 5 minutos; 2 bots por pessoa, até 6. Recompensa de 6 CR por eliminação e bônus ao terminar a rodada. Bots usam reação, dispersão, recarga, busca, coberturas, movimentação lateral e linha de visão; não atiram através de paredes ou fumaça.

**Treinamento:** alvos estáticos e móveis; todas as armas podem ser experimentadas sem compra. Não concede créditos ou Elo por eliminar os bots.

**Ranqueado:** duelo entre humanos no mesmo servidor, fila aproximada por Elo, primeiro a 5 eliminações ou 4 minutos. Até três duelos simultâneos. Vitória +24 Elo, derrota -18, empate sem alteração; primeiras 5 partidas são provisórias. Sair ou desconectar durante um duelo conta como derrota. A fila não conecta servidores diferentes e não coloca bots no ranqueado.

## Operadores — mantém a roupa e os acessórios do jogador

**ION / mobilidade:** Q Arco condutor (12 de dano + lentidão leve de 2 s); E Trilho de impulso (+12% de velocidade por 3 s); C Eco residual (distração destrutível de 20 HP, sem dano e sem recompensa de eliminação).

**ÂMBAR / suporte:** Q Película cinética (absorve até 25 de dano, 4 s); E Sutura de campo (2 HP/s por 5 s fora de combate); C Tranca de pulso (cobertura de 40 HP por 4 s).

**VÉU / informação:** Q Farol espectral (revela por 0,8 s dentro da linha de visão); E Neblina fragmentada (4 s de fumaça; balas atravessam); C Escuta direcional (sensor de disparos por 6 s; ping privado e breve).

As nove habilidades têm cooldowns no servidor. Nenhuma concede invulnerabilidade. Balanceamento numérico inicial: precisa de avaliação com jogadores reais.

## Controles

WASD mover • Mouse mirar • Clique disparar • Direito ADS • Shift correr • Ctrl ou F dash • R recarregar • H inspecionar • 1/2 trocar arma • Q/E/C habilidades • B menu • Tab placar • V objetivos • M opções. Há botões de toque para ações principais; adaptação completa para controle ainda não foi validada.

O dash é terrestre, percorre cerca de 8 studs, tem cooldown de 4 s e verifica paredes. Não é uma rasteira. Não permite atirar durante sua janela curta e não concede invulnerabilidade.

## Publicação e salvamento

1. Abra o lugar e teste com **Test > Start Server**, usando pelo menos dois jogadores para conferir replicação, fila e duelo.
2. Publique pelo Studio na sua conta/grupo. Para testar persistência no Studio, habilite **Game Settings > Security > Enable Studio Access to API Services** em uma experiência de teste publicada.
3. O DataStore `VYREL_Profile_v1` guarda créditos, compras, equipamento, operador e Elo. Sem acesso ao DataStore, o menu avisa que o progresso é apenas da sessão. Perfil já em uso fica protegido contra compras concorrentes. Não há produtos ou passes pagos configurados.
4. Ajustes de armas: `WeaponCatalog`; agentes: `AgentCatalog` e `SkillService`; economia: `ProfileService`; modos: `SessionService`; arenas: `WorldService`.

O instalador opcional é destinado a um lugar vazio e para instalação fora do Play. O caminho recomendado é abrir o RBXLX incluído. Não instale duas cópias do sistema no mesmo lugar.

## Fontes, Blender e validação

`Fontes/` contém todos os scripts. `Blender/` inclui o arquivo editável com as 12 armas e seus geradores. O jogo usa a geometria nativa equivalente; os bevels do arquivo Blender não são meshes importados automaticamente. `Previas/` contém renders técnicos, não capturas de execução do Roblox Studio. `Referencias.md` documenta a pesquisa de RIVALS/VALORANT; nomes, habilidades e geometrias deste projeto são originais.

O teste de entrada do menu simula hit testing por camadas e a disputa de cursor com a câmera em primeira pessoa; verifica navegação, compra, treino, retorno ao jogo, atalhos, rolagem por toque e limpeza.

Foram executados testes Luau com serviços e física simulados para tiro, munição, dano, movimento, pose, aparência, GUI, economia, habilidades, bots e ciclo de partida. O RBXLX foi lido e regravado pelo rbxmk, verificando referências e preservação dos 39 scripts. Os scripts finais foram compilados com Luau. Esses testes não substituem a validação no motor Roblox: o Studio não estava disponível neste ambiente. Não há garantia de ausência de bugs ou de balanceamento final.

Validação adicional: testes simulados de votação compartilhada, mudança de voto, mapa inválido, cancelamento, prazo sem votos, aplicação do vencedor, reserva de duelo e spawns nos nove temas. Colisões foram verificadas por consultas simuladas de volume e apoio de piso; a física, o streaming e a navegação dos bots ainda precisam de sessão real no Studio.
