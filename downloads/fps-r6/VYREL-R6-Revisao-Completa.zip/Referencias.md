# Pesquisa visual e de sistemas - VYREL

Referencias consultadas em 03/11/2026; usadas para analise, sem importar artes ou personagens.

- Loja RIVALS: https://robloxrivals.fandom.com/wiki/Shop
  Resultado indexado e imagens de loja: categorias, catalogo, chaves, itens possuidos e desbloqueio. A pagina direta retornou 402.
- Imagem da loja (abas e grade de itens): https://progameguides.com/roblox/roblox-rivals-update-13/
- Economia de chaves / desbloqueios: https://play.google.com/store/apps/editorial?hl=en-US&id=mc_games_editorialevergreen_postinstall_all_about_rivals_in_roblox_gamehub_fcp
- Agentes oficiais VALORANT: https://playvalorant.com/en-us/agents/
- Tipos de habilidades: https://wiki.playvalorant.com/en-us/Abilities
- Referencia do menu enviada pelo usuario: navegacao superior, grande area central e paineis laterais.

VYREL: menu, modelos e habilidades originais. Loja usa creditos de jogo e compra deterministica; nao depende de IDs de produtos pagos. Treino permite experimentar armamento. Sem roupas de personagem impostas ao avatar.

## Mapas e spawns — pesquisa de 04/11/2026

- Riot, The Art of VALORANT Map Environments: https://playvalorant.com/en-us/news/dev/the-art-of-valorant-map-environments/
  Separar rotas jogaveis, arquitetura e acabamento; priorizar leitura dos personagens e desempenho.
- Riot, Deep Dive Into Icebox 4.04 Changes: https://playvalorant.com/en-us/news/game-updates/deep-dive-into-icebox-4-04-changes/
  Referencia visual de neve, carga, guindastes, rotas industriais e clareza de cobertura.
- Riot, galeria de mapas: https://playvalorant.com/en-gb/maps/
  Referencias de patios de templo e ambientes urbanos; imagens de Lotus e Icebox foram pesquisadas.
- Roblox Creator Hub, Greybox your environment: https://create.roblox.com/docs/tutorials/curriculums/environmental-art/greybox-your-environment
  Zonas de spawn opostas, tres rotas principais e conexoes laterais.

Solara, Glacier e Hoshima usam geometrias e nomes proprios. As imagens de referencia nao foram importadas como texturas. O lugar usa materiais e relevos nativos Roblox (arenito, neve, metal, asfalto, tijolo e madeira), sem depender de IDs de imagens ou modelos externos.

## Referencias enviadas pelo usuario — Arsenal, Crossroads e arena neon

- Sandtown / cidade desertica, Roblox Arsenal News: https://x.com/RBX_ArsenalNews/status/1783549030489891190
  Referencia de casas ocres, coberturas, terraços e passagens de madeira, utilizada para SAHRA.
- Portfolio Guga028 / arena futurista: https://devforum.roblox.com/t/closedmap-designer-builder-guga028/888307
  Referencia de plataformas elevadas, torres circulares e neon azul/violeta para NEXUS. A pagina direta apresentou verificacao de JavaScript; foram consideradas a imagem e a descricao enviadas pelo usuario.
- Arsenal / complexo industrial, imagem ilustrativa: https://thenerdstash.com/roblox-arsenal-codes/
  Referencia de linguagem industrial e arena sobre o mar para MARINA. O artigo e sobre codigos; nao foi usado como fonte tecnica do mapa.
- Crossroads classico e remaster: https://devforum.roblox.com/t/crossroads-remastered/14577
  Castelo, terreno verde, studs e arvores geometricas para BASTION.
- Arsenal Community Maps / Midtown: https://devforum.roblox.com/t/arsenal-community-maps/486624
  Fachadas coloridas, carros e arvores para VERANO. A pagina direta exigiu JavaScript; a imagem de Midtown foi consultada na pesquisa visual.
- Arsenal / patio de conteineres, referencia enviada: https://x.com/RBX_ArsenalNews
  Conteineres coloridos, tuneis e passarelas para FREIGHT.

Os seis cenarios novos sao geometrias proprias, construidas com pecas e materiais Roblox. A biblioteca anterior Solara/Glacier/Hoshima foi mantida. Nenhum modelo, textura ou arquivo de jogo desses autores foi baixado ou redistribuido.

## HUD e acabamento da revisão

- RIVALS Ranked, imagem de HUD: https://www.sportskeeda.com/roblox-news/rivals-ranked-guide
- RIVALS treino, vida/munição/objetivos: https://thenerdstash.com/roblox-rivals-top-tips-and-tricks/
- Catálogo e visual de armas: https://www.sportskeeda.com/roblox-news/roblox-rivals-weapons-guide
- Referências de loadout: https://progameguides.com/roblox/best-weapon-loadouts-for-roblox-rivals/

As referências orientam hierarquia visual, barra de vida, leitura de munição, ranking, slots e contraste. A interface e a geometria deste projeto são próprias; os números de dano/munição vêm do catálogo VYREL.
