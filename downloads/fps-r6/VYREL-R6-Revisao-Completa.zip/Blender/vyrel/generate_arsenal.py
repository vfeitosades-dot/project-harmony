from pathlib import Path
import json,math
B=Path(__file__).resolve().parents[1];models={};meta={}
black=[25,29,34];steel=[76,85,94];dark=[36,44,51];rubber=[19,21,24];gold=[184,143,70];wood=[111,60,31];green=[66,79,59];sand=[145,133,102]
for ident,family in [('VETOR','m4'),('KESTREL','ak'),('LYRA','bullpup'),('FERAL','mp5'),('PULSAR','vector'),('BASIL','bolt'),('ARGO','dmr'),('TORQ','lmg'),('MAREA','pump'),('RUPTURA','double'),('VESPER','heavy'),('NOMAD','pistol')]:
 rows=[]
 def p(name,size,pos,color=black,shape='Block',rot=(0,0,0),group='Body',alpha=0):rows.append(dict(name=name,size=list(size),pos=list(pos),color=color,shape=shape,rot=list(rot),group=group,alpha=alpha))
 def tube(name,radius,length,z,y=.29,color=steel,x=0):p(name,(radius,radius,length),(x,y,z),color,'Tube')
 pistol=family in ['pistol','heavy'];internal=family in ['pump','double']
 bodyColor=green if family=='bolt' else sand if family in ['dmr','bullpup'] else black
 if pistol:
  length=1.25 if family=='heavy' else 1.05
  p('Frame',(.4,.25,length),(0,.04,-.35),dark)
  p('Slide',(.43,.27,length),(0,.31,-.38),steel if family=='heavy' else black)
  p('SlideChamfer',(.43,.12,.18),(0,.38,-length*.73),dark,'Wedge')
  p('PistolGrip',(.35,.66,.35),(0,-.34,.13),rubber,rot=(-12,0,0))
  tube('Barrel',.12,.24,-length*.85,.29)
  for side in [-1,1]:
   for z in [-.05,-.13,-.21,-.29]:p('SlideSerration',(.025,.19,.025),(side*.224,.31,z),steel)
   for y in [-.55,-.43,-.31,-.19]:p('GripTexture',(.025,.035,.26),(side*.183,y,.14),dark)
   p('GripPanel',(.022,.44,.23),(side*.19,-.31,.14),dark)
  p('TriggerGuard',(.34,.05,.4),(0,-.17,-.21),dark)
  p('GuardFront',(.34,.18,.05),(0,-.08,-.4),dark)
  p('Trigger',(.05,.14,.045),(0,-.06,-.14),steel,rot=(-12,0,0))
  p('RearSight',(.36,.07,.1),(0,.49,.03),black)
  for x in [-.13,.13]:p('RearPost',(.06,.09,.08),(x,.55,.03),steel)
  p('FrontPost',(.045,.09,.08),(0,.55,-length*.7),gold)
  p('Magazine',(.29,.15,.3),(0,-.65,.14),dark,group='Mag')
  aim=(0,.57,.48);muzzle=(0,.29,-length*.98);left=(-.25,-.18,.05);right=(.04,-.29,.12)
 else:
  l=1.8 if family in ['lmg','bolt','dmr'] else 1.5
  p('LowerReceiver',(.54,.4,l),(0,.18,-.55),bodyColor)
  p('UpperReceiver',(.57,.2,l*.9),(0,.48,-.58),dark)
  p('FrontChamfer',(.54,.16,.23),(0,.4,-.55-l/2),bodyColor,'Wedge')
  p('RearChamfer',(.54,.16,.2),(0,.4,-.55+l/2),bodyColor,'Wedge',(0,180,0))
  handZ=-1.65;handL=.85;barrelZ=-2.35;barrelL=.65
  if family in ['bolt','dmr','pump']:handL=1.15;handZ=-1.8;barrelZ=-2.85;barrelL=1.05
  if family=='lmg':handL=1;barrelZ=-2.8;barrelL=.9
  if family in ['mp5','vector']:handL=.5;handZ=-1.25;barrelZ=-1.85;barrelL=.55
  if family=='double':handL=.8;handZ=-1.7;barrelZ=-2.3;barrelL=1.4
  p('Handguard',(.48,.39,handL),(0,.22,handZ),wood if family=='ak' else bodyColor)
  if family=='double':
   for x in [-.14,.14]:tube('TwinBarrel',.22,barrelL,barrelZ,.3,steel,x)
  else:tube('Barrel',.15,barrelL,barrelZ)
  end=barrelZ-barrelL/2
  if family!='double':
   tube('MuzzleBrake',.25,.23,end-.08,.29,dark)
   tube('MuzzleRing',.28,.055,end-.01,.29,steel)
   for side in [-1,1]:
    for z in [end-.03,end+.04]:p('BrakePort',(.025,.065,.045),(side*.128,.29,z),rubber)
  if family=='ak':
   tube('GasTube',.17,.9,-1.6,.55,dark)
   p('WoodStock',(.41,.48,.82),(0,.14,.81),wood)
   p('StockChamfer',(.41,.22,.26),(0,.37,1.05),wood,'Wedge',(0,180,0))
  elif family=='bullpup':
   p('BullpupStock',(.62,.57,.85),(0,.18,.65),sand)
   p('ThumbHole',(.2,.1,.38),(0,-.17,.2),black)
   p('RearMagazineWell',(.44,.18,.6),(0,-.16,.65),dark)
  elif family=='mp5':
   for x in [-.18,.18]:tube('StockRod',.06,.75,.72,.3,steel,x)
   p('RetractableStock',(.43,.5,.11),(0,.16,1.15),rubber)
   tube('RoundReceiver',.4,1.1,-.5,.42,dark)
  elif family=='vector':
   p('VerticalReceiver',(.52,.7,.55),(0,-.2,-.4),dark)
   p('SkeletonStockTop',(.32,.12,.7),(0,.36,.79),black)
   p('SkeletonStockBottom',(.32,.1,.7),(0,.06,.79),black)
   p('ButtPlate',(.38,.47,.1),(0,.21,1.12),rubber)
  else:
   p('StockTube',(.23,.18,.42),(0,.3,.43),steel)
   p('StockBody',(.38,.36,.62),(0,.2,.83),bodyColor)
   p('StockCheek',(.4,.13,.48),(0,.43,.78),rubber)
   p('ButtPlate',(.44,.59,.11),(0,.13,1.18),rubber)
   for y in [-.04,.08,.2,.32]:p('StockRib',(.45,.025,.12),(0,y,1.2),dark)
  p('PistolGrip',(.33,.58,.35),(0,-.34,.12),wood if family=='ak' else rubber,rot=(-11,0,0))
  for y in [-.5,-.38,-.26]:p('GripRib',(.35,.03,.34),(0,y,.13),dark)
  p('TriggerGuard',(.34,.045,.42),(0,-.2,-.21),steel)
  p('TriggerGuardFront',(.34,.16,.045),(0,-.1,-.41),steel)
  p('Trigger',(.06,.16,.045),(0,-.04,-.12),black,rot=(-15,0,0))
  p('Rail',(.3,.06,1.7),(0,.63,-.65),dark)
  for n in range(12):p('RailTooth',(.33,.04,.07),(0,.68,-1.45+n*.14),steel)
  for side in [-1,1]:
   p('ReceiverPanel',(.025,.22,.96),(side*.28,.23,-.55),dark)
   p('Selector',(.035,.04,.18),(side*.3,.22,.01),steel,rot=(0,0,-15))
   for z in [-.95,-.6,-.2,.08]:p('Pin',(.055,.055,.025),(side*.3,.22,z),steel,'Tube',(0,90,0))
   for n in range(5):p('Vent',(.025,.13,.09),(side*.25,.26,handZ-handL*.36+n*handL*.17),rubber)
  p('EjectionPort',(.035,.14,.36),(.301,.41,-.39),rubber)
  p('BoltHandle',(.18,.07,.09),(.37,.38,-.25),steel)
  if family in ['bolt','dmr']:
   for x in [-.24,.24]:p('ScopeMount',(.09,.2,.28),(x,.78,-.42),black)
   for z in [-.9,-.1]:
    for n in range(8):
     angle=n*math.pi/4;p('ScopeRing',(.16,.055,.12),(math.cos(angle)*.22,1.04+math.sin(angle)*.22,z),black,rot=(0,0,math.degrees(angle)+90))
   for x in [-.21,.21]:p('ScopeTubeRail',(.065,.1,.8),(x,1.04,-.5),dark)
   p('ScopeTopRail',(.22,.05,.8),(0,1.25,-.5),dark)
   p('Reticle',(.014,.014,.014),(0,1.04,-.83),gold)
   aim=(0,1.04,.5)
   if family=='bolt':p('BoltLever',(.3,.06,.06),(.39,.35,.02),steel,rot=(0,0,-25));p('BoltKnob',(.13,.13,.13),(.55,.27,.02),black)
  else:
   p('SightMount',(.4,.08,.33),(0,.76,-.22),black)
   for x in [-.22,.22]:p('ReflexUpright',(.06,.35,.09),(x,.96,-.22),black)
   p('ReflexTop',(.5,.06,.09),(0,1.14,-.22),black)
   p('Reticle',(.014,.014,.014),(0,.96,-.22),gold)
   p('FrontSight',(.06,.13,.08),(0,.77,handZ-.2),steel)
   aim=(0,.96,.52)
  if internal:
   p('Magazine',(.1,.1,.1),(0,-.46,-.65),black,group='Hidden',alpha=1)
   if family=='pump':
    tube('MagazineTube',.2,1.3,-1.9,.05,dark)
    p('Pump',(.5,.3,.6),(0,.08,-1.55),rubber)
    for n in range(7):p('PumpRib',(.53,.035,.03),(0,.25,-1.8+n*.075),dark)
   else:p('HingePin',(.6,.08,.08),(0,.09,-.8),steel);p('BreakLever',(.05,.09,.28),(0,.63,.02),steel)
  elif family=='lmg':
   p('Magazine',(.71,.68,.73),(0,-.47,-.7),green,group='Mag')
   for n in range(8):p('BeltRound',(.09,.08,.15),(-.45-n*.055,.12,-.55),gold)
   for side in [-1,1]:p('Bipod',(.065,.76,.065),(side*.25,-.1,-2.3),steel,rot=(0,0,side*20))
   p('CarryHandle',(.1,.12,.65),(.17,.79,-.65),rubber)
  else:
   magz=.6 if family=='bullpup' else -.6
   p('Magazine',(.37,.62,.49),(0,-.46,magz),dark,group='Mag')
   for side in [-1,1]:
    for y in [-.65,-.48,-.31]:p('MagazineRib',(.035,.035,.43),(side*.2,y,magz),steel,group='Mag')
   if family=='ak':
    for n in range(3):p('CurvedMagazine',(.37,.21,.48),(0,-.7-n*.15,magz-.04-n*.05),dark,rot=(n*5,0,0),group='Mag')
   p('MagazineBase',(.43,.07,.54),(0,-.8,magz),rubber,group='Mag')
  muzzle=(0,.29,end-.2);left=(-.3,-.08,-.95);right=(.05,-.3,.12)

 # Family-specific silhouettes and machined detail. Grip and stock contacts stay compatible with R6.
 def remove(*names):
  rows[:]=[r for r in rows if r['name'] not in names]
 def change(name,**values):
  for r in rows:
   if r['name']==name:r.update(values)
 def ring(name,radius,z,y=.29,width=.045,tint=steel):
  tube(name,radius,width,z,y,tint)
 if not pistol:
  # Dark anodized rail teeth are deliberately subtle rather than bright silver blocks.
  change('RailTooth',size=[.31,.035,.06],color=dark)
  change('ReceiverPanel',size=[.025,.18,.94],color=black)
  change('MagazineRib',color=dark)
  for side in [-1,1]:
   p('ReceiverBevel',(.05,.10,1.10),(side*.266,.53,-.55),black,'Wedge',rot=(0,0,side*90))
   p('DustCover',(.025,.12,.35),(side*.313,.37,-.38),dark)
   p('BoltRelease',(.065,.12,.08),(side*.32,.12,-.14),steel)
   p('GripInset',(.014,.26,.22),(side*.176,-.32,.12),dark)
   for y in [-.40,-.31,-.22]:
    for z in [.03,.12,.21]:p('GripStipple',(.02,.022,.022),(side*.184,y,z),black)
  p('ChargingHandle',(.70,.06,.10),(0,.53,.18),dark)
  p('RearPlate',(.52,.28,.055),(0,.27,.23),steel)
  for side in [-1,1]:
   p('SlingMount',(.06,.18,.14),(side*.25,.18,1.05),steel)
  if family in ['m4','dmr','bullpup']:
   for side in [-1,1]:
    for n in range(6):p('MLOKSlot',(.014,.055,.11),(side*.254,.13,handZ-handL*.4+n*handL*.15),rubber)
   p('GasBlock',(.27,.33,.20),(0,.35,barrelZ+.22),dark)
   ring('BarrelCollar',.21,barrelZ+.08)
  if family=='m4':
   p('StockCutout',(.012,.15,.28),(.199,.22,.83),rubber)
   p('StockCutout',(.012,.15,.28),(-.199,.22,.83),rubber)
   p('MagazineWell',(.46,.18,.60),(0,-.10,-.6),black)
   for side in [-1,1]:p('StockGuide',(.03,.07,.43),(side*.19,.38,.78),steel)
  elif family=='ak':
   remove('RailTooth','ReceiverBevel','RearPlate','ChargingHandle')
   change('LowerReceiver',size=[.47,.34,1.48],color=black)
   change('UpperReceiver',size=[.48,.18,1.34],color=steel)
   change('Handguard',size=[.47,.32,.89],color=wood)
   change('Rail',size=[.26,.04,.46],pos=[0,.64,-.30])
   tube('DustCoverRound',.42,1.20,-.48,.42,black)
   p('GasBlock',(.27,.43,.19),(0,.46,-2.0),dark)
   p('AKChargingHandle',(.24,.065,.14),(.36,.35,-.26),steel)
   for side in [-1,1]:
    for z in [-.88,-.65,-.15,.03]:p('ReceiverRivet',(.025,.045,.045),(side*.25,.27,z),steel)
    for n in range(4):p('WoodGrain',(.012,.018,.66),(side*.242,.12+n*.05,-1.65),[91+n*2,49+n*2,29])
   change('Magazine',size=[.34,.55,.42])
  elif family=='bullpup':
   change('LowerReceiver',size=[.53,.32,1.28],pos=[0,.21,-.42])
   change('UpperReceiver',size=[.53,.19,1.18],pos=[0,.47,-.4])
   change('Handguard',size=[.47,.31,.76])
   p('AngledForegrip',(.29,.30,.31),(0,-.11,-1.23),rubber,'Wedge',rot=(0,180,0))
   for side in [-1,1]:p('AmbiEjectCover',(.03,.15,.32),(side*.32,.35,.68),dark)
  elif family=='mp5':
   change('LowerReceiver',size=[.43,.30,1.16],pos=[0,.14,-.42])
   change('UpperReceiver',size=[.37,.13,1.05])
   change('Handguard',shape='Tube',size=[.48,.48,.74],pos=[0,.24,-1.30])
   change('Magazine',size=[.25,.88,.34],pos=[0,-.59,-.48])
   change('MagazineBase',size=[.30,.06,.39],pos=[0,-1.04,-.48])
   remove('MagazineRib','RailTooth','ReceiverBevel','RearPlate')
   change('Rail',size=[.25,.045,.72],pos=[0,.63,-.34])
   p('CockHandle',(.18,.06,.08),(-.28,.43,-1.02),steel)
   for side in [-1,1]:p('SightEar',(.06,.19,.08),(side*.14,.68,-1.65),black)
   for n in range(5):ring('ForeendRib',.50,-1.55+n*.115,.24,.018,dark)
  elif family=='vector':
   change('LowerReceiver',size=[.48,.30,1.12],pos=[0,.18,-.36])
   change('UpperReceiver',size=[.48,.19,1.12],pos=[0,.48,-.36])
   change('VerticalReceiver',size=[.51,.86,.64],pos=[0,-.23,-.57])
   change('Magazine',size=[.26,.75,.32],pos=[0,-1.02,-.57])
   change('MagazineBase',size=[.31,.07,.37],pos=[0,-1.42,-.57])
   remove('MagazineRib','RearPlate')
   p('RecoilHousing',(.04,.60,.42),(.28,-.23,-.57),steel)
   p('RecoilHousing',(.04,.60,.42),(-.28,-.23,-.57),steel)
   p('ForwardGrip',(.27,.46,.30),(0,-.20,-1.23),rubber)
  elif family in ['bolt','dmr']:
   remove('ReflexUpright','ReflexTop')
   # Open optical tube: circular shell, never a solid cap in the ADS sight line.
   radius=.245 if family=='bolt' else .205
   for n in range(12):
    a=n*math.pi/6
    p('OpticShell',(.13,.04,.93),(math.cos(a)*radius,1.04+math.sin(a)*radius,-.5),black,rot=(0,0,n*30+90))
   for z in [-1.04,-.02]:
    for n in range(12):
     a=n*math.pi/6;p('OpticBell',(.15,.055,.12),(math.cos(a)*(radius+.035),1.04+math.sin(a)*(radius+.035),z),dark,rot=(0,0,n*30+90))
   p('ElevationTurret',(.16,.14,.16),(0,1.39,-.35),steel)
   p('WindageTurret',(.12,.16,.16),(.34,1.06,-.35),steel)
   change('Magazine',size=[.36,.43,.47],pos=[0,-.36,-.6])
   change('MagazineBase',size=[.41,.06,.52],pos=[0,-.6,-.6])
   remove('MagazineRib')
   if family=='bolt':
    change('LowerReceiver',size=[.44,.30,1.8],color=green)
    change('UpperReceiver',size=[.38,.16,1.50])
    change('Handguard',size=[.43,.29,1.16])
    tube('PrecisionBarrel',.18,1.18,-2.8,.29,steel)
    for side in [-1,1]:
     p('BipodLeg',(.06,.65,.06),(side*.23,-.05,-2.2),steel,rot=(0,0,side*15))
     p('BipodFoot',(.17,.05,.19),(side*.31,-.39,-2.2),rubber)
    p('AdjustableComb',(.42,.12,.52),(0,.55,.79),green)
  elif family=='lmg':
   change('UpperReceiver',size=[.62,.24,1.64])
   change('Handguard',size=[.54,.44,1.06])
   for n in range(6):ring('HeatShroud',.28,-2.25+n*.10,.29,.035,dark)
   for n in range(10):p('BeltLink',(.07,.10,.11),(-.43-n*.045,.15,-.55),dark)
   p('FeedCover',(.66,.11,1.05),(0,.60,-.6),black)
  elif family in ['pump','double']:
   remove('LowerReceiver','UpperReceiver','FrontChamfer','RearChamfer','Rail','RailTooth','ReflexUpright','ReflexTop','SightMount','FrontSight','ReceiverPanel','ReceiverBevel','ChargingHandle','RearPlate','DustCover','BoltRelease')
   p('ShotgunReceiver',(.48,.37,.95 if family=='pump' else .63),(0,.26,-.42),black)
   p('BreechBevel',(.48,.12,.30),(0,.47,-.30),dark,'Wedge')
   p('ReceiverTang',(.28,.19,.36),(0,.29,.18),dark)
   change('StockBody',color=wood);change('StockCheek',color=wood)
   change('PistolGrip',color=wood)
   change('Reticle',pos=[0,.59,-.55])
   aim=(0,.59,.52)
   p('RearNotch',(.30,.07,.09),(0,.56,-.05),black)
   p('FrontBead',(.05,.06,.05),(0,.58,end+.14),gold)
   if family=='pump':
    tube('ContinuousBarrel',.21,2.70,-1.975,.29,steel)
    tube('MagazineExtension',.20,1.50,-1.30,.05,dark)
    change('Pump',shape='Tube',size=[.54,.54,.65],color=wood,pos=[0,.11,-1.55])
    change('PumpRib',shape='Tube',size=[.56,.56,.035],color=dark)
    for r in rows:
     if r['name']=='PumpRib':r['pos'][1]=.11
    change('Handguard',size=[.22,.19,.8],color=dark)
   else:
    change('Handguard',size=[.44,.23,.73],color=wood)
    change('TwinBarrel',size=[.22,.22,2.40])
    for r in rows:
     if r['name']=='TwinBarrel':r['pos'][2]=-1.90
    p('BarrelRib',(.12,.06,1.45),(0,.44,-2.3),steel)
    for side in [-1,1]:p('BreechScrew',(.03,.07,.07),(side*.25,.26,-.54),steel)
 else:
  change('SlideSerration',color=dark)
  for side in [-1,1]:
   p('SlideFlat',(.015,.12,.65),(side*.223,.34,-.43),dark)
   p('GripInsert',(.012,.38,.20),(side*.184,-.32,.14),[98,64,44] if family=='heavy' else dark)
   for y in [-.45,-.36,-.27,-.18]:
    for z in [.06,.14,.22]:p('GripStipple',(.014,.02,.02),(side*.194,y,z),black)
   for n in range(3):p('FrontSlideCut',(.016,.14,.028),(side*.226,.32,-.73+n*.065),black,rot=(0,0,12))
  p('Extractor',(.02,.065,.13),(.235,.36,-.25),steel)
  p('SlideStop',(.03,.05,.17),(-.23,.08,-.09),steel)
  p('TakedownPin',(.03,.055,.06),(.23,.07,-.33),dark)
  p('AccessoryRail',(.24,.045,.33),(0,-.10,-.62),dark)
  for n in range(3):p('RailSlot',(.26,.025,.025),(0,-.125,-.75+n*.1),black)
  if family=='heavy':
   change('Slide',size=[.46,.29,1.38],color=[112,120,127])
   p('BarrelHood',(.27,.015,.29),(0,.465,-.21),steel)
   p('BeaverTail',(.28,.09,.14),(0,.07,.24),dark)
 # Engraving accents remain subtle and do not obstruct the sight picture.
 for side in [-1,1]:
  p('SerialPlate',(.008,.06,.24),(side*(.235 if pistol else .324),.25,-.12),steel)


 # Final visual pass: coordinated hardware, machining bevels, inset panels and original maker mark.
 for side in [-1,1]:
  x=side*(.239 if pistol else .327)
  p('MakerMark',(.009,.065,.025),(x,.21,-.22),[173,155,112],rot=(30,0,0))
  p('MakerMark',(.009,.065,.025),(x,.21,-.18),[173,155,112],rot=(-30,0,0))
  p('RecessedPin',(.016,.038,.038),(x,.16,-.06),black)
 if pistol:
  p('SlideBevel',(.38,.035,.85),(0,.468,-.40),dark)
  for side in [-1,1]:p('GripBaseBevel',(.022,.065,.25),(side*.17,-.60,.14),steel,'Wedge',rot=(0,0,side*90))
 else:
  if family not in ['pump','double']:
   for side in [-1,1]:
    p('MachinedEdge',(.035,.065,.82),(side*.275,.51,-.48),dark,'Wedge',rot=(0,0,side*90))
    p('ControlPin',(.025,.065,.065),(side*.322,.29,.01),steel)
  for side in [-1,1]:p('StockFastener',(.018,.048,.048),(side*.205,.22,1.04),steel)

 models[ident]=rows
 meta[ident]={'AimPoint':aim,'Muzzle':muzzle,'LeftGrip':left,'WorldLeftGrip':(-.58,-.08,-.24),'RightGripPoint':right,'MagazinePivot':next(r['pos'] for r in rows if r['name']=='Magazine'),'StockPivot':(0,.13,1.16) if not pistol else (0,0,0)}
def lua(v):
 if isinstance(v,str):return json.dumps(v)
 if isinstance(v,bool):return str(v).lower()
 if isinstance(v,(int,float)):return str(v)
 if isinstance(v,(list,tuple)):return '{'+','.join(lua(x) for x in v)+'}'
 return '{'+','.join('['+lua(k)+']='+lua(x) for k,x in v.items())+'}'
(B/'vyrel/arsenal.json').write_text(json.dumps({'models':models,'attachments':meta}))
(B/'Modules').mkdir(exist_ok=True)
(B/'Modules/WeaponModels.lua').write_text('-- Geometria autoral do arsenal VYREL, exportada do mesmo projeto usado no Blender.\nreturn '+lua({'Models':models,'Attachments':meta})+'\n')
print('ARSENAL_GEOMETRY_OK',len(models),sum(map(len,models.values())),'pecas')
