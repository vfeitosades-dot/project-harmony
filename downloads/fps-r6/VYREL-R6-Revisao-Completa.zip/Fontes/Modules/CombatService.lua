local Players=game:GetService("Players") local system=game:GetService("ReplicatedStorage"):WaitForChild("FPSSystem")
local Match=require(script.Parent.MatchState)
local D={}
function D.Actor(model)
 return Players:GetPlayerFromCharacter(model) or model
end
function D.Attribute(actor,key) return actor and actor:GetAttribute(key) end
function D.Allowed(attacker,model)
 if not attacker or not model then return false end
 if attacker:IsA("Player") and attacker:GetAttribute("FPSSpawnPending")==true then return false end
 local source=attacker:IsA("Player") and attacker.Character or attacker if source==model then return false end
 local target=D.Actor(model) if target:IsA("Player") and target:GetAttribute("FPSSpawnPending")==true then return false end local mode=D.Attribute(attacker,"FPSMode") local targetMode=D.Attribute(target,"FPSMode")
 if mode=="Lobby" or targetMode=="Lobby" then return false end
 local arena=D.Attribute(attacker,"FPSMatchId") local other=D.Attribute(target,"FPSMatchId")
 if arena and other and arena~=other then return false end
 local side=D.Attribute(attacker,"FPSSide") local targetSide=D.Attribute(target,"FPSSide") if side and targetSide and side==targetSide then return false end
 if not (side and targetSide) and target:IsA("Player") and attacker:IsA("Player") and not attacker.Neutral and not target.Neutral and attacker.Team==target.Team then return false end
 return true
end
function D.Apply(attacker,model,damage,critical,position)
 if not D.Allowed(attacker,model) then return 0,false end
 local h=model:FindFirstChildOfClass("Humanoid") if not h or h.Health<=0 or model:FindFirstChildOfClass("ForceField") then return 0,false end
 local now=workspace:GetServerTimeNow() local shield=model:GetAttribute("FPSShield") or 0
 if (model:GetAttribute("FPSShieldUntil") or 0)>now and shield>0 then local used=math.min(shield,damage) damage-=used model:SetAttribute("FPSShield",shield-used) end
 local before=h.Health if damage>0 then h:TakeDamage(damage) end
 local applied=before-h.Health if applied<=0 then return 0,false end
 model:SetAttribute("FPSLastDamageAt",now)
 local recipient=Players:GetPlayerFromCharacter(model) local remote=system.Remotes:FindFirstChild("SkillFX")
 if recipient and remote then local source=attacker:IsA("Player") and attacker.Character or attacker local root=source and source:FindFirstChild("HumanoidRootPart") if root then remote:FireClient(recipient,"Hurt",root.Position,applied,"ION",0) end end
 if h.Health<=0 and not model:GetAttribute("FPSKillCounted") then
  model:SetAttribute("FPSKillCounted",true)
  if model:GetAttribute("FPSDecoy") then return applied,true end
  if attacker:IsA("Player") then Match.Kill(attacker,model,critical)
  else
   local victim=Players:GetPlayerFromCharacter(model)
   if victim then victim:SetAttribute("FPSDeaths",(victim:GetAttribute("FPSDeaths") or 0)+1) end
   system.Remotes.MatchFeed:FireAllClients(attacker.Name,victim and (victim.DisplayName or victim.Name) or model.Name,critical==true,attacker:GetAttribute("FPSMatchId"))
  end
 end
 return applied,h.Health<=0
end
function D.Barrier(part,damage)
 local hp=part:GetAttribute("FPSBarrierHP") if not hp then return false end
 hp-=damage part:SetAttribute("FPSBarrierHP",hp) if hp<=0 then part:Destroy() end return true
end
function D.Params(exclude)
 local params=RaycastParams.new() params.FilterType=Enum.RaycastFilterType.Exclude params.FilterDescendantsInstances=exclude or {} params.IgnoreWater=true return params
end
function D.Visible(origin,target,exclude)
 local delta=target-origin if delta.Magnitude<.01 then return true end
 local hit=workspace:Raycast(origin,delta,D.Params(exclude)) return not hit or (hit.Position-target).Magnitude<1.5
end
return D
