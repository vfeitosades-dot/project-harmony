-- Client confirms that its own character AND local floor exist before physics ownership is released.
local Players=game:GetService("Players") local Run=game:GetService("RunService") local Input=game:GetService("UserInputService")
local R=game:GetService("ReplicatedStorage"):WaitForChild("FPSSystem"):WaitForChild("Remotes")
local S={} local oldCleanup
function S.init()
 if oldCleanup then oldCleanup() end
 local player=Players.LocalPlayer local gui=Instance.new("ScreenGui") gui.Name="VYRELSpawnLoading" gui.IgnoreGuiInset=true gui.ResetOnSpawn=false gui.DisplayOrder=85 gui.Parent=player:WaitForChild("PlayerGui")
 local cover=Instance.new("Frame") cover.Name="Loading" cover.Size=UDim2.fromScale(1,1) cover.BackgroundColor3=Color3.fromRGB(12,20,34) cover.BorderSizePixel=0 cover.Active=true cover.Visible=false cover.Parent=gui
 local title=Instance.new("TextLabel") title.Name="Title" title.Size=UDim2.new(1,-40,0,50) title.Position=UDim2.new(0,20,.45,-25) title.BackgroundTransparency=1 title.Text="PREPARANDO O CAMPO" title.TextColor3=Color3.fromRGB(240,246,252) title.Font=Enum.Font.GothamBold title.TextSize=26 title.Parent=cover
 local subtitle=title:Clone() subtitle.Name="Progress" subtitle.Position=UDim2.new(0,20,.45,28) subtitle.Text="Carregando o cenario com seguranca..." subtitle.TextColor3=Color3.fromRGB(155,178,199) subtitle.TextSize=13 subtitle.Parent=cover
 local cancel=Instance.new("TextButton") cancel.Name="Back" cancel.Size=UDim2.fromOffset(220,38) cancel.Position=UDim2.new(.5,-110,.65,0) cancel.BackgroundColor3=Color3.fromRGB(34,53,74) cancel.TextColor3=Color3.fromRGB(237,245,251) cancel.Text="VOLTAR AO MENU" cancel.Font=Enum.Font.GothamBold cancel.TextSize=12 cancel.Active=true cancel.Modal=true cancel.Parent=cover
 local small=title:Clone() small.Name="LobbyLoading" small.Size=UDim2.fromOffset(270,24) small.Position=UDim2.new(0,20,1,-28) small.Text="Preparando seu personagem..." small.TextSize=11 small.TextXAlignment=Enum.TextXAlignment.Left small.Visible=false small.Parent=gui
 local cursorBinding="VYRELSpawnCursor_"..player.UserId
 local links={} local alive=true local elapsed=0 local sentAt=-math.huge local streamAt=-100 local readyToken local cameraToken
 Run:BindToRenderStep(cursorBinding,Enum.RenderPriority.Camera.Value+60,function() if alive and cover.Visible then Input.MouseBehavior=Enum.MouseBehavior.Default Input.MouseIconEnabled=true end end)
 table.insert(links,cancel.Activated:Connect(function() R.Session:FireServer("Leave") end))
 local function step(dt)
  if not alive then return end elapsed+=dt if elapsed<.1 then return end elapsed=0
  local char=player.Character local root=char and char:FindFirstChild("HumanoidRootPart") local h=char and char:FindFirstChildOfClass("Humanoid")
  local pending=player:GetAttribute("FPSSpawnPending")==true local token=player:GetAttribute("FPSSpawnToken")
  player:SetAttribute("FPSWorldLoading",pending)
  local lobby=(player:GetAttribute("FPSMode") or "Lobby")=="Lobby"
  cover.Visible=pending and not lobby small.Visible=pending and lobby
  subtitle.Text="Preparando o cenario"..string.rep(".",math.floor(workspace:GetServerTimeNow()*2)%4)
  if not pending then
   if readyToken~=token and h and h.Health>0 then
    readyToken=token
    if not lobby and player:GetAttribute("FPSGameMenu")~=true then local camera=workspace.CurrentCamera if camera then camera.CameraType=Enum.CameraType.Custom camera.CameraSubject=h player.CameraMode=Enum.CameraMode.LockFirstPerson end end
   end return
  end
  if not root or not h or h.Health<=0 or type(token)~="number" or char:GetAttribute("FPSSpawnToken")~=token then return end
  if not lobby then Input.MouseBehavior=Enum.MouseBehavior.Default Input.MouseIconEnabled=true end
  if player.RequestStreamAroundAsync and workspace:GetServerTimeNow()-streamAt>2 then streamAt=workspace:GetServerTimeNow() task.spawn(function() pcall(function() player:RequestStreamAroundAsync(root.Position,2) end) end) end
  local world=workspace:FindFirstChild("VYRELWorld") local arena=player:GetAttribute("FPSArena") or "Lobby" local model=world and world:FindFirstChild(arena=="Lobby" and "Citadela" or arena)
  if not model or arena~="Lobby" and model:GetAttribute("MapId")~=player:GetAttribute("FPSMapId") then return end
  local params=RaycastParams.new() params.FilterType=Enum.RaycastFilterType.Include params.FilterDescendantsInstances={model} params.IgnoreWater=true
  local hit=workspace:Raycast(root.Position+Vector3.new(0,2,0),Vector3.new(0,-14,0),params)
  if hit and hit.Instance and hit.Instance:IsA("BasePart") and hit.Instance.CanCollide and hit.Normal.Y>.6 and root.Position.Y-hit.Position.Y>=2 and root.Position.Y-hit.Position.Y<=7 then
   if workspace:GetServerTimeNow()-sentAt>.2 then sentAt=workspace:GetServerTimeNow() R.Session:FireServer("SpawnReady",token) end
  end
 end
 table.insert(links,Run.Heartbeat:Connect(step)) step(.1)
 local function cleanup() alive=false Run:UnbindFromRenderStep(cursorBinding) player:SetAttribute("FPSWorldLoading",false) for _,c in ipairs(links) do c:Disconnect() end gui:Destroy() end
 oldCleanup=cleanup return cleanup
end
return S
