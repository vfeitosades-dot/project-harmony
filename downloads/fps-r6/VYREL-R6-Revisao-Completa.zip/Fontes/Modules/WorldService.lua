local Players=game:GetService("Players") local CS=game:GetService("CollectionService") local Debris=game:GetService("Debris")
local Maps=require(script.Parent.MapCatalog) local Architecture=require(script.Parent.MapArchitecture)
local W={Centers={Lobby=Vector3.new(0,0,1600),Casual=Vector3.new(0,0,0),Training=Vector3.new(1600,0,0)},Cover={},Spawns={},SpawnNodes={},MapIds={},Revision={},Models={},Floors={}}
local built=false local root local reserved={} local cursor={}
local function color(r,g,b) return Color3.fromRGB(r,g,b) end
local stone=color(120,130,142) local trim=color(41,49,65) local cyan=color(75,229,239) local coral=color(242,115,106)
local function part(parent,name,size,cf,tint,material,shape,decor)
 local p=Instance.new(shape=="Wedge" and "WedgePart" or "Part") p.Name=name p.Size=size p.CFrame=cf p.Color=tint p.Material=material or Enum.Material.Concrete p.Anchored=true p.TopSurface=Enum.SurfaceType.Smooth p.BottomSurface=Enum.SurfaceType.Smooth p.CanCollide=not decor p.CanTouch=false p.CanQuery=not decor p.Parent=parent
 return p
end
local function environment(parent,id,center)
 local theme=Maps.Maps[id] local accent=Color3.fromRGB(table.unpack(theme.Color))
 local m=Instance.new("Model") m.Name=id m:SetAttribute("MapId",id)
 local cover={} local nodes={}
 local function sign(surface,value,face)
  local ui=Instance.new("SurfaceGui") ui.Name="Sinalizacao" ui.Face=face ui.CanvasSize=Vector2.new(480,100) ui.Parent=surface
  local label=Instance.new("TextLabel") label.Name="Texto" label.Size=UDim2.fromScale(1,1) label.BackgroundTransparency=1 label.Text=value label.Font=Enum.Font.GothamBold label.TextScaled=true label.TextColor3=Color3.fromRGB(236,242,247) label.Parent=ui
 end local function at(x,y,z,angle) return CFrame.new(center+Vector3.new(x,y,z))*CFrame.Angles(0,math.rad(angle or 0),0) end
 local function box(name,size,x,y,z,tint,material,decor,angle) return part(m,name,size,at(x,y,z,angle),tint,material,nil,decor) end
 local floorColor=theme.FloorColor and Color3.fromRGB(table.unpack(theme.FloorColor)) or id=="SOLARA" and color(187,156,111) or id=="GLACIER" and color(213,229,235) or color(53,64,76)
 local floorMat=theme.FloorMaterial and Enum.Material[theme.FloorMaterial] or id=="SOLARA" and Enum.Material.Sand or id=="GLACIER" and Enum.Material.Snow or Enum.Material.Asphalt
 local floor=box("Piso",Vector3.new(176,2,176),0,0,0,floorColor,floorMat)
 floor:SetAttribute("SpawnFloor",true)
 local wallColor=theme.WallColor and Color3.fromRGB(table.unpack(theme.WallColor)) or id=="SOLARA" and color(155,116,77) or id=="GLACIER" and color(89,118,137) or color(66,68,85)
 local wallMat=theme.WallMaterial and Enum.Material[theme.WallMaterial] or id=="SOLARA" and Enum.Material.Sandstone or id=="GLACIER" and Enum.Material.Metal or Enum.Material.Brick
 for _,v in ipairs({{0,7,-88,176,14,2},{0,7,88,176,14,2},{-88,7,0,2,14,176},{88,7,0,2,14,176}}) do box("Limite",Vector3.new(v[4],v[5],v[6]),v[1],v[2],v[3],wallColor,wallMat) end
 local function coverBox(name,x,z,sx,sy,sz,tint,material)
  box(name,Vector3.new(sx,sy,sz),x,1+sy/2,z,tint,material)
  table.insert(cover,center+Vector3.new(x,4,z+sz/2+4)) table.insert(cover,center+Vector3.new(x,4,z-sz/2-4))
 end
 local function ramp(x,z,angle,height,length,tint,material)
  local cf=at(x,1+height/2,z,angle)
  part(m,"Rampa",Vector3.new(14,height,length),cf,tint,material,"Wedge")
 end
 local function arch(x,z,angle,tint)
  local base=at(x,1,z,angle)
  for _,side in ipairs({-1,1}) do
   part(m,"Coluna",Vector3.new(3,12,4),base*CFrame.new(side*9,6,0),tint,Enum.Material.Sandstone)
   part(m,"Capitel",Vector3.new(4,1.2,5),base*CFrame.new(side*9,12,0),accent,Enum.Material.Sandstone)
  end
  for n=0,6 do local a=n*math.pi/6
   part(m,"ArcoTalhado",Vector3.new(4.6,2.5,4),base*CFrame.new(math.cos(a)*8,12+math.sin(a)*7,0)*CFrame.Angles(0,0,a+math.pi/2),tint,Enum.Material.Sandstone)
  end
 end
 local function planter(x,z)
  box("Canteiro",Vector3.new(8,1.4,8),x,1.7,z,color(110,82,67),Enum.Material.Brick)
  box("Terra",Vector3.new(7.5,.1,7.5),x,2.42,z,color(63,72,47),Enum.Material.Ground,true)
  box("Tronco",Vector3.new(1.2,12,1.2),x,8.4,z,color(100,78,53),Enum.Material.Wood,true)
  for i=0,5 do local a=i*math.pi/3
   part(m,"Palmeira",Vector3.new(2,.5,9),at(x,14,z)*CFrame.Angles(0,a,.16)*CFrame.new(0,0,-3),color(70,112+i*3,61),Enum.Material.Grass,nil,true)
  end
 end
 if Architecture.Build(id,{Model=m,Center=center,Box=box,Part=part,At=at,CoverBox=coverBox,CoverNodes=cover,Ramp=ramp,Accent=accent,Sign=sign}) then
 elseif id=="SOLARA" then
  for x=-60,60,20 do for z=-48,48,16 do box("Laje",Vector3.new(17.7,.08,13.7),x,1.04,z,color(208,177+(z%3),127),Enum.Material.Sandstone,true) end end
  for _,z in ipairs({-34,34}) do arch(0,z,0,color(218,184,131)) end
  for _,x in ipairs({-53,53}) do
   for _,z in ipairs({-29,29}) do
    coverBox("Ruina",x,z,22,7,14,color(190,145,96),Enum.Material.Sandstone)
    box("FrisoEsculpido",Vector3.new(24,.7,16),x,8.5,z,color(229,190,134),Enum.Material.Sandstone)
    for n=-1,1 do box("Relevo",Vector3.new(1,4,.25),x+n*6,4.8,z-7.2,accent,Enum.Material.Brick,true) end
   end
  end
  coverBox("Santuario",0,0,24,6,18,color(207,167,111),Enum.Material.Sandstone)
  ramp(0,20,180,6,22,color(199,168,120),Enum.Material.Sandstone) ramp(0,-20,0,6,22,color(199,168,120),Enum.Material.Sandstone)
  box("Fonte",Vector3.new(11,.2,10),0,7.18,0,color(64,175,174),Enum.Material.Glass,true).Transparency=.25
  for _,x in ipairs({-29,29}) do planter(x,-21) planter(x,21) end
  for _,v in ipairs({{-27,2},{26,-3},{-7,47},{8,-47}}) do coverBox("Mureta",v[1],v[2],12,3.8,4,color(177,137,91),Enum.Material.Sandstone) end
  for _,side in ipairs({-1,1}) do
   for n=0,4 do local x=side*(100+n*18) arch(x,7,90,color(165,129,94)) end
   part(m,"Montanha",Vector3.new(55,49,75),at(side*145,10,-28,18*side),color(142,110,84),Enum.Material.Rock,"Wedge",true)
  end
  for _,x in ipairs({-78,78}) do for z=-45,45,15 do box("Trepadeira",Vector3.new(.5,6,2.5),x,12,z,color(60,105,61),Enum.Material.Grass,true) end end
 elseif id=="GLACIER" then
  local function container(x,z,angle,tint,sy)
   sy=sy or 8 local cf=at(x,1+sy/2,z,angle)
   part(m,"Conteiner",Vector3.new(16,sy,31),cf,tint,Enum.Material.CorrodedMetal)
   for _,side in ipairs({-1,1}) do
    for n=-6,6 do part(m,"Nervura",Vector3.new(.18,sy-.4,.18),cf*CFrame.new(side*8.1,0,n*2),color(69,92,109),Enum.Material.Metal,nil,true) end
    part(m,"TrilhoCarga",Vector3.new(16.4,.25,.3),cf*CFrame.new(0,sy/2-.3,side*15.5),color(144,164,176),Enum.Material.Metal,nil,true)
   end
   part(m,"NeveAcumulada",Vector3.new(16.3,.28,31.2),cf*CFrame.new(0,sy/2+.12,0),color(237,246,247),Enum.Material.Snow,nil,true)
   table.insert(cover,center+Vector3.new(x+12,4,z)) table.insert(cover,center+Vector3.new(x-12,4,z))
  end
  container(-48,-24,0,color(62,125,152)) container(48,24,0,color(62,125,152))
  container(-47,30,90,color(181,111,50)) container(47,-30,90,color(181,111,50))
  container(0,0,90,color(72,112,130),6)
  ramp(-28,0,90,6,24,color(132,153,163),Enum.Material.DiamondPlate) ramp(28,0,-90,6,24,color(132,153,163),Enum.Material.DiamondPlate)
  for _,v in ipairs({{-22,-37},{22,37},{-8,47},{8,-47}}) do coverBox("CargaTermica",v[1],v[2],10,4.5,8,color(127,146,155),Enum.Material.Metal) end
  for _,side in ipairs({-1,1}) do
   local x=side*101
   box("BaseGuindaste",Vector3.new(12,43,12),x,20,0,color(192,141,52),Enum.Material.Metal,true)
   box("LancaGuindaste",Vector3.new(6,5,94),x,44,0,color(226,163,63),Enum.Material.Metal,true)
   for _,z in ipairs({-35,35}) do box("CaboGuindaste",Vector3.new(.25,23,.25),x,31,z,color(60,73,83),Enum.Material.Metal,true) end
   for n=1,5 do part(m,"Iceberg",Vector3.new(19,18+n*5,35),at(side*(105+n*11),5+n*2,-70+n*25,side*n*11),color(165,204,221),Enum.Material.Glacier,"Wedge",true) end
  end
  for _,x in ipairs({-77,77}) do box("Luminaria",Vector3.new(1,20,1),x,10,0,color(77,90,102),Enum.Material.Metal) box("Lampada",Vector3.new(5,.4,2),x,20,0,cyan,Enum.Material.Neon,true) end
 else
  local teal=color(77,224,216) local pink=color(240,105,172)
  box("FaixaCentral",Vector3.new(10,.07,160),0,1.04,0,color(86,95,112),Enum.Material.Concrete,true)
  for _,x in ipairs({-58,58}) do
   for _,z in ipairs({-29,29}) do
    for _,side in ipairs({-1,1}) do
     box("ParedeLoja",Vector3.new(1,15,23),x+side*12,8.5,z,color(92,75,88),Enum.Material.Brick)
     for _,signSide in ipairs({-1,1}) do box("FachadaLoja",Vector3.new(8,15,1),x+signSide*8.5,8.5,z+side*11.5,color(92,75,88),Enum.Material.Brick) end
     box("VergaLoja",Vector3.new(9,8,1),x,12,z+side*11.5,color(92,75,88),Enum.Material.Brick)
    end
    table.insert(cover,center+Vector3.new(x+17,4,z))
    box("Marquise",Vector3.new(28,1.4,27),x,16.7,z,color(35,44,62),Enum.Material.Metal)
    for _,side in ipairs({-1,1}) do
     box("Vitrine",Vector3.new(.18,6,14),x+side*12.65,7,z,color(59,123,143),Enum.Material.Glass,true).Transparency=.25
     local neon=box("LetreiroNeon",Vector3.new(.25,1.3,17),x+side*12.85,12,z,side==1 and pink or teal,Enum.Material.Neon,true)
     sign(neon,z>0 and "SORA / NIGHT MARKET" or "NOVA / ARCADE",side==1 and Enum.NormalId.Right or Enum.NormalId.Left)
     if side==(x<0 and 1 or -1) then local light=Instance.new("PointLight") light.Name="Glow" light.Color=side==1 and pink or teal light.Brightness=1.6 light.Range=25 light.Shadows=false light.Parent=neon end
     for n=-1,1 do box("Moldura",Vector3.new(.3,6,.3),x+side*12.85,7,z+n*7.1,color(37,47,67),Enum.Material.Metal,true) end
    end
    for n=-1,1 do box("Telha",Vector3.new(26,.7,8),x,18.2+math.abs(n)*-.8,z+n*8,color(46,72,87),Enum.Material.Slate,true) end
   end
  end
  coverBox("Quiosque",0,0,22,5,17,color(90,77,83),Enum.Material.WoodPlanks)
  ramp(0,19,180,5,20,color(99,107,120),Enum.Material.Concrete) ramp(0,-19,0,5,20,color(99,107,120),Enum.Material.Concrete)
  box("TelhadoQuiosque",Vector3.new(25,.45,20),0,6.3,0,color(63,83,96),Enum.Material.Slate)
  for _,v in ipairs({{-26,-15},{26,15},{-17,43},{17,-43}}) do
   coverBox("Balcao",v[1],v[2],12,4,6,color(128,87,65),Enum.Material.WoodPlanks)
   box("Toldo",Vector3.new(13,.3,7),v[1],8,v[2],teal,Enum.Material.Fabric,true)
   for _,side in ipairs({-1,1}) do box("SuporteToldo",Vector3.new(.3,6,.3),v[1]+side*5.5,5,v[2],color(50,60,74),Enum.Material.Metal,true) end
  end
  for _,x in ipairs({-75,75}) do
   box("Poste",Vector3.new(.7,18,.7),x,10,0,color(57,63,79),Enum.Material.Metal)
   for z=-48,48,16 do box("Lanterna",Vector3.new(2.3,3,2.3),x,19,z,pink,Enum.Material.Neon,true) end
  end
  for i=1,16 do local a=i*2.399 local radius=110+i%3*15 local h=26+i%5*11
   local x,z=math.sin(a)*radius,math.cos(a)*radius
   box("ArranhaCeu",Vector3.new(16,h,18),x,h/2,z,color(35,44,62),Enum.Material.Concrete,true)
   for y=8,h-3,7 do box("JanelaCidade",Vector3.new(12,.8,.1),x,y,z-9.1,i%2==0 and teal or pink,Enum.Material.Neon,true) end
  end
 end
 -- Model finishing is decorative and never changes the validated spawn or collision volumes.
 local outlined={Ruina=true,Santuario=true,Quiosque=true,Conteiner=true,CargaTermica=true,MaquinaCentral=true,Baluarte=true,Gerador=true,FontePraca=true,JardineiraCentral=true}
 for _,body in ipairs(m:GetChildren()) do if body:IsA("BasePart") and outlined[body.Name] then
  local tint=id=="SOLARA" and color(220,187,139) or id=="GLACIER" and color(159,182,195) or trim
  for _,side in ipairs({-1,1}) do
   part(m,"AcabamentoVertical",Vector3.new(.22,body.Size.Y+.06,.25),body.CFrame*CFrame.new(side*(body.Size.X/2+.03),0,-body.Size.Z/2-.02),tint,body.Material,nil,true)
  end
  part(m,"AcabamentoSuperior",Vector3.new(body.Size.X+.12,.12,body.Size.Z+.12),body.CFrame*CFrame.new(0,body.Size.Y/2+.07,0),tint,body.Material,nil,true)
 end end
 -- Protected rear zones: no prop or sloped floor crosses the spawn footprint.
 for _,side in ipairs({-1,1}) do
  for _,x in ipairs({-39,39}) do
   local baseWall=box("AnteparoSpawn",Vector3.new(42,7,2),x,4.5,side*60,wallColor,wallMat)
   sign(baseWall,side==1 and "BASE A  /  VYREL" or "BASE B  /  VYREL",side==1 and Enum.NormalId.Back or Enum.NormalId.Front)
   box("SinalBase",Vector3.new(30,.25,.16),x,7.4,side*58.9,accent,Enum.Material.Neon,true)
  end
  for _,z in ipairs({70,80}) do for _,x in ipairs({-60,-40,-20,20,40,60}) do
   local position=center+Vector3.new(x,1,side*z)
   table.insert(nodes,{Position=position,Side=side==1 and "A" or "B"})
   local pad=box("SpawnPad",Vector3.new(6,.06,6),x,1.04,side*z,accent,id=="SOLARA" and Enum.Material.Sandstone or Enum.Material.Metal,true) pad.TopSurface=Enum.SurfaceType.Studs
  end end
 end
 m.Parent=parent return m,cover,nodes,floor
end
function W.ExportMap(id) if not Maps.Maps[id] then return nil end return environment(nil,id,Vector3.zero) end
function W.SetMap(arena,id)
 if not Maps.Maps[id] or not W.Centers[arena] or arena=="Lobby" then return false end
 local m,cover,nodes,floor=environment(nil,id,W.Centers[arena]) m.Name=arena
 if arena=="Training" then
  nodes={}
  for _,x in ipairs({-24,0,24}) do table.insert(nodes,{Position=W.Centers[arena]+Vector3.new(x,1,48),Side="A"}) table.insert(nodes,{Position=W.Centers[arena]+Vector3.new(x,1,-24),Side="B"}) end
  for _,p in ipairs(m:GetChildren()) do if p.Name=="SpawnPad" then p:Destroy() end end
 end
 local old=W.Models[arena] W.Models[arena]=m W.Cover[arena]=cover W.SpawnNodes[arena]=nodes W.Floors[arena]=floor W.MapIds[arena]=id W.Revision[arena]=(W.Revision[arena] or 0)+1 reserved[arena]={}
 local vectors={} for _,node in ipairs(nodes) do table.insert(vectors,node.Position+Vector3.new(0,3.1,0)) end W.Spawns[arena]=vectors
 m.Parent=root if old then old:Destroy() end return true
end
function W.Build()
 if built then return end built=true
 for _,name in ipairs({"BancadaTeste","Spawn","ParedeTesteLOS","Instrucoes"}) do local old=workspace:FindFirstChild(name) if old then old:Destroy() end end
 local existing=workspace:FindFirstChild("VYRELWorld") if existing then existing:Destroy() end
 root=Instance.new("Folder") root.Name="VYRELWorld" root.Parent=workspace
 W.SetMap("Casual","SAHRA") W.SetMap("Training","BASTION")
 for i=1,3 do W.Centers["Ranked"..i]=Vector3.new(3200+(i-1)*1600,0,0) W.SetMap("Ranked"..i,Maps.Order[i]) end
 local lobby=Instance.new("Model") lobby.Name="Citadela" lobby.Parent=root local c=W.Centers.Lobby
 part(lobby,"Ilha",Vector3.new(120,5,100),CFrame.new(c+Vector3.new(0,-2,0)),trim)
 part(lobby,"Praca",Vector3.new(94,2,80),CFrame.new(c+Vector3.new(0,1,0)),stone)
 for i=0,7 do local angle=i*math.pi/4 local pos=c+Vector3.new(math.sin(angle)*28,17,math.cos(angle)*28)
  part(lobby,"Arco",Vector3.new(4,30,4),CFrame.new(pos)*CFrame.Angles(0,angle,.08),trim)
  part(lobby,"Cristal",Vector3.new(2,8,2),CFrame.new(pos+Vector3.new(0,19,0))*CFrame.Angles(.2,angle,.35),coral,Enum.Material.Neon)
 end
 local ring=part(lobby,"Portal",Vector3.new(17,17,2),CFrame.new(c+Vector3.new(0,14,-15)),trim) ring.Transparency=.8 ring.CanCollide=false
 for i=0,11 do local a=i*math.pi/6 part(lobby,"PortalSegmento",Vector3.new(4,.9,1),CFrame.new(c+Vector3.new(math.cos(a)*8,14+math.sin(a)*8,-16))*CFrame.Angles(0,0,a+math.pi/2),cyan,Enum.Material.Neon).CanCollide=false end
 for i=1,14 do local angle=i*2.399 local r=65+i*2 local height=12+i%4*10 part(lobby,"CidadeSuspensa",Vector3.new(14,height,14),CFrame.new(c+Vector3.new(math.sin(angle)*r,height/2-5,math.cos(angle)*r)),stone) end W.Models.Lobby=lobby
 local assets=game:GetService("ReplicatedStorage"):WaitForChild("FPSSystem"):WaitForChild("Assets")
 local previews=Instance.new("Folder") previews.Name="MapPreviews" previews.Parent=assets
 for _,id in ipairs(Maps.Order) do
  local full=environment(nil,id,Vector3.zero) full.Name=id
  for _,p in ipairs(full:GetDescendants()) do if p:IsA("BasePart") and p.Size.X*p.Size.Y*p.Size.Z<14 and p.Material~=Enum.Material.Neon and not p:GetAttribute("PreviewDetail") then p:Destroy() end end
  full.Parent=previews
 end
end
local function enemies(arena,side,model)
 local list={}
 for _,p in ipairs(Players:GetPlayers()) do if p.Character and p.Character~=model and p:GetAttribute("FPSArena")==arena then table.insert(list,{Model=p.Character,Side=p:GetAttribute("FPSSide")}) end end
 for _,m in ipairs(CS:GetTagged("FPSDemoBot")) do if m~=model and m:GetAttribute("FPSArena")==arena then table.insert(list,{Model=m,Side="Hostile"}) end end
 return list
end
function W.SpawnCFrame(actor,model)
 W.Build() local arena=actor:GetAttribute("FPSArena") or "Lobby" local center=W.Centers[arena] or W.Centers.Lobby
 local h=model and model:FindFirstChildOfClass("Humanoid") local rootPart=model and model:FindFirstChild("HumanoidRootPart") local leg=model and model:FindFirstChild("Left Leg")
 local lift=math.clamp((leg and leg.Size.Y or 2)+(rootPart and rootPart.Size.Y*.5 or 1)+(h and h.HipHeight or 0),2.8,4.5)+.12
 if arena=="Lobby" then
  local index=math.abs(actor:IsA("Player") and actor.UserId or 1)%8 local pos=center+Vector3.new((index%4-1.5)*9,2+lift,25+math.floor(index/4)*9)
  return CFrame.lookAt(pos,Vector3.new(center.X,pos.Y,center.Z))
 end
 local side=actor:GetAttribute("FPSSide") local desired=(side=="B" or side=="Hostile") and "B" or "A"
 local nodes=W.SpawnNodes[arena] if not nodes then return nil end
 local excludes={} for _,p in ipairs(Players:GetPlayers()) do if p.Character then table.insert(excludes,p.Character) end end
 for _,m in ipairs(CS:GetTagged("FPSDemoBot")) do table.insert(excludes,m) end if model then table.insert(excludes,model) end
 local overlap=OverlapParams.new() overlap.FilterType=Enum.RaycastFilterType.Exclude overlap.FilterDescendantsInstances=excludes
 local floorParams=RaycastParams.new() floorParams.FilterType=Enum.RaycastFilterType.Include floorParams.FilterDescendantsInstances={W.Floors[arena],W.Models[arena]}
 local live=enemies(arena,side,model) local best local bestScore=-math.huge local at=workspace:GetServerTimeNow()
 reserved[arena]=reserved[arena] or {} cursor[arena]=(cursor[arena] or 0)+1
 for step=1,#nodes do local index=(step+cursor[arena]-1)%#nodes+1 local node=nodes[index]
  if node.Side==desired then
   local ground=workspace:Raycast(node.Position+Vector3.new(0,8,0),Vector3.new(0,-14,0),floorParams)
   if ground and ground.Normal.Y>.8 then
    local feet=Vector3.new(node.Position.X,ground.Position.Y,node.Position.Z) local position=feet+Vector3.new(0,lift,0)
    local clear=true
    for _,p in ipairs(workspace:GetPartBoundsInBox(CFrame.new(feet+Vector3.new(0,3.1,0)),Vector3.new(4,5.8,4),overlap)) do if p:IsA("BasePart") and p.CanCollide then clear=false break end end
    if clear then
     local score=(reserved[arena][index] or 0)>at and -1000 or 0 local nearest=120
     for _,other in ipairs(live) do local r=other.Model:FindFirstChild("HumanoidRootPart") local hum=other.Model:FindFirstChildOfClass("Humanoid")
      if r and hum and hum.Health>0 then local distance=(r.Position-position).Magnitude
       if other.Side~=side then
        nearest=math.min(nearest,distance)
        if distance<100 then local ray=RaycastParams.new() ray.FilterType=Enum.RaycastFilterType.Exclude ray.FilterDescendantsInstances=excludes local hit=workspace:Raycast(position,r.Position-position,ray) if not hit then score-=100 end end
       elseif distance<8 then score-=300 end
      end
     end
     score+=nearest
     if score>bestScore then bestScore=score best={Position=position,Index=index} end
    end
   end
  end
 end
 if not best then return nil end reserved[arena][best.Index]=at+1.5
 local exitZ=arena=="Training" and center.Z or center.Z+(desired=="B" and -60 or 60)
 return CFrame.lookAt(best.Position,Vector3.new(center.X,best.Position.Y,exitZ))
end
function W.GetSpawn(actor) local cf=W.SpawnCFrame(actor,actor.Character) return cf and cf.Position or nil end
function W.Place(actor,model,protect)
 local rootPart=model and model:FindFirstChild("HumanoidRootPart") local h=model and model:FindFirstChildOfClass("Humanoid") if not rootPart or not h or h.Health<=0 then return false end
 local cf=W.SpawnCFrame(actor,model) if not cf then return false end
 model.PrimaryPart=rootPart
 local player=actor:IsA("Player")
 if player then rootPart.Anchored=true end
 -- PivotTo targets the pivot, which can differ from the HumanoidRootPart CFrame.
 model:PivotTo(cf*(rootPart.PivotOffset or CFrame.new()))
 rootPart.AssemblyLinearVelocity=Vector3.zero rootPart.AssemblyAngularVelocity=Vector3.zero
 if player then
  local token=(actor:GetAttribute("FPSSpawnToken") or 0)+1
  model:SetAttribute("FPSSpawnToken",token) actor:SetAttribute("FPSSpawnToken",token)
  actor:SetAttribute("FPSSpawnPending",true) h.WalkSpeed=0
 end
 pcall(function() rootPart:SetNetworkOwner(nil) end)

 if protect and actor:GetAttribute("FPSMode")~="Lobby" then
  local old=model:FindFirstChild("SpawnProtection") if old then old:Destroy() end
  local ff=Instance.new("ForceField") ff.Name="SpawnProtection" ff.Visible=true ff.Parent=model Debris:AddItem(ff,2)
 end
 actor:SetAttribute("FPSMapId",W.MapIds[actor:GetAttribute("FPSArena") or "Lobby"] or "Lobby") actor:SetAttribute("FPSSpawnAt",workspace:GetServerTimeNow())
 return true
end
function W.ReleaseSpawn(actor,token)
 if type(token)~="number" or token~=actor:GetAttribute("FPSSpawnToken") or actor:GetAttribute("FPSSpawnPending")~=true then return false end
 local model=actor.Character local rootPart=model and model:FindFirstChild("HumanoidRootPart") local h=model and model:FindFirstChildOfClass("Humanoid")
 if not rootPart or not h or h.Health<=0 or model:GetAttribute("FPSSpawnToken")~=token then return false end
 local arena=actor:GetAttribute("FPSArena") or "Lobby" local geometry=W.Models[arena]
 if not geometry then return false end
 local params=RaycastParams.new() params.FilterType=Enum.RaycastFilterType.Include params.FilterDescendantsInstances={geometry}
 local floor=workspace:Raycast(rootPart.Position+Vector3.new(0,2,0),Vector3.new(0,-14,0),params)
 if not floor or not floor.Instance.CanCollide or floor.Normal.Y<.6 or rootPart.Position.Y-floor.Position.Y<2 then return false end
 rootPart.AssemblyLinearVelocity=Vector3.zero rootPart.AssemblyAngularVelocity=Vector3.zero rootPart.Anchored=false
 h.PlatformStand=false h.Sit=false h.EvaluateStateMachine=true h.WalkSpeed=actor:GetAttribute("FPSMode")=="Lobby" and 0 or 16
 pcall(function() h:ChangeState(Enum.HumanoidStateType.GettingUp) end) pcall(function() rootPart:SetNetworkOwner(actor) end)
 actor:SetAttribute("FPSSpawnPending",false)
 local fx=game:GetService("ReplicatedStorage"):WaitForChild("FPSSystem").Remotes:FindFirstChild("SkillFX")
 if fx and actor:GetAttribute("FPSMode")~="Lobby" then fx:FireAllClients("SpawnPulse",rootPart.Position-Vector3.new(0,2.8,0),1,actor:GetAttribute("FPSAgent") or "ION",actor.UserId) end
 if actor:GetAttribute("FPSMode")~="Lobby" then
  local old=model:FindFirstChild("SpawnProtection") if old then old:Destroy() end
  local ff=Instance.new("ForceField") ff.Name="SpawnProtection" ff.Visible=true ff.Parent=model Debris:AddItem(ff,2)
 end
 return true
end
function W.OutOfBounds(actor,model)
 local r=model and model:FindFirstChild("HumanoidRootPart") if not r then return false end local arena=actor:GetAttribute("FPSArena") or "Lobby" local center=W.Centers[arena] or W.Centers.Lobby
 local floor=W.Floors[arena] local floorTop=arena=="Lobby" and center.Y+2 or floor and floor.Position.Y+floor.Size.Y*.5 or center.Y+1
 local leg=model:FindFirstChild("Left Leg") local minimum=math.max(.35,((leg and leg.Size.Y or 2)+r.Size.Y*.5)*.55)
 return r.Position.Y<floorTop+minimum or math.abs(r.Position.X-center.X)>(arena=="Lobby" and 60 or 90) or math.abs(r.Position.Z-center.Z)>(arena=="Lobby" and 50 or 90)
end
return W
