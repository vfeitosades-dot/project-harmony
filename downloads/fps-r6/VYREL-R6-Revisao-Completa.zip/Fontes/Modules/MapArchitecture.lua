-- Six original layouts, based on the user's visual references; no imported third-party assets.
local A={}
local function rgb(r,g,b) return Color3.fromRGB(r,g,b) end
local supported={SAHRA=true,NEXUS=true,MARINA=true,BASTION=true,VERANO=true,FREIGHT=true}
function A.Build(id,c)
 if not supported[id] then return false end
 local box,part,at,cover,ramp=c.Box,c.Part,c.At,c.CoverBox,c.Ramp local m=c.Model
 local wood=rgb(115,78,48) local steel=rgb(72,88,104) local cyan=rgb(82,222,242) local purple=rgb(153,108,244)
 -- Transparent gameplay bounds plus visible railings replace the flat boxed arena silhouette.
 for _,p in ipairs(m:GetChildren()) do if p.Name=="Limite" then p.Transparency=1 end end
 local function rail(x,z,length,angle,material,tint,y)
  y=y or 1 local base=at(x,y,z,angle)
  for _,level in ipairs({1.6,3.3}) do part(m,"Corrimao",Vector3.new(length,.22,.22),base*CFrame.new(0,level,0),tint,material) end
  for n=0,math.floor(length/8) do part(m,"PosteGuarda",Vector3.new(.35,3.6,.35),base*CFrame.new(-length/2+n*8,1.8,0),tint,material) end
 end
 local function stairs(x,z,height,width,run,angle,material,tint)
  local n=math.ceil(height/1) local base=at(x,1,z,angle)
  for i=1,n do local h=i*height/n part(m,"Degrau",Vector3.new(width,h,run/n+.04),base*CFrame.new(0,h/2,-run/2+(i-.5)*run/n),tint,material) end
 end
 local function tree(x,z,scale,classic)
  scale=scale or 1
  box("Tronco",Vector3.new(1.5,7,1.5)*scale,x,1+3.5*scale,z,wood,Enum.Material.Wood)
  local leaf=box("CopaGeometrica",Vector3.new(8,7,8)*scale,x,1+9*scale,z,rgb(69,130,72),Enum.Material.Grass,true,25)
  if classic then leaf.TopSurface=Enum.SurfaceType.Studs end
  box("CopaTopo",Vector3.new(5,4,5)*scale,x,1+13*scale,z,rgb(87,153,78),Enum.Material.Grass,true,-20)
 end
 local function bridge(x,z,length,width,height,angle)
  local base=at(x,1+height,z,angle)
  for n=1,math.ceil(length/2) do part(m,"TabuaPonte",Vector3.new(width,.45,1.9),base*CFrame.new(0,0,-length/2+(n-.5)*2),wood,Enum.Material.WoodPlanks) end
  for _,s in ipairs({-1,1}) do
   part(m,"Longarina",Vector3.new(.7,1,length),base*CFrame.new(s*(width/2-.7),-.6,0),steel,Enum.Material.Metal)
   for n=0,math.floor(length/8) do part(m,"PostePonte",Vector3.new(.35,3,.35),base*CFrame.new(s*(width/2-.3),1.5,-length/2+n*8),wood,Enum.Material.Wood) end
   part(m,"GuardaPonte",Vector3.new(.28,.28,length),base*CFrame.new(s*(width/2-.3),2.8,0),wood,Enum.Material.Wood)
  end
 end
 local function house(x,z,width,depth,height,tint,theme,open)
  local mat=theme=="desert" and Enum.Material.Sandstone or Enum.Material.Concrete
  local cf=at(x,1,z,0)
  -- Real doorway and interior clearance, rather than a solid cuboid painted as a house.
  local wall=2 local front=-depth/2
  for _,s in ipairs({-1,1}) do
   part(m,"ParedeLateral",Vector3.new(wall,height,depth),cf*CFrame.new(s*(width/2-wall/2),height/2,0),tint,mat)
   part(m,"LadoEntrada",Vector3.new((width-10)/2,height,wall),cf*CFrame.new(s*(width+10)/4,height/2,front),tint,mat)
  end
  part(m,"VergaPorta",Vector3.new(10,height-7,wall),cf*CFrame.new(0,7+(height-7)/2,front),tint,mat)
  if not open then part(m,"ParedeFundos",Vector3.new(width,height,wall),cf*CFrame.new(0,height/2,depth/2),tint,mat) else
   for _,s in ipairs({-1,1}) do part(m,"SaidaFundos",Vector3.new((width-10)/2,height,wall),cf*CFrame.new(s*(width+10)/4,height/2,depth/2),tint,mat) end
   part(m,"VergaFundos",Vector3.new(10,height-7,wall),cf*CFrame.new(0,7+(height-7)/2,depth/2),tint,mat)
  end
  local roof=part(m,"Terraco",Vector3.new(width+1,1,depth+1),cf*CFrame.new(0,height+.5,0),tint,mat)
  for _,s in ipairs({-1,1}) do
   for _,v in ipairs({-depth*.25,depth*.25}) do
    part(m,"JanelaRecuada",Vector3.new(.15,3.4,4.2),cf*CFrame.new(s*(width/2+.10),height*.62,v),rgb(54,86,102),Enum.Material.Glass,nil,true)
    part(m,"Peitoril",Vector3.new(.6,.3,5),cf*CFrame.new(s*(width/2+.20),height*.62-1.9,v),rgb(224,210,179),Enum.Material.Concrete,nil,true)
   end
  end
  if theme=="desert" then
   for _,s in ipairs({-1,1}) do for _,xSide in ipairs({-1,1}) do part(m,"Platibanda",Vector3.new((width-10)/2,1.5,.6),cf*CFrame.new(xSide*(width+10)/4,height+1.6,s*(depth/2)),rgb(190,109,68),Enum.Material.Sandstone) end end
  else
   part(m,"Cornija",Vector3.new(width+2,.65,depth+2),cf*CFrame.new(0,height+1.2,0),rgb(235,224,199),Enum.Material.Concrete,nil,true)
  end
  table.insert(c.CoverNodes,c.Center+Vector3.new(x+width/2+4,4,z))
  return roof
 end
 local function container(x,z,angle,tint,open,y)
  y=y or 1 local cf=at(x,y,z,angle) local width,length,height=14,28,8
  if open then
   for _,s in ipairs({-1,1}) do part(m,"ParedeConteiner",Vector3.new(.6,height,length),cf*CFrame.new(s*width/2,height/2,0),tint,Enum.Material.Metal) end
   part(m,"TetoConteiner",Vector3.new(width+.6,.4,length),cf*CFrame.new(0,height,0),tint,Enum.Material.Metal)
  else part(m,"Conteiner",Vector3.new(width,height,length),cf*CFrame.new(0,height/2,0),tint,Enum.Material.Metal) end
  for _,s in ipairs({-1,1}) do
   for n=-6,6 do part(m,"NervuraCarga",Vector3.new(.18,7.5,.18),cf*CFrame.new(s*(width/2+.35),4,n*2),tint,Enum.Material.Metal,nil,true) end
   for _,h in ipairs({.3,7.8}) do part(m,"FrisoCarga",Vector3.new(width+.8,.3,.3),cf*CFrame.new(0,h,s*length/2),steel,Enum.Material.Metal,nil,true) end
  end
  table.insert(c.CoverNodes,c.Center+Vector3.new(x+11,4,z)) table.insert(c.CoverNodes,c.Center+Vector3.new(x-11,4,z))
 end
 for _,s in ipairs({-1,1}) do rail(0,s*86,164,0,Enum.Material.Metal,steel) rail(s*86,0,164,90,Enum.Material.Metal,steel) end
 if id=="SAHRA" then
  box("PaisagemDeserto",Vector3.new(340,2,300),0,-.1,0,rgb(198,160,110),Enum.Material.Sand,true)
  for _,s in ipairs({-1,1}) do
   house(s*48,-27,24,24,9,rgb(205,126,77),"desert",true)
   house(s*48,28,24,24,9,rgb(226,153,91),"desert",true)
   bridge(s*48,0,30,10,10,0)
   stairs(s*66,-31,10,10,20,180,Enum.Material.Sandstone,rgb(216,154,99))
   stairs(s*66,32,10,10,20,0,Enum.Material.Sandstone,rgb(216,154,99))
   for z=-37,37,74 do box("ToldoMercado",Vector3.new(16,.35,7),s*25,9,z,rgb(112,154,137),Enum.Material.Fabric,true) end
   for n=1,6 do house(s*(105+n%2*23),-75+n*25,18,18,12+n%3*4,rgb(188+n*5,124+n*3,82),"desert",false) end
  end
  cover("FontePraca",0,0,14,3.5,14,rgb(208,160,107),Enum.Material.Sandstone)
  box("AguaFonte",Vector3.new(11,.10,11),0,4.6,0,rgb(73,172,182),Enum.Material.Glass,true).Transparency=.25
  for _,v in ipairs({{-21,18},{23,-15},{-9,43},{11,-43}}) do cover("Caixote",v[1],v[2],7,4,6,wood,Enum.Material.WoodPlanks) end
 elseif id=="NEXUS" then
  local function disc(x,z,diam,height)
   local cf=at(x,1+height-.6,z,0)*CFrame.Angles(0,0,math.pi/2)
   local disk=part(m,"PlataformaCircular",Vector3.new(1.2,diam,diam),cf,steel,Enum.Material.Metal) disk.Shape=Enum.PartType.Cylinder
   local glow=part(m,"AroEnergia",Vector3.new(.3,diam+1,diam+1),at(x,height+.1,z,0)*CFrame.Angles(0,0,math.pi/2),cyan,Enum.Material.Neon,nil,true) glow.Shape=Enum.PartType.Cylinder
   for _,dx in ipairs({-5,5}) do box("SuporteOrbital",Vector3.new(1,7.8,1),x+dx,4.9,z,steel,Enum.Material.Metal) end
  end
  disc(0,0,30,9) disc(-47,0,28,9) disc(47,0,28,9)
  for _,s in ipairs({-1,1}) do
   box("PassarelaOrbital",Vector3.new(26,.6,10),s*24,9.85,0,rgb(74,87,112),Enum.Material.DiamondPlate)
   for _,z in ipairs({-5,5}) do box("TrilhoNeon",Vector3.new(27,.14,.3),s*24,10.1,z,purple,Enum.Material.Neon,true) end
   ramp(0,s*31,s==1 and 180 or 0,9,34,rgb(70,84,111),Enum.Material.DiamondPlate)
   cover("Gerador",s*28,s*35,10,5,8,rgb(53,68,94),Enum.Material.Metal)
   for n=1,4 do local tower=part(m,"TorreCircular",Vector3.new(16+n*4,15,15),at(s*111,8+n*4,-65+n*28,0)*CFrame.Angles(0,0,math.pi/2),rgb(44,56,85),Enum.Material.Metal,nil,true) tower.Shape=Enum.PartType.Cylinder end
  end
  for i=0,11 do local a=i*math.pi/6 part(m,"PortalOrbital",Vector3.new(5,.6,1),at(0,17,0,0)*CFrame.new(math.cos(a)*12,math.sin(a)*12,0)*CFrame.Angles(0,0,a+math.pi/2),purple,Enum.Material.Neon,nil,true) end
 elseif id=="MARINA" then
  box("Oceano",Vector3.new(510,.3,340),0,-7,0,rgb(30,116,151),Enum.Material.Glass,true).Transparency=.18
  for _,s in ipairs({-1,1}) do
   house(s*51,-25,26,29,10,rgb(116,151,167),"industrial",true)
   house(s*51,28,26,24,10,rgb(208,158,75),"industrial",true)
   bridge(s*51,2,29,11,11,0)
   ramp(s*70,-20,180,11,30,rgb(106,125,140),Enum.Material.DiamondPlate)
   for _,z in ipairs({-40,40}) do box("PilarCais",Vector3.new(4,18,4),s*77,-7,z,steel,Enum.Material.Concrete,true) end
   box("Guindaste",Vector3.new(5,42,5),s*100,15,3,rgb(225,166,62),Enum.Material.Metal,true)
   box("Lanca",Vector3.new(5,4,86),s*100,37,0,rgb(239,188,74),Enum.Material.Metal,true)
   box("Cabo",Vector3.new(.25,24,.25),s*100,24,-28,steel,Enum.Material.Metal,true)
   container(s*22,s*35,90,rgb(60,132,157),false)
  end
  cover("MaquinaCentral",0,0,19,5,20,steel,Enum.Material.Metal)
  box("CascoNavio",Vector3.new(39,12,125),146,-1,4,rgb(39,61,83),Enum.Material.Metal,true)
  box("Convés",Vector3.new(34,1,116),146,5.7,4,rgb(147,151,145),Enum.Material.Metal,true)
  for n=-1,1 do box("CabineNavio",Vector3.new(25,8,15),146,10,-20+n*18,rgb(195,207,210),Enum.Material.Metal,true) end
 elseif id=="BASTION" then
  local landscape=box("PaisagemClassica",Vector3.new(340,2,300),0,-.1,0,rgb(100,148,73),Enum.Material.Plastic,true) landscape.TopSurface=Enum.SurfaceType.Studs
  local floor=m:FindFirstChild("Piso") floor.TopSurface=Enum.SurfaceType.Studs floor.Material=Enum.Material.Plastic
  local brick=rgb(141,148,156)
  for _,s in ipairs({-1,1}) do
   for _,z in ipairs({-28,28}) do
    cover("TorreCastelo",s*46,z,20,10,20,brick,Enum.Material.Brick)
    for n=-2,2 do box("Ameia",Vector3.new(3,2.2,3),s*46+n*4,12.1,z-9,brick,Enum.Material.Brick) box("Ameia",Vector3.new(3,2.2,3),s*46+n*4,12.1,z+9,brick,Enum.Material.Brick) end
    stairs(s*64,z,10,10,22,z<0 and 180 or 0,Enum.Material.Brick,brick)
   end
   bridge(s*46,0,36,10,10,0)
   tree(s*23,39,1,true) tree(s*24,-39,.9,true)
   for n=1,4 do part(m,"MontanhaTriangular",Vector3.new(30,20+n*5,40),at(s*(109+n*10),3,-65+n*28,n*25),rgb(73,117+n*5,70),Enum.Material.Grass,"Wedge",true) end
  end
  cover("Baluarte",0,0,19,5.5,19,rgb(111,123,139),Enum.Material.Brick)
  ramp(0,21,180,5.5,25,brick,Enum.Material.Brick) ramp(0,-21,0,5.5,25,brick,Enum.Material.Brick)
  for _,p in ipairs(m:GetChildren()) do if p:IsA("BasePart") and p.CanCollide then p.TopSurface=Enum.SurfaceType.Studs end end
 elseif id=="VERANO" then
  box("BairroExterno",Vector3.new(320,2,290),0,-.1,0,rgb(151,158,155),Enum.Material.Concrete,true)
  for _,side in ipairs({-1,1}) do for n=-1,1 do
   house(side*112,n*46,24,30,16+(n+1)*3,n%2==0 and rgb(178,191,166) or rgb(182,151,143),"urban",false)
   tree(side*91,n*46+12,.9)
  end end
  for _,x in ipairs({-26,26}) do box("Calcada",Vector3.new(12,.35,112),x,1.15,0,rgb(190,191,179),Enum.Material.Concrete) end
  local palette={rgb(202,127,114),rgb(100,159,170),rgb(226,190,114),rgb(142,158,192)} local index=0
  for _,x in ipairs({-53,53}) do for _,z in ipairs({-28,28}) do index+=1 house(x,z,25,26,9,palette[index],"urban",true) stairs(x+(x>0 and 19 or -19),z,10,9,19,0,Enum.Material.Concrete,rgb(177,178,170)) box("PatamarVaranda",Vector3.new(6,.5,10),x+(x>0 and 13.5 or -13.5),10.75,z,rgb(177,178,170),Enum.Material.Concrete) end end
  local function car(x,z,tint,angle)
   local base=at(x,1,z,angle)
   part(m,"Carroceria",Vector3.new(6,1.8,12),base*CFrame.new(0,1.5,0),tint,Enum.Material.Metal)
   part(m,"CabineCarro",Vector3.new(5,1.8,5),base*CFrame.new(0,3.2,.4),tint,Enum.Material.Metal)
   part(m,"VidroCarro",Vector3.new(4.5,1.3,.12),base*CFrame.new(0,3.3,-2.15),rgb(58,104,128),Enum.Material.Glass,nil,true)
   for _,s in ipairs({-1,1}) do for _,vz in ipairs({-3.7,3.7}) do local wheel=part(m,"Roda",Vector3.new(.7,2,2),base*CFrame.new(s*3.1,1,vz),rgb(28,33,39),Enum.Material.SmoothPlastic,nil,true) wheel.Shape=Enum.PartType.Cylinder end end
   for _,s in ipairs({-1,1}) do part(m,"Farol",Vector3.new(1.3,.45,.1),base*CFrame.new(s*1.7,1.8,-6.05),rgb(236,225,174),Enum.Material.Glass,nil,true) end
   table.insert(c.CoverNodes,c.Center+Vector3.new(x+7,4,z))
  end
  car(-11,-35,rgb(233,182,83),10) car(11,32,rgb(183,84,86),-8) car(27,0,rgb(84,152,134),90)
  for _,x in ipairs({-26,26}) do tree(x,-44,.7) tree(x,44,.7) end
  cover("JardineiraCentral",0,0,13,2.5,12,rgb(144,120,97),Enum.Material.Brick) tree(0,0,.8)
  for n=-4,4 do if n~=0 then box("FaixaRua",Vector3.new(.6,.05,8),0,1.04,n*14,rgb(231,212,140),Enum.Material.Concrete,true) end end
 elseif id=="FREIGHT" then
  box("PatioExterno",Vector3.new(310,2,290),0,-.1,0,rgb(112,121,130),Enum.Material.Concrete,true)
  local blue=rgb(67,130,174) local red=rgb(185,91,66) local yellow=rgb(203,168,66) local green=rgb(84,145,119)
  for _,s in ipairs({-1,1}) do
   container(s*49,-28,0,blue,true) container(s*49,28,0,red,true)
   container(s*19,s*38,90,s==1 and yellow or green,false)
   bridge(s*49,0,31,10,8,0)
   ramp(s*70,-25,180,8,27,rgb(115,127,138),Enum.Material.DiamondPlate)
  end
  container(0,0,90,yellow,true)
  for _,s in ipairs({-1,1}) do ramp(s*29,0,s==1 and -90 or 90,8,30,rgb(113,127,138),Enum.Material.DiamondPlate) end
  for n=1,8 do box("PilhaFundo",Vector3.new(15,8+n%2*8,29),104+n%2*19,4+n%2*4,-91+n*24,n%2==0 and blue or red,Enum.Material.Metal,true) end
 end
 local rib=0
 for _,p in ipairs(m:GetChildren()) do
  if p:IsA("BasePart") then
   local important=p.Name=="JanelaRecuada" or p.Name=="Peitoril" or p.Name=="Roda" or p.Name=="VidroCarro" or p.Name=="Corrimao" or p.Name=="GuardaPonte" or p.Name=="Farol"
   if p.Name=="NervuraCarga" then rib+=1 important=rib%3==0 end
   if important then p:SetAttribute("PreviewDetail",true) end
  end
 end
 return true
end
return A
