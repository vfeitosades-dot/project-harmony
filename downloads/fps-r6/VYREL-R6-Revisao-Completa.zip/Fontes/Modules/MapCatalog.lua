-- Original environments inspired by architectural and FPS layout research.
return {
 Order={"SAHRA","NEXUS","MARINA","BASTION","VERANO","FREIGHT","SOLARA","GLACIER","HOSHIMA"},
 Maps={
  SAHRA={Name="SAHRA",Theme="CIDADE / DESERTO",Tagline="Entre becos e telhados.",Description="Casas ocres, patios abertos, escadas e pontes de madeira entre terracos.",Color={239,161,91},Materials="Arenito / reboco / madeira",FloorColor={201,166,116},FloorMaterial="Sand",WallColor={178,119,78},WallMaterial="Sandstone",Lighting="SOLARA"},
  NEXUS={Name="NEXUS",Theme="ORBITAL / NEON",Tagline="Controle a altura.",Description="Torres circulares, plataformas elevadas e passarelas de energia azul e violeta.",Color={123,147,255},Materials="Metal / chapa / neon",FloorColor={26,34,55},FloorMaterial="Slate",WallColor={52,64,87},WallMaterial="Metal",Lighting="HOSHIMA"},
  MARINA={Name="MARINA",Theme="OCEANO / INDUSTRIA",Tagline="O horizonte e a linha de frente.",Description="Complexo sobre o mar, galpoes abertos, rampas, guindastes e um navio ao fundo.",Color={83,205,217},Materials="Metal / concreto / vidro",FloorColor={107,128,140},FloorMaterial="DiamondPlate",WallColor={87,110,124},WallMaterial="Metal",Lighting="GLACIER"},
  BASTION={Name="BASTION",Theme="CLASSICO / CASTELO",Tagline="Defenda sua historia.",Description="Castelo de studs, montanhas triangulares, arvores low-poly e pontes entre ameias.",Color={143,204,96},Materials="Studs / tijolo / grama / madeira",FloorColor={102,151,72},FloorMaterial="Grass",WallColor={123,131,139},WallMaterial="Brick",Lighting="Day"},
  VERANO={Name="VERANO",Theme="BAIRRO / COLORIDO",Tagline="Cada esquina abre uma rota.",Description="Ruas conectadas, fachadas coloridas, carros estacionados, arvores e varandas.",Color={249,200,115},Materials="Asfalto / tijolo / reboco",FloorColor={76,84,94},FloorMaterial="Asphalt",WallColor={139,155,163},WallMaterial="Concrete",Lighting="Day"},
  FREIGHT={Name="FREIGHT",Theme="CARGA / CONTEINERES",Tagline="Mude de rota. Ganhe terreno.",Description="Conteineres coloridos com tuneis, passarelas superiores e rampas entre tres corredores.",Color={233,163,75},Materials="Metal / chapa / concreto",FloorColor={111,120,127},FloorMaterial="Concrete",WallColor={84,109,122},WallMaterial="Metal",Lighting="GLACIER"},

  SOLARA={Name="SOLARA",Theme="TEMPLO / JARDINS",Tagline="A memoria da pedra. O calor do confronto.",Description="Arcos de arenito, patios ajardinados e rotas laterais entre ruinas.",Color={232,180,103},Materials="Arenito / tijolo / madeira / vegetacao"},
  GLACIER={Name="GLACIER",Theme="PORTO / POLAR",Tagline="Aco frio. Decisoes rapidas.",Description="Conteineres de carga, neve e uma plataforma industrial com duas rotas de flanco.",Color={114,214,246},Materials="Neve / metal / chapa / gelo"},
  HOSHIMA={Name="HOSHIMA",Theme="DISTRITO / NEON",Tagline="A cidade nunca deixa de observar.",Description="Mercado noturno, fachadas iluminadas e vielas conectadas a uma praca central.",Color={224,120,228},Materials="Asfalto / tijolo / madeira / vidro"}
 }
}
