local Factory=require(script.Parent.WeaponFactory)
local Spring=require(script.Parent.Spring)
local Recoil=require(script.Parent.Recoil)
local Anim=require(script.Parent.AnimationController)
local Catalog=require(script.Parent.WeaponCatalog)
local V={} V.__index=V
function V.new(camera,id)
 local C=Catalog.Get(id)
 local model=Instance.new("Model") model.Name="R6ViewModel"
 local root=Instance.new("Part") root.Name="CameraRoot" root.Size=Vector3.new(.1,.1,.1) root.CFrame=CFrame.new() root.Transparency=1 root.Anchored=true root.CanCollide=false root.CanQuery=false root.CanTouch=false root.Parent=model model.PrimaryPart=root
 local gun=Factory.Build(model,nil,C.Id) local handle=gun.Handle for _,p in ipairs(gun:GetDescendants()) do if p:IsA("BasePart") then p.CastShadow=false end end
 local joint=Instance.new("Motor6D") joint.Name="WeaponMotor" joint.Part0=root joint.Part1=handle joint.Parent=root
 local function arm(name,point,angle)
  local player=game:GetService("Players").LocalPlayer local character=player and player.Character
  local original=character and character:FindFirstChild(name)
  -- Package meshes can extend far outside an R6 arm's Part bounds.
  -- Use bounded first-person geometry and copy skin colour/clothing only.
  local p=Instance.new("Part") p.Name=name p.Size=Vector3.new(.65,1.65,.65)
  p.Color=original and original.Color or Color3.fromRGB(211,180,153)
  p.Anchored=false p.Material=Enum.Material.SmoothPlastic p.CanCollide=false p.CanQuery=false p.CanTouch=false p.Massless=true p.CastShadow=false p.LocalTransparencyModifier=0 p.Parent=model
  local rot=CFrame.Angles(angle,0,name=="Left Arm" and .25 or -.25)
  local motor=Instance.new("Motor6D") motor.Name=name.."Joint" motor.Part0=handle motor.Part1=p motor.C0=point.CFrame*rot*CFrame.new(0,.825,0) motor.Parent=handle p.CFrame=motor.C0
  return motor
 end
 local right=arm("Right Arm",handle.RightGripPoint,2.2) local left=arm("Left Arm",handle.LeftGrip,2.15)
 local player=game:GetService("Players").LocalPlayer local character=player and player.Character
 local torso=Instance.new("Part") torso.Name="Torso" torso.Size=Vector3.new(2,2,1) torso.Transparency=1 torso.CanCollide=false torso.CanTouch=false torso.CanQuery=false torso.Massless=true torso.Parent=model
 local w=Instance.new("Weld") w.Part0=root w.Part1=torso w.Parent=torso
 local hrp=Instance.new("Part") hrp.Name="HumanoidRootPart" hrp.Size=Vector3.new(.1,.1,.1) hrp.Transparency=1 hrp.CanCollide=false hrp.CanTouch=false hrp.CanQuery=false hrp.Massless=true hrp.Parent=model
 local rw=Instance.new("Weld") rw.Part0=root rw.Part1=hrp rw.Parent=hrp
 local controller=Instance.new("Humanoid") controller.RigType=Enum.HumanoidRigType.R6 controller.RequiresNeck=false controller.DisplayDistanceType=Enum.HumanoidDisplayDistanceType.None controller.EvaluateStateMachine=false controller.PlatformStand=true controller.AutoRotate=false controller.Parent=model
 if character then
  for _,v in ipairs(character:GetChildren()) do
   if v:IsA("Shirt") or v:IsA("BodyColors") then v:Clone().Parent=model end
  end
 end
 local magParts={} for _,p in ipairs(gun:GetDescendants()) do if p:IsA("BasePart") and p:GetAttribute("MagazinePart") then table.insert(magParts,p) end end
 for _,part in ipairs(model:GetDescendants()) do
  if part:IsA("BasePart") then part.CanCollide=false part.CanTouch=false part.CanQuery=false part.Massless=true part.CollisionGroup="FPSViewModel" end
 end
 model.Parent=camera
 return setmetatable({cfg=C,action=handle:FindFirstChild("ActionMotor"),actionBase=handle:FindFirstChild("ActionMotor") and handle.ActionMotor.C0 or CFrame.new(),fireTime=-math.huge,model=model,root=root,gun=gun,joint=joint,right=right,left=left,leftBase=left.C0,leftRotation=CFrame.Angles(2.15,0,.25),mag=handle.MagazineMotor,magBase=handle.MagazineMotor.C0,magAlpha=0,magParts=magParts,recoil=Recoil.new(C.RecoilScale),sway=Spring.new(Vector3.zero,14),aim=0,run=0,dash=0,move=0,jump=0,grounded=true,landing=Spring.new(Vector3.zero,18),phase=0,pose=CFrame.new(),leftPose=CFrame.new(),magPose=CFrame.new()},V)
end
function V:Fire() self.fireTime=workspace:GetServerTimeNow() self.recoil:Fire(self.aim>.5) end
function V:Step(dt,camera,info,mouse)
 local C=self.cfg
 local smoothing=1-math.exp(-dt*16)
 self.aim+=((info.aim and 1 or 0)-self.aim)*(1-math.exp(-dt/C.ADSTime*4)) self.run+=((info.running and 1 or 0)-self.run)*smoothing self.dash+=((info.dash and 1 or 0)-self.dash)*(1-math.exp(-dt*22))
 local gunPose,leftPose,magPose=Anim.Sample(info.state,info.state=="Reloading" and info.time*1.65/C.ReloadTime or info.time)
 if info.state=="Running" then gunPose=CFrame.new(.12,-.22,.12)*CFrame.Angles(-.2,.15,.15) end
 self.pose=self.pose:Lerp(gunPose,smoothing) self.leftPose=self.leftPose:Lerp(leftPose,smoothing) self.magPose=self.magPose:Lerp(magPose,smoothing)
 local targetAlpha=info.state=="Reloading" and Anim.MagazineAlpha(info.time*1.65/C.ReloadTime) or 0 self.magAlpha+=(targetAlpha-self.magAlpha)*smoothing for _,p in ipairs(self.magParts) do if p.Parent then p.Transparency=self.magAlpha end end
 self.mag.C0=self.magBase*self.magPose
 if self.action then self.action.C0=self.actionBase*Anim.ActionSample(C.Kind,workspace:GetServerTimeNow()-self.fireTime) end
 local leftTarget=self.leftBase
 if info.state=="Reloading" then
  local hand=self.gun.Handle.LeftGrip.CFrame:Lerp(self.magBase*self.magPose*CFrame.new(-.25,0,0),Anim.ReloadHandWeight(info.time*1.65/C.ReloadTime))
  leftTarget=hand*self.leftRotation*CFrame.new(0,.825,0) self.left.Transform=CFrame.new()
 else self.left.Transform=self.leftPose end
 self.left.C0=self.left.C0:Lerp(leftTarget,smoothing)
 local kick=self.recoil:Step(dt) self.right.Transform=CFrame.Angles(kick.X*.3,0,0)
 local rate=mouse/math.max(dt,1/300)
 self.sway.target=Vector3.new(math.clamp(-rate.Y*.000012,-.025,.025),math.clamp(-rate.X*.000012,-.025,.025),0)
 local sway=self.sway:Step(dt)*(1-self.aim) self.phase+=dt*(info.running and 11 or 7.5)*math.clamp(info.speed/16,0,1.5)
 local grounded=info.grounded~=false
 if grounded and not self.grounded then self.landing:Impulse(Vector3.new(0,-.7,.22)) end self.grounded=grounded
 self.move+=(math.clamp(info.speed/16,0,1)-self.move)*smoothing
 self.jump+=((grounded and 0 or 1)-self.jump)*smoothing
 local moving=self.move
 local bob=Vector3.new(math.sin(self.phase)*(.018+self.run*.027),math.cos(self.phase*2)*(.018+self.run*.033),0)*moving*(1-self.aim)
 local breath=Vector3.new(0,math.sin(os.clock()*3.49)*.0035,0)*(1-self.aim)
 local offset=CFrame.new(.72,-1.30,-1.85):Lerp(self.gun.Handle.AimPoint.CFrame:Inverse(),self.aim)
 local visualKick=CFrame.new(0,0,kick.X*6)*CFrame.Angles(kick.X,kick.Y,0)
 self.root.CFrame=camera.CFrame
 local land=self.landing:Step(dt)*(1-self.aim*.7)
 local jump=Vector3.new(0,-.035*self.jump,.04*self.jump)
 jump+=Vector3.new(.04,-.09,.12)*self.dash
 if info.casting then
  local weight=math.sin(math.pi*math.clamp(info.castPhase or 0,0,1))
  local offset=info.castIndex==2 and Vector3.new(-.14,-.09,-.25) or info.castIndex==3 and Vector3.new(-.25,.28,-.08) or Vector3.new(-.1,.18,-.22)
  self.left.Transform=CFrame.new(offset*weight)*CFrame.Angles(.2*weight,0,-.15*weight)
 end
 local gait=CFrame.Angles(.012*self.run*math.cos(self.phase*2)+.025*self.jump,0,.018*self.run*math.sin(self.phase))
 self.joint.C0=offset*CFrame.new(bob+breath+land+jump)*CFrame.Angles(sway.X,sway.Y,0)*gait*self.pose*visualKick
 return CFrame.Angles(kick.X,kick.Y,0),self.aim
end
function V:Destroy() if self.model then self.model:Destroy() end end
return V
