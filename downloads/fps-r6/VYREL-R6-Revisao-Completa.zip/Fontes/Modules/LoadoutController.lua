-- Custom loadout: primary, secondary and real Q/E skill shortcuts.
local Players=game:GetService("Players") local Input=game:GetService("UserInputService")
local StarterGui=game:GetService("StarterGui") local C=require(script.Parent.WeaponConfig)
local Catalog=require(script.Parent.WeaponCatalog) local Models=require(script.Parent.WeaponModels) local Agents=require(script.Parent.AgentCatalog) local Tween=game:GetService("TweenService")
local remotes=game:GetService("ReplicatedStorage"):WaitForChild("FPSSystem"):WaitForChild("Remotes")
local L={} local previousCleanup
function L.init()
 if previousCleanup then previousCleanup() end
 local player=Players.LocalPlayer local pg=player:WaitForChild("PlayerGui")
 local alive=true local links={} local charLinks={} local saved={}
 local function connect(list,event,fn) table.insert(list,event:Connect(fn)) end
 local function disconnect(list) for _,c in ipairs(list) do c:Disconnect() end table.clear(list) end
 local function disable(attempt)
  if not alive then return end
  local ok=pcall(function()
   for _,kind in ipairs({Enum.CoreGuiType.Backpack,Enum.CoreGuiType.Health,Enum.CoreGuiType.PlayerList}) do
    if saved[kind]==nil then saved[kind]=StarterGui:GetCoreGuiEnabled(kind) end
    StarterGui:SetCoreGuiEnabled(kind,false)
   end
  end)
  if not ok and attempt<24 then task.delay(.25,function() disable(attempt+1) end) end
 end
 disable(0)
 local oldMode,oldMin,oldMax=player.CameraMode,player.CameraMinZoomDistance,player.CameraMaxZoomDistance
 local function lockCamera()
  if C.AlwaysFirstPerson and alive then player.CameraMode=Enum.CameraMode.LockFirstPerson player.CameraMinZoomDistance=.5 player.CameraMaxZoomDistance=.5 Input.MouseIconEnabled=player:GetAttribute("FPSMenuOpen")==true end
 end
 lockCamera() connect(links,game:GetService("RunService").Heartbeat,lockCamera)
 local old=pg:FindFirstChild("FPSLoadout") if old then old:Destroy() end
 local gui=Instance.new("ScreenGui") gui.Name="FPSLoadout" gui.ResetOnSpawn=false gui.IgnoreGuiInset=true gui.DisplayOrder=19 gui.Parent=pg
 local function frame(parent,name,size,pos,color,alpha)
  local f=Instance.new("Frame") f.Name=name f.Size=size f.Position=pos f.BackgroundColor3=color f.BackgroundTransparency=alpha or 0 f.BorderSizePixel=0 f.Parent=parent return f
 end
 local function label(parent,name,text,size,pos,fontSize)
  local t=Instance.new("TextLabel") t.Name=name t.Text=text t.Size=size t.Position=pos t.BackgroundTransparency=1 t.Font=Enum.Font.GothamMedium t.TextSize=fontSize t.TextColor3=Color3.fromRGB(241,245,250) t.TextXAlignment=Enum.TextXAlignment.Left t.TextStrokeTransparency=.55 t.TextStrokeColor3=Color3.fromRGB(0,0,0) t.Parent=parent return t
 end
 local viewport=workspace.CurrentCamera and workspace.CurrentCamera.ViewportSize
 local compact=Input.TouchEnabled or viewport and viewport.X<1000
 local width=compact and 46 or 66 local gap=compact and 5 or 6 local slotHeight=compact and 56 or 72
 local first=18+width*4+gap*3
 local slot=Instance.new("TextButton") slot.Name="PrimarySlot" slot.Text="" slot.Size=UDim2.fromOffset(width,slotHeight) slot.Position=UDim2.new(1,-first,1,-slotHeight-28) slot.BackgroundColor3=Color3.fromRGB(20,24,30) slot.BackgroundTransparency=.4 slot.BorderSizePixel=0 slot.Parent=gui
 local corner=Instance.new("UICorner") corner.CornerRadius=UDim.new(0,5) corner.Parent=slot
 local border=Instance.new("UIStroke") border.Thickness=1 border.Transparency=.65 border.Color=Color3.fromRGB(220,230,240) border.Parent=slot
 local selected=frame(slot,"Selection",UDim2.new(1,0,0,2),UDim2.new(0,0,1,-2),Color3.fromRGB(245,248,255))
 label(slot,"Key","1",UDim2.fromOffset(16,18),UDim2.new(0,5,1,-20),12)
 local name=label(slot,"Weapon",C.Name,UDim2.new(1,-8,0,16),UDim2.fromOffset(4,2),9) name.Visible=false
 local caption=label(slot,"State","EQUIPAR",UDim2.fromOffset(68,14),UDim2.fromOffset(28,33),9) caption.TextColor3=Color3.fromRGB(152,166,180) caption.Visible=false
 -- Original vector silhouette of this rifle, no external icon assets.
 local icon=frame(slot,"RifleIcon",UDim2.fromOffset(70,24),UDim2.new(.5,compact and -20 or -30,.5,-10),Color3.fromRGB(255,255,255),1)
 for i,d in ipairs({{17,7,30,8},{46,8,19,3},{63,7,5,5},{8,9,10,7},{2,8,7,12},{21,15,5,7},{32,15,7,8},{23,4,17,2}}) do
  frame(icon,"Piece"..i,UDim2.fromOffset(d[3],d[4]),UDim2.fromOffset(d[1],d[2]),Color3.fromRGB(226,234,242))
 end
 local scale=Instance.new("UIScale") scale.Scale=compact and .58 or .85 scale.Parent=icon
 local secondary=Instance.new("TextButton") secondary.Name="SecondarySlot" secondary.Text="" secondary.Size=UDim2.fromOffset(width,slotHeight) secondary.Position=UDim2.new(1,-first+width+gap,1,-slotHeight-28) secondary.BackgroundColor3=Color3.fromRGB(20,24,30) secondary.BackgroundTransparency=.55 secondary.BorderSizePixel=0 secondary.Parent=gui
 local secondaryStroke=Instance.new("UIStroke") secondaryStroke.Color=Color3.fromRGB(245,248,255) secondaryStroke.Transparency=.8 secondaryStroke.Parent=secondary
 label(secondary,"Key","2",UDim2.fromOffset(16,18),UDim2.new(0,5,1,-20),12)
 local secondaryIcon=frame(secondary,"PistolIcon",UDim2.fromOffset(34,11),UDim2.new(.5,-17,.5,-8),Color3.fromRGB(206,217,230))
 local grip=frame(secondaryIcon,"Grip",UDim2.fromOffset(9,17),UDim2.fromOffset(4,8),Color3.fromRGB(206,217,230)) grip.Rotation=-12
 local quick={}
 for i=3,4 do
  local button=Instance.new("TextButton") button.Name="AbilityQuick"..(i-2) button.Text="" button.Active=true button.Size=UDim2.fromOffset(width,slotHeight) button.Position=UDim2.new(1,-first+(i-1)*(width+gap),1,-slotHeight-28) button.BackgroundColor3=Color3.fromRGB(25,31,43) button.BackgroundTransparency=.35 button.BorderSizePixel=0 button.Parent=gui
  local corner=Instance.new("UICorner") corner.CornerRadius=UDim.new(0,6) corner.Parent=button
  local outline=Instance.new("UIStroke") outline.Thickness=1.5 outline.Transparency=.35 outline.Color=Color3.fromRGB(200,214,231) outline.Parent=button
  label(button,"Key",i==3 and "Q" or "E",UDim2.fromOffset(18,18),UDim2.new(0,5,1,-20),12)
  local shape=frame(button,"SkillIcon",UDim2.fromOffset(18,24),UDim2.new(.5,-9,.5,-17),Color3.fromRGB(111,222,243)) shape.Rotation=i==3 and 30 or -30
  local inner=frame(shape,"Cut",UDim2.fromOffset(8,14),UDim2.fromOffset(5,5),Color3.fromRGB(25,31,43))
  local timer=label(button,"Cooldown","",UDim2.new(1,0,0,26),UDim2.fromOffset(0,14),21) timer.TextXAlignment=Enum.TextXAlignment.Center
  quick[i-2]={button=button,timer=timer,icon=shape}
  connect(links,button.Activated,function()
   if player:GetAttribute("FPSMode")=="Lobby" or player:GetAttribute("FPSMenuOpen") or player:GetAttribute("FPSWorldLoading") then return end
   local cam=workspace.CurrentCamera if cam then remotes.Skill:FireServer(i-2,cam.CFrame.LookVector) end
  end)
 end
 local function silhouette(parent,id)
  parent:ClearAllChildren() parent.BackgroundTransparency=1
  local rows=Models.Models[id] or Models.Models.VETOR local minZ,maxZ,minY,maxY=math.huge,-math.huge,math.huge,-math.huge
  for _,r in ipairs(rows) do if (r.alpha or 0)<1 then minZ=math.min(minZ,r.pos[3]-r.size[3]/2) maxZ=math.max(maxZ,r.pos[3]+r.size[3]/2) minY=math.min(minY,r.pos[2]-r.size[2]/2) maxY=math.max(maxY,r.pos[2]+r.size[2]/2) end end
  local spanZ=math.max(1,maxZ-minZ) local spanY=math.max(.7,maxY-minY)
  for _,r in ipairs(rows) do if (r.alpha or 0)<1 and r.size[2]*r.size[3]>.018 then
   local f=Instance.new("Frame") f.Name="WeaponShape" f.Size=UDim2.fromScale(r.size[3]/spanZ,r.size[2]/spanY) f.Position=UDim2.fromScale((maxZ-r.pos[3]-r.size[3]/2)/spanZ,(maxY-r.pos[2]-r.size[2]/2)/spanY) f.BackgroundColor3=Color3.fromRGB(234,242,249) f.BorderSizePixel=0 f.Active=false f.Parent=parent
  end end
 end
 icon.Size=UDim2.fromOffset(width-10,28) icon.Position=UDim2.new(.5,-(width-10)/2,.5,-14)
 local iconId local secondaryId
 local healthWidth=compact and 130 or 290
 local health=frame(gui,"Health",UDim2.fromOffset(healthWidth,compact and 24 or 30),UDim2.new(0,compact and 18 or 32,1,compact and -132 or -76),Color3.fromRGB(16,19,20),.05)
 local hc=Instance.new("UICorner") hc.CornerRadius=UDim.new(1,0) hc.Parent=health
 local outline=Instance.new("UIStroke") outline.Thickness=2 outline.Transparency=.15 outline.Color=Color3.fromRGB(0,0,0) outline.Parent=health
 local track=frame(health,"Track",UDim2.new(1,-10,1,-10),UDim2.fromOffset(5,5),Color3.fromRGB(42,70,27),0)
 local tc=Instance.new("UICorner") tc.CornerRadius=UDim.new(1,0) tc.Parent=track
 local fill=frame(track,"Fill",UDim2.fromScale(1,1),UDim2.fromScale(0,0),Color3.fromRGB(88,255,34))
 local fc=Instance.new("UICorner") fc.CornerRadius=UDim.new(1,0) fc.Parent=fill
 local sheen=Instance.new("UIGradient") sheen.Color=ColorSequence.new(Color3.fromRGB(141,255,72),Color3.fromRGB(50,206,19)) sheen.Rotation=90 sheen.Parent=fill
 label(health,"PlayerName",player.DisplayName or player.Name or "VOCE",UDim2.new(1,0,0,16),UDim2.fromOffset(2,-21),10)
 local shield=label(health,"Shield","",UDim2.fromOffset(70,18),UDim2.new(1,-70,0,-24),11) shield.TextXAlignment=Enum.TextXAlignment.Right shield.TextColor3=Color3.fromRGB(116,218,246)
 local hp=label(health,"Value","100",UDim2.new(1,-15,1,0),UDim2.fromOffset(0,0),compact and 11 or 14) hp.TextXAlignment=Enum.TextXAlignment.Right hp.TextColor3=Color3.fromRGB(33,92,14) hp.ZIndex=3
 local function humanoid() local char=player.Character return char and char:FindFirstChildOfClass("Humanoid") end
 local function rifle()
  local char=player.Character local bag=player:FindFirstChild("Backpack")
  local tool=char and char:FindFirstChild("Rifle") or bag and bag:FindFirstChild("Rifle")
  return tool and tool:IsA("Tool") and tool or nil
 end
 local function refresh()
  if not alive then return end
  local tool=rifle() local equipped=tool and tool.Parent==player.Character
  local activeId=tool and tool:GetAttribute("WeaponId") or player:GetAttribute("FPSWeapon") or "VETOR"
  local isSecondary=Catalog.Get(activeId).Kind=="Pistol"
  slot.Active=tool~=nil selected.Visible=equipped==true and not isSecondary border.Transparency=equipped and not isSecondary and .15 or .7
  secondaryStroke.Transparency=equipped and isSecondary and .15 or .8
  name.Text=tool and Catalog.Get(activeId).Name or "AGUARDANDO" caption.Text=equipped and "EQUIPADO" or "EQUIPAR"
  local h=humanoid() local value=h and math.max(0,h.Health) or 0 local max=h and math.max(1,h.MaxHealth) or 100
  hp.Text=tostring(math.ceil(value)) Tween:Create(fill,TweenInfo.new(.12),{Size=UDim2.fromScale(math.clamp(value/max,0,1),1)}):Play()
  local primary=player:GetAttribute("FPSPrimary") or "VETOR" local secondaryWeapon=player:GetAttribute("FPSSecondary") or "NOMAD"
  if iconId~=primary then iconId=primary silhouette(icon,primary) end
  if secondaryId~=secondaryWeapon then secondaryId=secondaryWeapon secondaryIcon.Size=UDim2.fromOffset(width-12,28) secondaryIcon.Position=UDim2.new(.5,-(width-12)/2,.5,-14) silhouette(secondaryIcon,secondaryWeapon) end
  fill.BackgroundColor3=value<=max*.3 and Color3.fromRGB(255,112,100) or Color3.fromRGB(88,255,34)
 end
 local function toggle(index)
  if player:GetAttribute("FPSMode")=="Lobby" or player:GetAttribute("FPSGameMenu")==true or player:GetAttribute("FPSWorldLoading")==true then return end
  local h=humanoid() local tool=rifle() if not h or h.Health<=0 or not tool then return end
  local desired=index==2 and (player:GetAttribute("FPSSecondary") or "NOMAD") or (player:GetAttribute("FPSPrimary") or "VETOR")
  if (tool:GetAttribute("WeaponId") or "VETOR")~=desired then remotes.Session:FireServer("EquipSlot",index)
  elseif tool.Parent~=player.Character then h:EquipTool(tool) end
  task.defer(refresh)
 end
 connect(links,slot.Activated,function() toggle(1) end) connect(links,secondary.Activated,function() toggle(2) end)
 connect(links,Input.InputBegan,function(i,processed)
  if processed or Input:GetFocusedTextBox() then return end
  if i.KeyCode==Enum.KeyCode.One then toggle(1) elseif i.KeyCode==Enum.KeyCode.Two then toggle(2)
  elseif i.KeyCode==Enum.KeyCode.ButtonR1 then local tool=rifle() toggle(tool and Catalog.Get(tool:GetAttribute("WeaponId")).Kind=="Pistol" and 1 or 2) end
 end)
 local function bindCharacter(char)
  lockCamera()
  disconnect(charLinks)
  if not char then refresh() return end
  connect(charLinks,char.ChildAdded,function() task.defer(refresh) end)
  connect(charLinks,char.ChildRemoved,function() task.defer(refresh) end)
  local h=char:WaitForChild("Humanoid",10)
  if h and player.Character==char then
   connect(charLinks,h.HealthChanged,refresh) connect(charLinks,h.Died,refresh)
  end
  refresh()
 end
 local bag=player:WaitForChild("Backpack",10)
 if bag then connect(links,bag.ChildAdded,refresh) connect(links,bag.ChildRemoved,function() task.defer(refresh) end) end
 connect(links,player.CharacterAdded,bindCharacter)
 if player.Character then bindCharacter(player.Character) else refresh() end
 local elapsed=0
 connect(links,game:GetService("RunService").Heartbeat,function(dt)
  elapsed+=dt if elapsed<.1 then return end elapsed=0
  if (player:GetAttribute("FPSPrimary") or "VETOR")~=iconId or (player:GetAttribute("FPSSecondary") or "NOMAD")~=secondaryId then refresh() end
  local agent=Agents.Agents[player:GetAttribute("FPSAgent") or "ION"] local now=workspace:GetServerTimeNow()
  for i,t in ipairs(quick) do local left=math.max(0,(player:GetAttribute("FPSNextSkill"..i) or 0)-now) t.timer.Text=left>.1 and tostring(math.ceil(left)) or "" t.icon.Visible=left<=.1 t.icon.BackgroundColor3=Color3.fromRGB(table.unpack(agent.Color)) end
  local char=player.Character local amount=char and (char:GetAttribute("FPSShieldUntil") or 0)>now and (char:GetAttribute("FPSShield") or 0) or 0 shield.Text=amount>0 and "+"..math.floor(amount) or ""
 end)
 local function cleanup()
  if not alive then return end alive=false disconnect(links) disconnect(charLinks) gui:Destroy()
  for kind,value in pairs(saved) do pcall(function() StarterGui:SetCoreGuiEnabled(kind,value) end) end
  player.CameraMode=oldMode or Enum.CameraMode.Classic if oldMin then player.CameraMinZoomDistance=oldMin end if oldMax then player.CameraMaxZoomDistance=oldMax end
 end
 previousCleanup=cleanup return cleanup
end
return L
