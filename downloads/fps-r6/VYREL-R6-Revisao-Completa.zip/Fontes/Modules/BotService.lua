local Players=game:GetService("Players") local Run=game:GetService("RunService") local CS=game:GetService("CollectionService") local Path=game:GetService("PathfindingService") local Debris=game:GetService("Debris")
local system=game:GetService("ReplicatedStorage"):WaitForChild("FPSSystem")
local Avatar=require(script.Parent.AvatarAppearance) local World=require(script.Parent.WorldService) local Factory=require(script.Parent.WeaponFactory) local Catalog=require(script.Parent.WeaponCatalog) local Combat=require(script.Parent.CombatService) local Skills=require(script.Parent.SkillService) local Anim=require(script.Parent.AnimationController)
local B={} local bots={} local spawning={} local started=false local random=Random.new()
local function now() return workspace:GetServerTimeNow() end
local function participants(mode) local out={} for _,p in ipairs(Players:GetPlayers()) do if p:GetAttribute("FPSMode")==mode then table.insert(out,p) end end return out end
local function remove(key,b) if b and b.model.Parent then b.model:Destroy() end bots[key]=nil end
local function spawn(mode,index,owner)
 local key=mode..index if spawning[key] or bots[key] then return end spawning[key]=true
 local id=owner.UserId if id<=0 and game.CreatorType==Enum.CreatorType.User and game.CreatorId>0 then id=game.CreatorId end
 local model=Avatar.Create(id) if not model or #participants(mode)==0 then if model then model:Destroy() end spawning[key]=nil return end
 local root=model:FindFirstChild("HumanoidRootPart") local h=model:FindFirstChildOfClass("Humanoid") local torso=model:FindFirstChild("Torso")
 if not root or not h or not torso then model:Destroy() spawning[key]=nil return end
 local stationary=mode=="Training" and index<=2
 model.Name=(stationary and "ALVO " or "SENTINELA ")..string.format("%02d",index)
 h.DisplayName=model.Name h.MaxHealth=100 h.Health=100 h.BreakJointsOnDeath=false h.WalkSpeed=stationary and 0 or 18 h.JumpPower=50
 model:SetAttribute("FPSArena",mode)
 model:SetAttribute("FPSBotBaseSpeed",stationary and 0 or 18) model:SetAttribute("FPSMode",mode) model:SetAttribute("FPSMatchId",mode) model:SetAttribute("FPSSide","Hostile")
 local weapon=Catalog.Order[(index-1)%#Catalog.Order+1] if mode=="Training" then weapon=index==3 and "NOMAD" or "VETOR" end
 local cfg=Catalog.Get(weapon)
 local tool=Instance.new("Tool") tool.Name="Rifle" tool.CanBeDropped=false tool.RequiresHandle=true Factory.Mount(tool,weapon)
 tool:SetAttribute("EquippedAt",now()-1) tool:SetAttribute("ReloadEnd",0) tool:SetAttribute("AimPitch",0) tool.Parent=model
 local grip=Instance.new("Motor6D") grip.Name="WorldGrip" grip.Part0=torso grip.Part1=tool.Handle grip.C0=Anim.WorldBase(torso) grip.Parent=tool.Handle
 local arm=model:FindFirstChild("Right Arm") if arm then
  local function clear(j) if j.Name=="RightGrip" and j:IsA("JointInstance") and j.Part1==tool.Handle then j:Destroy() end end
  for _,j in ipairs(arm:GetChildren()) do clear(j) end arm.ChildAdded:Connect(clear)
 end
 for _,p in ipairs(model:GetDescendants()) do if p:IsA("BasePart") then p.CollisionGroup="Characters" if p.Parent and p.Parent:IsA("Accessory") then p.CanQuery=false end end end
 model.PrimaryPart=root model.Parent=workspace
 if not World.Place(model,model,false) then model:Destroy() spawning[key]=nil return end root.Anchored=stationary pcall(function() if not stationary then root:SetNetworkOwner(nil) end end)
 CS:AddTag(model,"FPSDemoBot")
 local shield=Instance.new("ForceField") shield.Visible=false shield.Parent=model Debris:AddItem(shield,1.5)
 local bot={mapRevision=World.Revision[mode],model=model,h=h,root=root,tool=tool,cfg=cfg,ammo=cfg.Magazine,stationary=stationary,mode=mode,key=key,lastShot=-100,nextThink=0,burst=0,pause=0,pathAt=0,seenAt=0,difficulty=mode=="Training" and "Easy" or "Normal"}
 bots[key]=bot spawning[key]=nil
 h.Died:Connect(function() bot.dead=true Debris:AddItem(model,1.5) task.delay(2,function() if bots[key]==bot then bots[key]=nil end end) end)
end
local function target(bot)
 local nearest local distance=math.huge local list={}
 for _,p in ipairs(participants(bot.mode)) do if p.Character then table.insert(list,p.Character) end end
 for _,m in ipairs(CS:GetTagged("VyrelDecoy")) do if m.Parent then table.insert(list,m) end end
 for _,m in ipairs(list) do local root=m:FindFirstChild("HumanoidRootPart") local h=m:FindFirstChildOfClass("Humanoid")
  if root and h and h.Health>0 and Combat.Allowed(bot.model,m) then
   local d=(root.Position-bot.root.Position).Magnitude
   if d<105 and d<distance and Combat.Visible(bot.root.Position+Vector3.new(0,1,0),root.Position,{bot.model,m}) and not Skills.SmokeBlocks(bot.root.Position,root.Position,bot.mode) then nearest=m distance=d end
  end
 end return nearest,distance
end
local function pathTo(bot,goal)
 if bot.busyPath or now()-bot.pathAt<1.4 then return end bot.pathAt=now() bot.busyPath=true
 task.spawn(function()
  local path=Path:CreatePath({AgentRadius=2,AgentHeight=5,AgentCanJump=true,WaypointSpacing=5})
  local ok=pcall(function() path:ComputeAsync(bot.root.Position,goal) end)
  if ok and path.Status==Enum.PathStatus.Success and bot.model.Parent then bot.route=path:GetWaypoints() bot.waypoint=2 end bot.busyPath=false
 end)
end
local function walk(bot,goal)
 if bot.stationary then return end
 if Combat.Visible(bot.root.Position,goal,{bot.model}) then bot.h:MoveTo(goal) bot.route=nil
 else
  pathTo(bot,goal)
  local point=bot.route and bot.route[bot.waypoint or 2]
  if point then
   if (bot.root.Position-point.Position).Magnitude<3 then bot.waypoint+=1 else bot.h:MoveTo(point.Position) if point.Action==Enum.PathWaypointAction.Jump then bot.h.Jump=true end end
  end
 end
end
local function shoot(bot,enemy)
 local time=now() if time<bot.pause or time-bot.lastShot<math.max(bot.cfg.FireInterval,.13) then return end
 if bot.ammo<=0 then
  if not bot.reloadEnd then bot.reloadEnd=time+bot.cfg.ReloadTime bot.tool:SetAttribute("ReloadEnd",bot.reloadEnd)
  elseif time>=bot.reloadEnd then bot.ammo=bot.cfg.Magazine bot.reloadEnd=nil bot.tool:SetAttribute("ReloadEnd",0) end return
 end
 local head=bot.model:FindFirstChild("Head") local victim=enemy:FindFirstChild(random:NextNumber()<.12 and "Head" or "Torso") if not head or not victim then return end
 if (victim.Position-head.Position).Magnitude<.1 then return end
 local spread=bot.difficulty=="Easy" and 6 or 3.2 local basis=CFrame.lookAt(head.Position,victim.Position)
 local direction=(basis*CFrame.Angles(math.rad(random:NextNumber(-spread,spread)),math.rad(random:NextNumber(-spread,spread)),0)).LookVector
 local hit=workspace:Raycast(head.Position,direction*bot.cfg.Range,Combat.Params({bot.model})) local endpoint=hit and hit.Position or head.Position+direction*bot.cfg.Range
 if hit and not Combat.Barrier(hit.Instance,bot.cfg.Damage) then
  local model=hit.Instance:FindFirstAncestorOfClass("Model") local critical=hit.Instance.Name=="Head"
  Combat.Apply(bot.model,model,bot.cfg.Damage*(bot.difficulty=="Easy" and .65 or .9)*(critical and bot.cfg.Critical or 1),critical,endpoint)
 end
 bot.lastShot=time bot.ammo-=1 bot.burst+=1 if bot.burst>=3 then bot.pause=time+(bot.difficulty=="Easy" and 1.1 or .65) bot.burst=0 end
 local muzzle=bot.tool.Handle:FindFirstChild("Muzzle") local start=muzzle and muzzle.WorldPosition or head.Position
 bot.model:SetAttribute("FPSLastShotAt",time) Skills.OnShot(bot.model,start)
 system.Remotes.WeaponFX:FireAllClients(-10000-tonumber(bot.key:match("%d+")),start,endpoint,hit and hit.Normal or nil,hit and hit.Material or nil)
end
local function think(bot)
 if bot.dead or not bot.model.Parent or bot.h.Health<=0 then return end
 if bot.mapRevision~=World.Revision[bot.mode] then remove(bot.key,bot) return end
 if World.OutOfBounds(bot.model,bot.model) then World.Place(bot.model,bot.model,false) end
 if bot.stationary then return end
 local enemy,distance=target(bot)
 local base=enemy and 18 or 22 bot.model:SetAttribute("FPSBotBaseSpeed",base)
 local mult=(bot.model:GetAttribute("FPSSlowUntil") or 0)>now() and .86 or 1
 bot.h.WalkSpeed=base*mult bot.tool:SetAttribute("Running",enemy==nil)
 if enemy then
  if bot.target~=enemy then bot.target=enemy bot.seenAt=now() end
  local er=enemy:FindFirstChild("HumanoidRootPart") local p=bot.root.Position
  if er then bot.lastKnown=er.Position bot.lastKnownAt=now() end
  if er then
   bot.h.AutoRotate=false local facing=Vector3.new(er.Position.X,p.Y,er.Position.Z) if (facing-p).Magnitude>.1 then bot.root.CFrame=bot.root.CFrame:Lerp(CFrame.lookAt(p,facing),.45) end
   bot.tool:SetAttribute("AimPitch",math.clamp(math.atan2(er.Position.Y-p.Y,distance),-.7,.7))
   if bot.h.Health<35 or bot.reloadEnd then
    local best local score=math.huge
    for _,node in ipairs(World.Cover[bot.mode]) do local d=(node-p).Magnitude if d<score and not Combat.Visible(er.Position,node,{bot.model,enemy}) then best=node score=d end end
    if best then walk(bot,best) else walk(bot,p+(p-er.Position).Unit*8) end
   else
    local strafe=bot.root.CFrame.RightVector*(math.sin(now()*1.6+tonumber(bot.key:match("%d+")))>0 and 7 or -7)
    if distance>40 then walk(bot,er.Position+(p-er.Position).Unit*25+strafe) else walk(bot,p+strafe) end
   end
   if now()-bot.seenAt>(bot.difficulty=="Easy" and .6 or .3) then shoot(bot,enemy) end
  end
 else
  bot.target=nil bot.h.AutoRotate=true
  if not bot.goal or (bot.root.Position-bot.goal).Magnitude<5 or now()-(bot.goalAt or 0)>6 then local nodes=World.Cover[bot.mode] bot.goal=not bot.goal and World.Centers[bot.mode]+Vector3.new(0,4,0) or nodes[random:NextInteger(1,#nodes)] bot.goalAt=now() end
  walk(bot,bot.lastKnown and now()-(bot.lastKnownAt or 0)<2.5 and bot.lastKnown or bot.goal)
  if bot.ammo<bot.cfg.Magazine*.3 and not bot.reloadEnd then bot.reloadEnd=now()+bot.cfg.ReloadTime bot.tool:SetAttribute("ReloadEnd",bot.reloadEnd) end
 end
 if bot.reloadEnd and now()>=bot.reloadEnd then bot.ammo=bot.cfg.Magazine bot.reloadEnd=nil bot.tool:SetAttribute("ReloadEnd",0) end
end
function B.Init()
 if started then return end started=true World.Build()
 local elapsed=0 Run.Heartbeat:Connect(function(dt)
  for _,bot in pairs(bots) do if now()>=bot.nextThink then bot.nextThink=now()+.15 think(bot) end end
  elapsed+=dt if elapsed<1 then return end elapsed=0
  for _,mode in ipairs({"Casual","Training"}) do
   local list=participants(mode) local desired=#list==0 and 0 or mode=="Training" and 3 or math.min(6,#list*2)
   for i=1,6 do local key=mode..i if i<=desired then if not bots[key] then task.spawn(spawn,mode,i,list[1]) end elseif bots[key] then remove(key,bots[key]) end end
  end
 end)
end
return B
