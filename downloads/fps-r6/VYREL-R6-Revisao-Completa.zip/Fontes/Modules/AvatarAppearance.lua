-- Executado no servidor. A aparencia vem da conta; so o rig e convertido em R6.
local Players=game:GetService("Players")
local A={} local templates={} local loading={}
local function neutral()
 local d=Instance.new("HumanoidDescription")
 local skin=Color3.fromRGB(211,180,153)
 d.HeadColor=skin d.LeftArmColor=skin d.RightArmColor=skin
 d.TorsoColor=Color3.fromRGB(55,65,81) d.LeftLegColor=Color3.fromRGB(31,41,55) d.RightLegColor=d.LeftLegColor
 return d
end
function A.Create(userId)
 userId=tonumber(userId) or 0
 while loading[userId] do task.wait(.1) end
 local cached=templates[userId]
 if cached and (not cached:GetAttribute("AppearanceFallback") or userId<=0) then return cached:Clone() end
 loading[userId]=true
 local description local fallback=false
 if userId>0 then
  for attempt=1,3 do local ok,result=pcall(Players.GetHumanoidDescriptionFromUserIdAsync,Players,userId) if ok then description=result break end if attempt<3 then task.wait(attempt) end end
 end
 if not description then description=neutral() fallback=true end
 local ok,model=pcall(Players.CreateHumanoidModelFromDescriptionAsync,Players,description,Enum.HumanoidRigType.R6)
 description:Destroy()
 if not ok then loading[userId]=nil return nil,tostring(model) end
 for _,v in ipairs(model:GetDescendants()) do if v:IsA("Script") or v:IsA("LocalScript") then v:Destroy() end end
 for _,v in ipairs(model:GetDescendants()) do if v:IsA("BasePart") then
  local accessory=v.Parent and v.Parent:IsA("Accessory") v.CanCollide=not accessory and (v.Name=="Torso" or v.Name=="Head") v.CanQuery=not accessory and v.Name~="HumanoidRootPart" v.Massless=accessory==true
 end end
 local h=model:FindFirstChildOfClass("Humanoid") if h then h.Health=h.MaxHealth h.CameraOffset=Vector3.zero h.HipHeight=0 h.EvaluateStateMachine=true h.PlatformStand=false h.Sit=false end
 model:SetAttribute("AppearanceFallback",fallback) model:SetAttribute("AppearanceUserId",userId)
 if cached then cached:Destroy() end templates[userId]=model loading[userId]=nil
 return model:Clone()
end
function A.Clear(userId) local m=templates[userId] if m then m:Destroy() templates[userId]=nil end end
return A
