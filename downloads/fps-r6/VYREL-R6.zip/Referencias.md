# Pesquisa visual e de sistemas - VYREL

Referencias consultadas em 03/11/2026; usadas para analise, sem importar artes ou personagens.

- Loja RIVALS: https://robloxrivals.fandom.com/wiki/Shop
  Resultado indexado e imagens de loja: categorias, catalogo, chaves, itens possuidos e desbloqueio. A pagina direta retornou 402.
- Imagem da loja (abas e grade de itens): https://progameguides.com/roblox/roblox-rivals-update-13/
- Economia de chaves / desbloqueios: https://play.google.com/store/apps/editorial?hl=en-US&id=mc_games_editorialevergreen_postinstall_all_about_rivals_in_roblox_gamehub_fcp
- Agentes oficiais VALORANT: https://playvalorant.com/en-us/agents/
- Tipos de habilidades: https://wiki.playvalorant.com/en-us/Abilities
- Referencia do menu enviada pelo usuario: navegacao superior, grande area central e paineis laterais.

VYREL: menu, modelos e habilidades originais. Loja usa creditos de jogo e compra deterministica; nao depende de IDs de produtos pagos. Treino permite experimentar armamento. Sem roupas de personagem impostas ao avatar.
