-- Server-owned session statistics and a real four-minute round clock.
local Players=game:GetService("Players") local Run=game:GetService("RunService")
local system=game:GetService("ReplicatedStorage"):WaitForChild("FPSSystem")
local M={} local started=false local duration=240
local function add(p,key,n) p:SetAttribute(key,(p:GetAttribute(key) or 0)+n) end
local function rewards(p)
 for _,d in ipairs({{"Equip",p:GetAttribute("FPSHasEquipped") and 1 or 0,1,25},{"Kills",p:GetAttribute("FPSKills") or 0,5,75},{"Rounds",p:GetAttribute("FPSRounds") or 0,1,50}}) do
  if d[2]>=d[3] and not p:GetAttribute("FPSReward"..d[1]) then p:SetAttribute("FPSReward"..d[1],true) add(p,"FPSXP",d[4]) end
 end
end
local function bind(p)
 for _,key in ipairs({"FPSKills","FPSRoundKills","FPSDeaths","FPSRounds","FPSWins","FPSXP"}) do if p:GetAttribute(key)==nil then p:SetAttribute(key,0) end end
 rewards(p)
end
function M.Init()
 if started then return end started=true
 system:SetAttribute("FPSRoundEnd",workspace:GetServerTimeNow()+duration) system:SetAttribute("FPSRound",1)
 Players.PlayerAdded:Connect(bind) for _,p in ipairs(Players:GetPlayers()) do bind(p) end
 Run.Heartbeat:Connect(function()
  if workspace:GetServerTimeNow()<(system:GetAttribute("FPSRoundEnd") or math.huge) then return end
  local best=0 local winners={}
  for _,p in ipairs(Players:GetPlayers()) do
   local score=p:GetAttribute("FPSRoundKills") or 0
   if score>best then best=score winners={p} elseif score==best and score>0 then table.insert(winners,p) end
  end
  if #winners==1 then add(winners[1],"FPSWins",1) end
  for _,p in ipairs(Players:GetPlayers()) do if p:GetAttribute("FPSMode")==nil then add(p,"FPSRounds",1) p:SetAttribute("FPSRoundKills",0) rewards(p) end end
  system:SetAttribute("FPSRound",(system:GetAttribute("FPSRound") or 1)+1)
  system:SetAttribute("FPSRoundEnd",workspace:GetServerTimeNow()+duration)
 end)
end
function M.Equip(p) M.Init() p:SetAttribute("FPSHasEquipped",true) rewards(p) end
function M.Kill(p,model,critical)
 M.Init() add(p,"FPSKills",1) add(p,"FPSRoundKills",1) add(p,"FPSXP",10) rewards(p)
 local victim=Players:GetPlayerFromCharacter(model) if victim then add(victim,"FPSDeaths",1) end
 system.Remotes.MatchFeed:FireAllClients(p.DisplayName or p.Name,victim and (victim.DisplayName or victim.Name) or model.Name,critical==true,p:GetAttribute("FPSMatchId"))
 if p:GetAttribute("FPSMode") then require(script.Parent.SessionService).RecordKill(p,victim) end
end
function M.Complete(p) rewards(p) end
return M
