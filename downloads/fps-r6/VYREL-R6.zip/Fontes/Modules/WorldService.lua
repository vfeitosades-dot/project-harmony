local W={Centers={Lobby=Vector3.new(0,0,260),Casual=Vector3.new(0,0,0),Training=Vector3.new(500,0,0)},Cover={},Spawns={}} local built=false
local function part(parent,name,size,cf,color,material,shape)
 local p=Instance.new(shape=="Wedge" and "WedgePart" or "Part") p.Name=name p.Size=size p.CFrame=cf p.Color=color p.Material=material or Enum.Material.Concrete p.Anchored=true p.TopSurface=Enum.SurfaceType.Smooth p.BottomSurface=Enum.SurfaceType.Smooth p.Parent=parent return p
end
local stone=Color3.fromRGB(120,130,142) local trim=Color3.fromRGB(41,49,65) local cyan=Color3.fromRGB(75,229,239) local coral=Color3.fromRGB(242,115,106)
local function arena(root,key,center)
 local m=Instance.new("Model") m.Name=key m.Parent=root W.Centers[key]=center W.Cover[key]={} W.Spawns[key]={}
 local function at(v) return CFrame.new(center+v) end
 local floor=part(m,"Piso",Vector3.new(148,2,148),at(Vector3.zero),Color3.fromRGB(155,164,173)) floor.TopSurface=Enum.SurfaceType.Studs
 for _,d in ipairs({{0,5,-74,148,10,2},{0,5,74,148,10,2},{-74,5,0,2,10,148},{74,5,0,2,10,148}}) do part(m,"Muralha",Vector3.new(d[4],d[5],d[6]),at(Vector3.new(d[1],d[2],d[3])),trim) end
 for _,x in ipairs({-44,44}) do for _,z in ipairs({-42,42}) do
  local base=Vector3.new(x,3,z) part(m,"Bastiao",Vector3.new(20,6,13),at(base),stone)
  part(m,"Friso",Vector3.new(20.2,.3,13.2),at(base+Vector3.new(0,3,0)),trim)
  local window=part(m,"Painel de energia",Vector3.new(9,1,.18),at(base+Vector3.new(0,1,-6.6)),cyan,Enum.Material.Neon) window.CanCollide=false
  table.insert(W.Cover[key],center+Vector3.new(x,4,z+10))
 end end
 for _,d in ipairs({{-20,-12,12,5,4},{22,16,12,5,4},{-8,32,5,5,14},{11,-34,5,5,14},{-38,7,5,4,12},{38,-8,5,4,12}}) do
  local pos=Vector3.new(d[1],d[4]/2+1,d[2]) local crate=part(m,"Cobertura",Vector3.new(d[3],d[4],d[5]),at(pos),Color3.fromRGB(102,113,126)) crate.TopSurface=Enum.SurfaceType.Studs
  for _,side in ipairs({-1,1}) do part(m,"Cinta",Vector3.new(.25,d[4]+.1,d[5]+.1),at(pos+Vector3.new(side*d[3]*.35,0,0)),trim) end
  table.insert(W.Cover[key],center+Vector3.new(d[1],4,d[2]+d[5]/2+3))
 end
 part(m,"PlataformaCentral",Vector3.new(22,3,22),at(Vector3.new(0,2,0)),trim)
 for i=0,3 do local angle=i*math.pi/2 local cf=at(Vector3.new(math.sin(angle)*18,1.8,math.cos(angle)*18))*CFrame.Angles(0,angle,0) part(m,"Rampa",Vector3.new(14,3.6,15),cf,stone,nil,"Wedge") end
 local core=part(m,"Nucleo",Vector3.new(9,.12,9),at(Vector3.new(0,3.6,0)),cyan,Enum.Material.Neon) core.CanCollide=false
 for i=0,7 do local angle=i*math.pi/4 local pos=Vector3.new(math.sin(angle)*58,4,math.cos(angle)*58) table.insert(W.Spawns[key],center+pos) end
 for _,x in ipairs({-61,61}) do
  part(m,"Torre",Vector3.new(8,18,8),at(Vector3.new(x,10,0)),stone)
  part(m,"TopoTorre",Vector3.new(11,2,11),at(Vector3.new(x,20,0)),trim)
  part(m,"SinalTorre",Vector3.new(.2,10,.2),at(Vector3.new(x,26,0)),coral,Enum.Material.Neon).CanCollide=false
 end
 for i=1,10 do local angle=i*2.399 local radius=95+(i%3)*8 local h=14+(i%5)*7 part(m,"EstruturaDeFundo",Vector3.new(12,h,12),at(Vector3.new(math.sin(angle)*radius,h/2-2,math.cos(angle)*radius)),Color3.fromRGB(75,87,107)) end
end
function W.Build()
 if built then return end built=true
 for _,name in ipairs({"BancadaTeste","Spawn","ParedeTesteLOS","Instrucoes"}) do local old=workspace:FindFirstChild(name) if old then old:Destroy() end end
 local root=Instance.new("Folder") root.Name="VYRELWorld" root.Parent=workspace
 arena(root,"Casual",W.Centers.Casual) arena(root,"Training",W.Centers.Training)
 for i=1,3 do arena(root,"Ranked"..i,Vector3.new(1000+(i-1)*220,0,0)) end
 local lobby=Instance.new("Model") lobby.Name="Citadela" lobby.Parent=root local c=W.Centers.Lobby
 part(lobby,"Ilha",Vector3.new(120,5,100),CFrame.new(c+Vector3.new(0,-2,0)),trim)
 part(lobby,"Praca",Vector3.new(94,2,80),CFrame.new(c+Vector3.new(0,1,0)),stone)
 for i=0,7 do local angle=i*math.pi/4 local pos=c+Vector3.new(math.sin(angle)*28,17,math.cos(angle)*28)
  part(lobby,"Arco",Vector3.new(4,30,4),CFrame.new(pos)*CFrame.Angles(0,angle,.08),trim)
  part(lobby,"Cristal",Vector3.new(2,8,2),CFrame.new(pos+Vector3.new(0,19,0))*CFrame.Angles(.2,angle,.35),coral,Enum.Material.Neon)
 end
 local ring=part(lobby,"Portal",Vector3.new(17,17,2),CFrame.new(c+Vector3.new(0,14,-15)),trim) ring.Transparency=.8 ring.CanCollide=false
 for i=0,11 do local a=i*math.pi/6 part(lobby,"PortalSegmento",Vector3.new(4,.9,1),CFrame.new(c+Vector3.new(math.cos(a)*8,14+math.sin(a)*8,-16))*CFrame.Angles(0,0,a+math.pi/2),cyan,Enum.Material.Neon).CanCollide=false end
 for i=1,14 do local angle=i*2.399 local r=65+i*2 local height=12+i%4*10 part(lobby,"CidadeSuspensa",Vector3.new(14,height,14),CFrame.new(c+Vector3.new(math.sin(angle)*r,height/2-5,math.cos(angle)*r)),stone) end
end
function W.GetSpawn(p)
 W.Build() local id=p:GetAttribute("FPSArena") or "Lobby"
 if id=="Lobby" then return W.Centers.Lobby+Vector3.new(0,5,25) end
 local list=W.Spawns[id] or W.Spawns.Casual local index=p:GetAttribute("FPSSide")=="B" and 5 or 1
 if id=="Casual" or id=="Training" then index=1+(math.abs(p.UserId)%#list) end
 return list[index]
end
return W
