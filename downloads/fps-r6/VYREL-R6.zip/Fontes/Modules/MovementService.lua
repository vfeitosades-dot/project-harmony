local Run=game:GetService("RunService") local Players=game:GetService("Players")
local system=game:GetService("ReplicatedStorage"):WaitForChild("FPSSystem") local Combat=require(script.Parent.CombatService)
local M={} local initialized=false local active={}
local function stop(p,s)
 if s.root and s.root.Parent then
  local v=s.root.AssemblyLinearVelocity s.root.AssemblyLinearVelocity=Vector3.new(0,v.Y,0)
  pcall(function() s.root:SetNetworkOwner(p) end)
 end
 if s.h and s.h.Parent then s.h.AutoRotate=s.auto s.h.WalkSpeed=p:GetAttribute("FPSMode")=="Lobby" and 0 or s.speed end active[p]=nil
end
function M.Dash(p,direction)
 local now=workspace:GetServerTimeNow() local char=p.Character local h=char and char:FindFirstChildOfClass("Humanoid") local root=char and char:FindFirstChild("HumanoidRootPart")
 if not h or h.Health<=0 or not root or h.FloorMaterial==Enum.Material.Air or p:GetAttribute("FPSMode")=="Lobby" or now<(p:GetAttribute("FPSNextDash") or 0) or active[p] then return false end
 if typeof(direction)~="Vector3" or direction.X~=direction.X or direction.Y~=direction.Y or direction.Z~=direction.Z or direction.Magnitude>2 then return false end
 local dir=Vector3.new(direction.X,0,direction.Z) if dir.Magnitude<.1 then dir=Vector3.new(root.CFrame.LookVector.X,0,root.CFrame.LookVector.Z) end if dir.Magnitude<.1 then return false end dir=dir.Unit
 local params=Combat.Params({char}) local length=8
 local hit=workspace:Blockcast(root.CFrame,Vector3.new(1.8,3.5,1.5),dir*length,params) if hit then length=math.max(0,hit.Distance-.8) end if length<1 then return false end
 local time=.18 local s={root=root,h=h,char=char,start=root.Position,dir=dir,length=length,finish=now+time,speed=h.WalkSpeed,auto=h.AutoRotate}
 active[p]=s p:SetAttribute("FPSNextDash",now+4) char:SetAttribute("FPSDashUntil",now+time+.08) char:SetAttribute("FPSDashDirection",dir)
 h.AutoRotate=false h.WalkSpeed=0 pcall(function() root:SetNetworkOwner(nil) end)
 system.Remotes.SkillFX:FireAllClients("Dash",root.Position,root.Position+dir*length,p:GetAttribute("FPSAgent"),p.UserId)
 return true
end
function M.Init()
 if initialized then return end initialized=true
 Run.Heartbeat:Connect(function(dt)
  local now=workspace:GetServerTimeNow()
  for p,s in pairs(active) do
   if p.Character~=s.char or p:GetAttribute("FPSMode")=="Lobby" or (s.char:GetAttribute("FPSDashUntil") or 0)<=now or not s.root.Parent or s.h.Health<=0 or now>=s.finish then stop(p,s)
   else
    local remain=math.max(0,s.length-(s.root.Position-s.start):Dot(s.dir))
    local hit=workspace:Blockcast(s.root.CFrame,Vector3.new(1.8,3.5,1.5),s.dir*math.min(remain,48*dt+.4),Combat.Params({s.char}))
    if hit or remain<.35 then stop(p,s) else local v=s.root.AssemblyLinearVelocity s.root.AssemblyLinearVelocity=s.dir*math.min(48,remain/math.max(.02,s.finish-now))+Vector3.new(0,v.Y,0) end
   end
  end
 end)
 Players.PlayerRemoving:Connect(function(p) if active[p] then stop(p,active[p]) end end)
end
return M
