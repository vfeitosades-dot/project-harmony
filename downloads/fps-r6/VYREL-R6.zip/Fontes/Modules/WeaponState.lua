local Default=require(script.Parent.WeaponConfig)
local S={}
function S.New(life,cfg) local C=cfg or Default return {cfg=C,life=life,ammo=C.Magazine,reserve=C.Reserve,equipped=false,reloading=false,reloadEnd=0,inspectEnd=0,running=false,aiming=false,pitch=0,readyAt=0,lastShot=-1e6,lastSeq=0,generation=0,revision=0} end
function S.Equip(s,value,now)
 local C=s.cfg or Default
 s.generation+=1 s.equipped=value s.reloading=false s.reloadEnd=0 s.inspectEnd=0 s.running=false s.aiming=false s.readyAt=now+(value and C.EquipTime or 0)
end
function S.Acknowledge(s,seq)
 if type(seq)~="number" or seq%1~=0 or seq<=s.lastSeq or seq>s.lastSeq+1000 then return false end s.lastSeq=seq return true
end
function S.Fire(s,seq,now)
 local C=s.cfg or Default
 if not S.Acknowledge(s,seq) then return false,"Sequence" end
 if not s.equipped or now<s.readyAt then return false,"Equip" end
 if s.reloading or s.running then return false,"Busy" end
 if now-s.lastShot<C.FireInterval-.002 then return false,"Cadence" end
 if s.ammo<=0 then return false,"Empty" end
 s.inspectEnd=0 s.lastShot=now s.ammo-=1 return true
end
function S.Reload(s,now)
 local C=s.cfg or Default
 if not s.equipped or now<s.readyAt or s.reloading or s.running or s.ammo>=C.Magazine or s.reserve<=0 then return false end
 s.generation+=1 s.reloading=true s.reloadEnd=now+C.ReloadTime s.inspectEnd=0 s.aiming=false return true,s.generation
end
function S.FinishReload(s,token,now)
 local C=s.cfg or Default
 if token~=s.generation or not s.reloading or not s.equipped or now+.001<s.reloadEnd then return false end
 local count=math.min(C.Magazine-s.ammo,s.reserve) s.ammo+=count s.reserve-=count s.reloading=false s.reloadEnd=0 return true
end
return S
