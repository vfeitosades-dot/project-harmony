local Players=game:GetService("Players") local Run=game:GetService("RunService") local CS=game:GetService("CollectionService") local Debris=game:GetService("Debris")
local system=game:GetService("ReplicatedStorage"):WaitForChild("FPSSystem") local R=system.Remotes
local Agents=require(script.Parent.AgentCatalog) local Combat=require(script.Parent.CombatService) local Movement=require(script.Parent.MovementService)
local K={} local started=false local projectiles={} local fields={} local sensors={} local smoke={}
local folder=Instance.new("Folder") folder.Name="VYRELAbilities" folder.Parent=workspace
local function now() return workspace:GetServerTimeNow() end
local function fx(p,name,a,b) R.SkillFX:FireAllClients(name,a,b,p:GetAttribute("FPSAgent") or "ION",p.UserId) end
local function part(name,size,cf,color,duration)
 local p=Instance.new("Part") p.Name=name p.Size=size p.CFrame=cf p.Color=color p.Material=Enum.Material.Neon p.Anchored=true p.CanCollide=false p.CanTouch=false p.CanQuery=false p.CastShadow=false p.Parent=folder Debris:AddItem(p,duration) return p
end
local function entities()
 local out={} for _,p in ipairs(Players:GetPlayers()) do if p.Character then table.insert(out,{actor=p,model=p.Character}) end end
 for _,m in ipairs(CS:GetTagged("FPSDemoBot")) do if m.Parent then table.insert(out,{actor=m,model=m}) end end
 for _,m in ipairs(CS:GetTagged("VyrelDecoy")) do if m.Parent then table.insert(out,{actor=m,model=m}) end end return out
end
local function allied(p,actor)
 return p:GetAttribute("FPSMatchId")==actor:GetAttribute("FPSMatchId") and p:GetAttribute("FPSSide")==actor:GetAttribute("FPSSide")
end
local function rootOf(model) return model:FindFirstChild("HumanoidRootPart") end
local function burst(p,pos)
 fx(p,"ArcBurst",pos,7)
 for _,e in ipairs(entities()) do local root=rootOf(e.model)
  if root and (root.Position-pos).Magnitude<=7 and Combat.Allowed(p,e.model) and Combat.Visible(pos,root.Position,{p.Character,e.model}) then
   Combat.Apply(p,e.model,12,false,root.Position) e.model:SetAttribute("FPSSlowUntil",now()+2)
  end
 end
end
function K.SmokeBlocks(a,b,matchId)
 local delta=b-a local squared=delta:Dot(delta) if squared<.01 then return false end
 for _,s in ipairs(smoke) do if s.finish>now() and s.match==matchId then local t=math.clamp((s.pos-a):Dot(delta)/squared,0,1) if (a+delta*t-s.pos).Magnitude<s.radius then return true end end end return false
end
function K.OnShot(actor,pos)
 local model=actor:IsA("Player") and actor.Character or actor
 for _,s in ipairs(sensors) do if s.part.Parent and s.finish>now() and s.owner.Parent and model and Combat.Allowed(s.owner,model) and (s.part.Position-pos).Magnitude<25 and now()-(s.last or 0)>.7 then
  s.last=now() R.SkillFX:FireClient(s.owner,"SoundPing",pos,.7,"VEU",0)
 end end
end
local function cast(p,index,direction)
 local char=p.Character local h=char and char:FindFirstChildOfClass("Humanoid") local root=char and rootOf(char)
 if not root or not h or h.Health<=0 or p:GetAttribute("FPSMode")=="Lobby" or (char:GetAttribute("FPSDashUntil") or 0)>now() then return false end
 local agent=Agents.Agents[p:GetAttribute("FPSAgent") or "ION"] if not agent or index%1~=0 or not agent.Skills[index] then return false end
 if (p:GetAttribute("FPSNextSkill"..index) or 0)>now() then return false end
 if typeof(direction)~="Vector3" or direction.Magnitude<.5 or direction.Magnitude>1.5 or direction.X~=direction.X or direction.Y~=direction.Y or direction.Z~=direction.Z then return false end
 direction=direction.Unit local color=Color3.fromRGB(table.unpack(agent.Color)) local flat=Vector3.new(direction.X,0,direction.Z) if flat.Magnitude<.1 then flat=root.CFrame.LookVector end flat=Vector3.new(flat.X,0,flat.Z).Unit
 local agentId=p:GetAttribute("FPSAgent") or "ION" local origin=root.Position local forward=origin+flat*6
 if agentId=="ION" and index==1 then
  local orb=part("ArcoCondutor",Vector3.new(.45,.45,.45),CFrame.new(origin+Vector3.new(0,1,0)+direction*2),color,2.2) orb.Shape=Enum.PartType.Ball
  table.insert(projectiles,{part=orb,pos=orb.Position,velocity=direction*45,finish=now()+1.25,owner=p})
 elseif agentId=="ION" and index==2 then
  local cf=CFrame.lookAt(origin+flat*6-Vector3.new(0,2.5,0),origin+flat*7-Vector3.new(0,2.5,0))
  local lane=part("Trilho",Vector3.new(3,.08,12),cf,color,5) lane.Transparency=.4
  table.insert(fields,{kind="Lane",part=lane,owner=p,finish=now()+5}) fx(p,"Lane",lane.Position,12)
 elseif agentId=="ION" and index==3 then
  local old=char.Archivable char.Archivable=true local echo=char:Clone() char.Archivable=old
  for _,v in ipairs(echo:GetDescendants()) do if v:IsA("Script") or v:IsA("LocalScript") or v:IsA("Tool") then v:Destroy() elseif v:IsA("BasePart") then v.CanCollide=false v.CanTouch=false v.Transparency=math.max(v.Transparency,.35) end end
  local eh=echo:FindFirstChildOfClass("Humanoid") local er=rootOf(echo) if not eh or not er then echo:Destroy() return false end
  eh.MaxHealth=20 eh.Health=20 eh.DisplayName="Eco" eh.EvaluateStateMachine=false er.Anchored=true echo.Name="EcoResidual" echo:SetAttribute("FPSKillCounted",nil) echo:SetAttribute("FPSDecoy",true) echo:SetAttribute("FPSMatchId",p:GetAttribute("FPSMatchId")) echo:SetAttribute("FPSMode",p:GetAttribute("FPSMode")) echo:SetAttribute("FPSSide",p:GetAttribute("FPSSide"))
  echo:PivotTo(root.CFrame*CFrame.new(-2,0,-1)) echo.Parent=workspace CS:AddTag(echo,"VyrelDecoy") Debris:AddItem(echo,4)
 elseif agentId=="AMBAR" and index==1 then
  char:SetAttribute("FPSShield",25) char:SetAttribute("FPSShieldUntil",now()+4)
  local glow=Instance.new("Highlight") glow.Name="VYRELShield" glow.Adornee=char glow.FillColor=color glow.OutlineColor=color glow.FillTransparency=.86 glow.OutlineTransparency=.35 glow.DepthMode=Enum.HighlightDepthMode.Occluded glow.Parent=char Debris:AddItem(glow,4) fx(p,"Shield",origin,4)
 elseif agentId=="AMBAR" and index==2 then
  local station=part("Sutura",Vector3.new(2,.18,2),CFrame.new(origin-Vector3.new(0,2.5,0)),color,5) table.insert(fields,{kind="Heal",part=station,owner=p,finish=now()+5,last=now()}) fx(p,"Heal",station.Position,8)
 elseif agentId=="AMBAR" and index==3 then
  local cf=CFrame.lookAt(forward,forward+flat) local params=OverlapParams.new() params.FilterType=Enum.RaycastFilterType.Exclude params.FilterDescendantsInstances={char,folder}
  for _,v in ipairs(workspace:GetPartBoundsInBox(cf,Vector3.new(7.5,3.5,.6),params)) do if v.CanCollide then return false end end
  local wall=part("Tranca",Vector3.new(8,4,.4),cf,color,4) wall.Transparency=.32 wall.CanCollide=true wall.CanQuery=true wall:SetAttribute("FPSBarrierHP",40) fx(p,"Barrier",wall.Position,4)
 elseif agentId=="VEU" and index==1 then
  fx(p,"RevealPulse",origin,18)
  for _,e in ipairs(entities()) do local er=rootOf(e.model) if er and (er.Position-origin).Magnitude<18 and Combat.Allowed(p,e.model) and Combat.Visible(origin,er.Position,{char,e.model}) then R.SkillFX:FireClient(p,"Reveal",e.model,.8,agentId,p.UserId) end end
 elseif agentId=="VEU" and index==2 then
  local hit=workspace:Raycast(origin+Vector3.new(0,1,0),direction*20,Combat.Params({char})) local pos=hit and hit.Position or origin+direction*15
  local cloud=part("Neblina",Vector3.new(8,8,8),CFrame.new(pos+Vector3.new(0,1,0)),color,4) cloud.Shape=Enum.PartType.Ball cloud.Transparency=.25 cloud.Material=Enum.Material.SmoothPlastic
  for i=1,5 do local angle=i*2.399 local offset=Vector3.new(math.cos(angle)*1.5,math.sin(angle*.7)*.7,math.sin(angle)*1.5)
   local puff=part("FragmentoNeblina",Vector3.new(5.5,5.5,5.5),CFrame.new(cloud.Position+offset),Color3.fromRGB(114+i*5,93+i*3,159+i*5),4) puff.Shape=Enum.PartType.Ball puff.Material=Enum.Material.SmoothPlastic puff.Transparency=.45
  end
  table.insert(smoke,{pos=cloud.Position,radius=4,finish=now()+4,match=p:GetAttribute("FPSMatchId")}) fx(p,"Smoke",cloud.Position,4)
 elseif agentId=="VEU" and index==3 then
  local sensor=part("Escuta",Vector3.new(.7,.7,.7),CFrame.new(forward-Vector3.new(0,2,0)),color,6) sensor.Shape=Enum.PartType.Ball sensor.CanQuery=true sensor:SetAttribute("FPSBarrierHP",15)
  table.insert(sensors,{owner=p,part=sensor,finish=now()+6}) fx(p,"Sensor",sensor.Position,6)
 end
 p:SetAttribute("FPSNextSkill"..index,now()+agent.Skills[index].Cooldown) char:SetAttribute("FPSCastUntil",now()+.26) char:SetAttribute("FPSCastIndex",index) fx(p,"Cast",origin,index)
 return true
end
function K.Init()
 if started then return end started=true Movement.Init()
 local last={}
 system.Remotes.Skill.OnServerEvent:Connect(function(p,index,direction)
  if now()-(last[p] or -math.huge)<.12 then return end last[p]=now()
  if index=="Dash" then Movement.Dash(p,direction) elseif type(index)=="number" and index>=1 and index<=3 then cast(p,index,direction) end
 end)
 Players.PlayerRemoving:Connect(function(p) last[p]=nil end)
 local accumulated=0 Run.Heartbeat:Connect(function(dt)
  for i=#projectiles,1,-1 do local orb=projectiles[i]
   if not orb.part.Parent or not orb.owner.Parent then if orb.part.Parent then orb.part:Destroy() end table.remove(projectiles,i)
   else
    orb.velocity+=Vector3.new(0,-30,0)*dt local delta=orb.velocity*dt local hit=workspace:Raycast(orb.pos,delta,Combat.Params({orb.owner.Character,folder}))
    if hit or now()>=orb.finish then burst(orb.owner,hit and hit.Position or orb.pos) orb.part:Destroy() table.remove(projectiles,i)
    else orb.pos+=delta orb.part.CFrame=CFrame.new(orb.pos) end
   end
  end
  accumulated+=dt if accumulated<.2 then return end local step=accumulated accumulated=0
  local actors=entities()
  for i=#fields,1,-1 do local f=fields[i]
   if not f.part.Parent or f.finish<=now() or not f.owner.Parent then if f.part.Parent then f.part:Destroy() end table.remove(fields,i)
   else for _,e in ipairs(actors) do local er=rootOf(e.model) local h=e.model:FindFirstChildOfClass("Humanoid")
    if er and h and h.Health>0 and allied(f.owner,e.actor) then
     if f.kind=="Lane" then local point=f.part.CFrame:PointToObjectSpace(er.Position) if math.abs(point.X)<2 and math.abs(point.Z)<6 and math.abs(point.Y)<4 then e.model:SetAttribute("FPSBoostUntil",now()+3) end
     elseif (er.Position-f.part.Position).Magnitude<8 and now()-(e.model:GetAttribute("FPSLastDamageAt") or -100)>2 then h.Health=math.min(h.MaxHealth,h.Health+2*step) end
    end
   end end
  end
  for _,e in ipairs(actors) do local h=e.model:FindFirstChildOfClass("Humanoid")
   if h and h.Health>0 and e.actor:GetAttribute("FPSMode")~="Lobby" and (e.model:GetAttribute("FPSDashUntil") or 0)<=now() then
    local tool=e.model:FindFirstChild("Rifle") local base=e.model:GetAttribute("FPSBotBaseSpeed") or (tool and tool:GetAttribute("Running") and 22 or 16)
    local mult=(e.model:GetAttribute("FPSBoostUntil") or 0)>now() and 1.12 or 1
    if (e.model:GetAttribute("FPSSlowUntil") or 0)>now() then mult*=.86 end
    if e.actor:IsA("Player") or mult~=1 then h.WalkSpeed=base*mult end
   end
  end
  for i=#sensors,1,-1 do if sensors[i].finish<now() or not sensors[i].part.Parent then table.remove(sensors,i) end end
  for i=#smoke,1,-1 do if smoke[i].finish<now() then table.remove(smoke,i) end end
 end)
end
return K
