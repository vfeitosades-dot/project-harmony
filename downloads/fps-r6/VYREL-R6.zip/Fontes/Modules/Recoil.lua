local Spring=require(script.Parent.Spring)
local R={} R.__index=R
function R.new(scale) return setmetatable({scale=scale or 1,spring=Spring.new(Vector3.zero,20),random=Random.new()},R) end
function R:Fire(ads) self.spring:Impulse(Vector3.new(ads and .32 or .65,self.random:NextNumber(-.12,.12)*(ads and .45 or 1),0)*self.scale) end
function R:Step(dt) local v=self.spring:Step(dt) return Vector3.new(math.clamp(v.X,-.02,.045),math.clamp(v.Y,-.025,.025),0) end
return R
