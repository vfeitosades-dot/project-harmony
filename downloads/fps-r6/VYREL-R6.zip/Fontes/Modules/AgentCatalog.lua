return {
 Order={"ION","AMBAR","VEU"},
 Agents={
 ION={Name="ION",Role="Vetor de mobilidade",Price=0,Color={69,215,255},Description="Controla ritmo e deslocamento. Pressiona sem depender de dano explosivo.",Skills={
  {Name="Arco condutor",Key="Q",Cooldown=18,Description="Orbita curta: 12 de dano e lentidao leve por 2s, raio de 7 studs."},
  {Name="Trilho de impulso",Key="E",Cooldown=24,Description="Trilho de 12 studs concede 12% de velocidade aos aliados por 3s."},
  {Name="Eco residual",Key="C",Cooldown=26,Description="Um eco visivel com 20 HP distrai inimigos por 4s. Nao causa dano."}}},
 AMBAR={Name="AMBAR",Role="Engenharia de suporte",Price=220,Color={255,173,66},Description="Protege por pouco tempo e cria oportunidades de reposicionamento.",Skills={
  {Name="Pelicula cinetica",Key="Q",Cooldown=24,Description="Absorve ate 25 de dano por 4s. Nao concede invulnerabilidade."},
  {Name="Sutura de campo",Key="E",Cooldown=26,Description="Estacao por 5s restaura 2 HP/s aos aliados fora de combate."},
  {Name="Tranca de pulso",Key="C",Cooldown=28,Description="Cobertura de energia por 4s, destrutivel com 40 de dano."}}},
 VEU={Name="VEU",Role="Leitura de combate",Price=220,Color={178,139,255},Description="Informacao localizada e controle de visao, com janelas curtas.",Skills={
  {Name="Farol espectral",Key="Q",Cooldown=22,Description="Pulso revela por 0,8s inimigos em linha de visao a ate 18 studs."},
  {Name="Neblina fragmentada",Key="E",Cooldown=26,Description="Nuvem pequena bloqueia visao por 4s; balas ainda atravessam."},
  {Name="Escuta direcional",Key="C",Cooldown=24,Description="Sensor por 6s pinga a origem de disparos inimigos proximos."}}}
 }
}
