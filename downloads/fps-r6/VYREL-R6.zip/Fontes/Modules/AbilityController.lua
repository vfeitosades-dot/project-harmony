local Players=game:GetService("Players") local Input=game:GetService("UserInputService") local Run=game:GetService("RunService") local Tween=game:GetService("TweenService") local Debris=game:GetService("Debris")
local system=game:GetService("ReplicatedStorage"):WaitForChild("FPSSystem") local Agents=require(script.Parent.AgentCatalog)
local A={} local closePrevious
function A.init()
 if closePrevious then closePrevious() end
 local player=Players.LocalPlayer local links={} local alive=true
 local gui=Instance.new("ScreenGui") gui.Name="FPSAbilities" gui.ResetOnSpawn=false gui.IgnoreGuiInset=true gui.DisplayOrder=22 gui.Parent=player:WaitForChild("PlayerGui")
 local compact=Input.TouchEnabled local width=compact and 50 or 58 local gap=8 local total=width*3+gap*2 local y=compact and -220 or -100
 local tiles={}
 local function label(parent,text,size,pos,fontSize)
  local t=Instance.new("TextLabel") t.Text=text t.Size=size t.Position=pos t.BackgroundTransparency=1 t.TextColor3=Color3.fromRGB(240,246,255) t.Font=Enum.Font.GothamBold t.TextSize=fontSize t.Parent=parent return t
 end
 local function cast(index)
  if player:GetAttribute("FPSMode")=="Lobby" or player:GetAttribute("FPSMenuOpen")==true then return end
  local char=player.Character local h=char and char:FindFirstChildOfClass("Humanoid") if not h or h.Health<=0 then return end
  local cam=workspace.CurrentCamera if not cam then return end
  local direction=index=="Dash" and h.MoveDirection.Magnitude>.1 and h.MoveDirection or cam.CFrame.LookVector
  system.Remotes.Skill:FireServer(index,direction)
 end
 for i=1,3 do
  local button=Instance.new("TextButton") button.Name="Ability"..i button.Text="" button.Size=UDim2.fromOffset(width,48) button.Position=UDim2.new(.5,-total/2+(i-1)*(width+gap),1,y) button.BackgroundColor3=Color3.fromRGB(22,33,49) button.BackgroundTransparency=.2 button.BorderSizePixel=0 button.Parent=gui
  local corner=Instance.new("UICorner") corner.CornerRadius=UDim.new(0,5) corner.Parent=button
  local stroke=Instance.new("UIStroke") stroke.Thickness=1 stroke.Transparency=.3 stroke.Color=Color3.fromRGB(85,225,245) stroke.Parent=button
  local key=label(button,({"Q","E","C"})[i],UDim2.fromOffset(20,18),UDim2.fromOffset(3,1),12)
  local name=label(button,"",UDim2.new(1,-4,0,18),UDim2.fromOffset(2,26),compact and 8 or 9)
  local cooldown=label(button,"",UDim2.new(1,0,0,26),UDim2.fromOffset(0,4),19)
  local bar=Instance.new("Frame") bar.Size=UDim2.new(1,0,0,2) bar.Position=UDim2.new(0,0,1,-2) bar.BorderSizePixel=0 bar.BackgroundColor3=stroke.Color bar.Parent=button
  table.insert(tiles,{button=button,name=name,key=key,cooldown=cooldown,bar=bar,stroke=stroke})
  table.insert(links,button.Activated:Connect(function() cast(i) end))
 end
 local dash=Instance.new("TextButton") dash.Name="Dash" dash.Text="CTRL  /  DASH" dash.Size=UDim2.fromOffset(compact and 82 or 160,compact and 38 or 24) dash.Position=compact and UDim2.new(1,-100,.5,-58) or UDim2.new(.5,-80,1,-47) dash.BackgroundTransparency=compact and .3 or 1 dash.BackgroundColor3=Color3.fromRGB(22,33,49) dash.TextColor3=Color3.fromRGB(204,223,240) dash.Font=Enum.Font.GothamBold dash.TextSize=10 dash.Parent=gui
 table.insert(links,dash.Activated:Connect(function() cast("Dash") end))
 table.insert(links,Input.InputBegan:Connect(function(i,processed)
  if processed or Input:GetFocusedTextBox() then return end
  if i.KeyCode==Enum.KeyCode.Q then cast(1) elseif i.KeyCode==Enum.KeyCode.E then cast(2) elseif i.KeyCode==Enum.KeyCode.C then cast(3) elseif i.KeyCode==Enum.KeyCode.LeftControl or i.KeyCode==Enum.KeyCode.F then cast("Dash") end
 end))
 table.insert(links,Run.Heartbeat:Connect(function()
  if not alive then return end local agent=Agents.Agents[player:GetAttribute("FPSAgent") or "ION"] local now=workspace:GetServerTimeNow()
  local color=Color3.fromRGB(table.unpack(agent.Color))
  gui.Enabled=player:GetAttribute("FPSMode")~="Lobby" and player:GetAttribute("FPSGameMenu")~=true
  for i,t in ipairs(tiles) do
   local left=math.max(0,(player:GetAttribute("FPSNextSkill"..i) or 0)-now) local skill=agent.Skills[i]
   t.name.Text=skill.Name:match("^(%S+)") or skill.Name t.cooldown.Text=left>.05 and tostring(math.ceil(left)) or "" t.key.TextTransparency=left>0 and .6 or 0
   t.bar.Size=UDim2.new(math.clamp(1-left/skill.Cooldown,0,1),0,0,2) t.bar.BackgroundColor3=color t.stroke.Color=color
  end
  local dashLeft=math.max(0,(player:GetAttribute("FPSNextDash") or 0)-now) dash.Text=dashLeft>.05 and ("DASH  "..string.format("%.1f",dashLeft)) or "CTRL  /  DASH"
 end))
 local function visual(name,size,cf,color,alpha,duration,goal)
  local p=Instance.new("Part") p.Name=name p.Size=size p.CFrame=cf p.Color=color p.Material=Enum.Material.Neon p.Transparency=alpha p.Anchored=true p.CanCollide=false p.CanTouch=false p.CanQuery=false p.CastShadow=false p.Parent=workspace
  if goal then Tween:Create(p,TweenInfo.new(duration),goal):Play() end Debris:AddItem(p,duration+.04) return p
 end
 table.insert(links,system.Remotes.SkillFX.OnClientEvent:Connect(function(kind,a,b,id,owner)
  local agent=Agents.Agents[id] or Agents.Agents.ION local color=Color3.fromRGB(table.unpack(agent.Color))
  if kind=="Reveal" and typeof(a)=="Instance" and a:IsA("Model") then
   local h=Instance.new("Highlight") h.Adornee=a h.FillColor=color h.OutlineColor=color h.FillTransparency=.8 h.OutlineTransparency=.1 h.DepthMode=Enum.HighlightDepthMode.Occluded h.Parent=a Debris:AddItem(h,b) return
  end
  if kind=="SoundPing" and typeof(a)=="Vector3" then
   local anchor=visual("Ping",Vector3.new(.1,.1,.1),CFrame.new(a),color,1,b)
   local bill=Instance.new("BillboardGui") bill.Size=UDim2.fromOffset(45,45) bill.AlwaysOnTop=true bill.StudsOffsetWorldSpace=Vector3.new(0,2,0) bill.Parent=anchor
   local t=label(bill,"!",UDim2.fromScale(1,1),UDim2.fromScale(0,0),30) t.TextColor3=color return
  end
  if player:GetAttribute("FPSVFXEnabled")==false or typeof(a)~="Vector3" then return end
  if kind=="Dash" and typeof(b)=="Vector3" then
   local delta=b-a if delta.Magnitude<.01 then return end
   local basis=CFrame.lookAt(a,b)
   for i=1,5 do local start=basis*CFrame.new((i%2==0 and 1 or -1)*.8,(i%3-1)*.5,-i*.5)
    visual("DashStreak",Vector3.new(.04,.04,1.3),start,color,.35,.25,{Transparency=1,CFrame=start*CFrame.new(0,0,-2),Size=Vector3.new(.01,.01,.2)})
   end
  else
   local radius=kind=="ArcBurst" and 7 or kind=="RevealPulse" and 18 or kind=="Heal" and 8 or 2
   local sphere=visual("AbilityPulse",Vector3.new(.2,.2,.2),CFrame.new(a),color,.65,.35,{Transparency=1,Size=Vector3.new(radius*2,radius*2,radius*2)}) sphere.Shape=Enum.PartType.Ball
   for i=1,5 do local angle=i*2.399 local offset=Vector3.new(math.cos(angle)*1.2,.2,math.sin(angle)*1.2)
    visual("PrismSpark",Vector3.new(.08,.16,.08),CFrame.new(a+offset)*CFrame.Angles(.3,i,.5),color,.15,.4,{Transparency=1,CFrame=CFrame.new(a+offset*2+Vector3.new(0,1.3,0))})
   end
  end
 end))
 local function cleanup() alive=false for _,c in ipairs(links) do c:Disconnect() end gui:Destroy() end closePrevious=cleanup return cleanup
end
return A
