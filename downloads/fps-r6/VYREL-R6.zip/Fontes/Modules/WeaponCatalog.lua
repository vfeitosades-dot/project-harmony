local Base=require(script.Parent.WeaponConfig)
local A={Order={"VETOR","KESTREL","LYRA","FERAL","PULSAR","BASIL","ARGO","TORQ","MAREA","RUPTURA","VESPER","NOMAD"},Weapons={}}
local function weapon(id,name,kind,price,damage,head,mag,reserve,interval,reload,ads,range,auto,pellets,spread)
 local cfg={} for k,v in pairs(Base) do cfg[k]=v end
 cfg.Id=id cfg.Name=name cfg.Kind=kind cfg.Price=price cfg.Damage=damage cfg.Critical=head cfg.Magazine=mag cfg.Reserve=reserve cfg.FireInterval=interval cfg.ReloadTime=reload cfg.ADSFOV=ads cfg.Range=range cfg.Automatic=auto cfg.Pellets=pellets or 1 cfg.Spread=spread or 0 cfg.RecoilScale=(kind=="Sniper" and 2.2 or kind=="Shotgun" and 1.7 or kind=="SMG" and .65 or 1)
 cfg.Description=kind=="Sniper" and "Precisao de longo alcance. Ferrolho, luneta e alto dano por disparo." or kind=="Shotgun" and "Dispersao curta. Cada cartucho lanca varios projeteis." or kind=="Pistol" and "Arma secundaria leve, disparo semiautomatico." or kind=="SMG" and "Compacta, agil e eficaz em combate proximo." or kind=="LMG" and "Suporte automatico com grande capacidade de municao." or "Fuzil versatil, tiro controlavel e alcance intermediario."
 A.Weapons[id]=table.freeze(cfg)
end
weapon("VETOR","VETOR C4","Rifle",0,20,2,30,120,.105,1.8,55,500,true)
weapon("KESTREL","KESTREL K7","Rifle",160,25,2,30,120,.135,2.15,55,500,true)
weapon("LYRA","LYRA B9","Rifle",180,22,2,30,120,.115,2,50,500,true)
weapon("FERAL","FERAL S5","SMG",90,15,1.9,30,150,.075,1.65,60,260,true)
weapon("PULSAR","PULSAR V2","SMG",140,13,1.9,25,150,.065,1.7,60,240,true)
weapon("BASIL","BASIL A1","Sniper",260,65,2.3,5,30,1.1,2.7,28,800,false)
weapon("ARGO","ARGO D6","DMR",210,36,2,15,75,.28,2.3,40,650,false)
weapon("TORQ","TORQ M8","LMG",230,20,1.8,60,180,.105,3.2,55,500,true)
weapon("MAREA","MAREA P8","Shotgun",130,12,1.5,8,48,.8,2.7,60,150,false,6,3.3)
weapon("RUPTURA","RUPTURA D2","Shotgun",100,14,1.5,2,32,.6,1.8,60,120,false,7,4)
weapon("VESPER","VESPER H50","Pistol",100,38,2,7,56,.28,1.7,60,400,false)
weapon("NOMAD","NOMAD P9","Pistol",0,21,2,15,75,.19,1.5,60,350,false)
function A.Get(id) return A.Weapons[id] or A.Weapons.VETOR end
return A
