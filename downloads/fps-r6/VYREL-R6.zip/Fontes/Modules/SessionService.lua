local Players=game:GetService("Players") local Run=game:GetService("RunService")
local system=game:GetService("ReplicatedStorage"):WaitForChild("FPSSystem") local R=system.Remotes
local Profiles=require(script.Parent.ProfileService) local Catalog=require(script.Parent.WeaponCatalog) local World=require(script.Parent.WorldService)
local S={WeaponChanged=Instance.new("BindableEvent")} local ready=false local queue={} local matches={} local last={} local lastSync={} local busy={} local casualEnd=0 local serial=0
local function now() return workspace:GetServerTimeNow() end
function S.Send(p,message)
 if not p.Parent then return end local data=Profiles.Snapshot(p)
 data.Mode=p:GetAttribute("FPSMode") or "Lobby" data.Queued=queue[p]~=nil data.Weapon=p:GetAttribute("FPSWeapon") or data.Primary data.Message=message or "" data.RoundEnd=p:GetAttribute("FPSMatchEnd") or 0
 R.SessionState:FireClient(p,data)
end
local function move(p)
 local char=p.Character local h=char and char:FindFirstChildOfClass("Humanoid") local root=char and char:FindFirstChild("HumanoidRootPart")
 if h then h:UnequipTools() h.WalkSpeed=p:GetAttribute("FPSMode")=="Lobby" and 0 or 16 if h.Health>0 then h.Health=h.MaxHealth end end
 if root then root.AssemblyLinearVelocity=Vector3.zero root.CFrame=CFrame.new(World.GetSpawn(p)) end
end
local function setMode(p,mode,arena,matchId,side,deadline)
 p:SetAttribute("FPSMode",mode) p:SetAttribute("FPSArena",arena) p:SetAttribute("FPSMatchId",matchId) p:SetAttribute("FPSSide",side or "Human") p:SetAttribute("FPSMatchEnd",deadline or 0)
 p:SetAttribute("FPSRoundKills",0) p:SetAttribute("FPSNextDash",0) p:SetAttribute("FPSMatchJoined",now())
 for i=1,3 do p:SetAttribute("FPSNextSkill"..i,0) end
 local char=p.Character if char then
  for _,key in ipairs({"FPSDashUntil","FPSCastUntil","FPSShieldUntil","FPSShield","FPSBoostUntil","FPSSlowUntil"}) do char:SetAttribute(key,0) end
  local glow=char:FindFirstChild("VYRELShield") if glow then glow:Destroy() end
 end
 queue[p]=nil move(p)
 local d=Profiles.Get(p) local weapon=p:GetAttribute("FPSTrialWeapon")
 if mode~="Training" or not Catalog.Weapons[weapon] then weapon=d.Primary end
 p:SetAttribute("FPSWeapon",weapon) S.WeaponChanged:Fire(p,weapon,true) S.Send(p)
end
local function complete(p,reward)
 p:SetAttribute("FPSRounds",(p:GetAttribute("FPSRounds") or 0)+1)
 Profiles.Reward(p,reward)
 local Match=require(script.Parent.MatchState) if Match.Complete then Match.Complete(p) end
end
local function finishRanked(index,winner,leaver)
 local m=matches[index] if not m or m.Done then return end m.Done=true matches[index]=nil
 for _,p in ipairs(m.Players) do
  local outcome if winner then outcome=p==winner end Profiles.RankedResult(p,outcome) complete(p,0)
  p:SetAttribute("FPSLastResult",p==winner and "VITORIA" or winner and "DERROTA" or "EMPATE")
  if p~=leaver and p.Parent then setMode(p,"Lobby","Lobby","Lobby",nil,0) S.Send(p,p==winner and "Vitoria ranqueada!" or "Partida ranqueada encerrada.") end
 end
end
local function cancelQueue(p) queue[p]=nil end
function S.Leave(p)
 cancelQueue(p)
 for i,m in pairs(matches) do if m.Players[1]==p or m.Players[2]==p then finishRanked(i,m.Players[1]==p and m.Players[2] or m.Players[1],p) end end
end
function S.RecordKill(p,victim)
 if p:GetAttribute("FPSMode")=="Ranked" then
  for i,m in pairs(matches) do
   if (m.Players[1]==p or m.Players[2]==p) and victim and victim:GetAttribute("FPSMatchId")==p:GetAttribute("FPSMatchId") then
    if (p:GetAttribute("FPSRoundKills") or 0)>=5 then finishRanked(i,p) end
   end
  end
 elseif p:GetAttribute("FPSMode")=="Casual" then Profiles.Reward(p,6) end
end
local function request(p,command,value,extra)
 if command=="Sync" then S.Send(p) return end
 if command=="CancelQueue" then cancelQueue(p) S.Send(p,"Busca cancelada.") return end
 if command=="Leave" then S.Leave(p) setMode(p,"Lobby","Lobby","Lobby",nil,0) return end
 if command=="Play" then
  if p:GetAttribute("FPSMode")~="Lobby" then S.Send(p,"Volte ao menu antes de trocar de modo.") return end
  local char=p.Character local h=char and char:FindFirstChildOfClass("Humanoid") if not char or not char:FindFirstChild("Torso") or not h or h.Health<=0 then S.Send(p,"Preparando seu avatar R6...") return end
  local d,state=Profiles.Get(p) if state.Loading then S.Send(p,"Perfil carregando.") return end
  if value=="Ranked" then
   if state.ReadOnly then S.Send(p,"Progresso em uso. Treinamento disponivel.") return end
   queue[p]=now() S.Send(p,"Buscando um adversario humano neste servidor...")
  elseif value=="Training" then setMode(p,"Training","Training","Training","Human",0)
  elseif value=="Casual" then if casualEnd<=now() then casualEnd=now()+300 end setMode(p,"Casual","Casual","Casual","Human",casualEnd) end
  return
 end
 if command=="EquipSlot" then
  if value~=1 and value~=2 then return end local d=Profiles.Get(p) local id=value==2 and d.Secondary or d.Primary
  if p:GetAttribute("FPSMode")=="Training" and value==1 and Catalog.Weapons[p:GetAttribute("FPSTrialWeapon")] then id=p:GetAttribute("FPSTrialWeapon") end
  p:SetAttribute("FPSWeapon",id) S.WeaponChanged:Fire(p,id,false) S.Send(p) return
 end
 if p:GetAttribute("FPSMode")~="Lobby" then S.Send(p,"A loja e a selecao ficam disponiveis no menu.") return end
 if command=="Buy" then local ok,message=Profiles.Buy(p,value,extra) S.Send(p,message)
 elseif command=="Equip" then
  local ok,message=Profiles.Equip(p,value,extra) if ok and value=="Weapon" then local d=Profiles.Get(p) p:SetAttribute("FPSTrialWeapon",nil) p:SetAttribute("FPSWeapon",d.Primary) S.WeaponChanged:Fire(p,d.Primary,true) end S.Send(p,message)
 elseif command=="TryWeapon" and Catalog.Weapons[value] then p:SetAttribute("FPSTrialWeapon",value) setMode(p,"Training","Training","Training","Human",0)
 end
end
function S.Init()
 if ready then return end ready=true World.Build() Profiles.Init()
 local function bind(p)
  p:SetAttribute("FPSMode","Lobby") p:SetAttribute("FPSArena","Lobby") p:SetAttribute("FPSMatchId","Lobby") p:SetAttribute("FPSSide","Human") p:SetAttribute("FPSWeapon","VETOR")
 end
 Players.PlayerAdded:Connect(bind) for _,p in ipairs(Players:GetPlayers()) do bind(p) end
 Profiles.BeforeRelease=S.Leave
 Players.PlayerRemoving:Connect(function(p) S.Leave(p) last[p]=nil lastSync[p]=nil busy[p]=nil end)
 R.Session.OnServerEvent:Connect(function(p,command,value,extra)
  if type(command)~="string" or busy[p] then return end
  if command=="Sync" then if now()-(lastSync[p] or -math.huge)<.5 then return end lastSync[p]=now()
  else if now()-(last[p] or -math.huge)<.1 then return end last[p]=now() end
  busy[p]=true
  local ok,err=pcall(request,p,command,value,extra) busy[p]=nil if not ok then warn("[VYREL] Session: "..tostring(err)) S.Send(p,"Nao foi possivel concluir esta acao.") end
 end)
 local accumulated=0 Run.Heartbeat:Connect(function(dt)
  accumulated+=dt if accumulated<.5 then return end accumulated=0
  local waiting={} for p,t in pairs(queue) do if p.Parent and p:GetAttribute("FPSMode")=="Lobby" then table.insert(waiting,p) else queue[p]=nil end end
  table.sort(waiting,function(a,b) return (queue[a] or 0)<(queue[b] or 0) end)
  for i=1,3 do if not matches[i] and #waiting>=2 then
   local first=waiting[1] local elo=Profiles.Get(first).Elo local bestIndex=2 local distance=math.huge
   for j=2,#waiting do local d=math.abs(Profiles.Get(waiting[j]).Elo-elo) if d<distance then distance=d bestIndex=j end end
   local a=table.remove(waiting,1) local b=table.remove(waiting,bestIndex-1) local deadline=now()+240 serial+=1 local id="Ranked"..i.."_"..serial
   matches[i]={Players={a,b},End=deadline,Id=id}
   setMode(a,"Ranked","Ranked"..i,id,"A",deadline) setMode(b,"Ranked","Ranked"..i,id,"B",deadline)
  end end
  for i,m in pairs(matches) do if now()>=m.End then
   local a,b=m.Players[1],m.Players[2] local x,y=a:GetAttribute("FPSRoundKills") or 0,b:GetAttribute("FPSRoundKills") or 0
   finishRanked(i,x>y and a or y>x and b or nil)
  end end
  if casualEnd>0 and now()>=casualEnd then
   casualEnd=now()+300
   for _,p in ipairs(Players:GetPlayers()) do if p:GetAttribute("FPSMode")=="Casual" then
    complete(p,now()-(p:GetAttribute("FPSMatchJoined") or now())>=60 and 70 or 15)
    p:SetAttribute("FPSRoundKills",0) p:SetAttribute("FPSMatchEnd",casualEnd) S.Send(p,"Rodada concluida. Nova rodada iniciada!")
   end end
  end
 end)
end
return S
