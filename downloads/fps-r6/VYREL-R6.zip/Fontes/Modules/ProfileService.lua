local Players=game:GetService("Players") local Run=game:GetService("RunService")
local Http=game:GetService("HttpService") local Catalog=require(script.Parent.WeaponCatalog) local Agents=require(script.Parent.AgentCatalog)
local P={} local profiles={} local initialized=false local token=(game.JobId or "")..Http:GenerateGUID(false)
local store local ok,result=pcall(function() return game:GetService("DataStoreService"):GetDataStore("VYREL_Profile_v1") end) if ok then store=result end
local function default()
 return {Version=1,Credits=500,Weapons={VETOR=true,NOMAD=true},Agents={ION=true},Primary="VETOR",Secondary="NOMAD",Agent="ION",Elo=1000,RankMatches=0,Wins=0}
end
local function sanitize(d)
 local n=default() if type(d)~="table" then return n end
 for _,key in ipairs({"Credits","Elo","RankMatches","Wins"}) do if type(d[key])=="number" and d[key]==d[key] then n[key]=math.clamp(math.floor(d[key]),0,10000000) end end
 for id,v in pairs(type(d.Weapons)=="table" and d.Weapons or {}) do if v==true and Catalog.Weapons[id] then n.Weapons[id]=true end end
 for id,v in pairs(type(d.Agents)=="table" and d.Agents or {}) do if v==true and Agents.Agents[id] then n.Agents[id]=true end end
 if n.Weapons[d.Primary] and Catalog.Get(d.Primary).Kind~="Pistol" then n.Primary=d.Primary end
 if n.Weapons[d.Secondary] and Catalog.Get(d.Secondary).Kind=="Pistol" then n.Secondary=d.Secondary end
 if n.Agents[d.Agent] then n.Agent=d.Agent end return n
end
local function dirty(s) s.Dirty=true s.Revision=(s.Revision or 0)+1 end
local function attrs(p,s)
 p:SetAttribute("FPSCredits",s.Data.Credits) p:SetAttribute("FPSAgent",s.Data.Agent)
 p:SetAttribute("FPSPrimary",s.Data.Primary) p:SetAttribute("FPSSecondary",s.Data.Secondary)
 p:SetAttribute("FPSElo",s.Data.Elo) p:SetAttribute("FPSRankMatches",s.Data.RankMatches)
 p:SetAttribute("FPSStorage",s.Savable and "Persistente" or s.ReadOnly and "Em uso" or "Sessao") p:SetAttribute("FPSProfileReady",true)
end
function P.Load(p)
 if profiles[p] then return profiles[p] end
 local s={Data=default(),Savable=false,ReadOnly=false,Dirty=false,Loading=true} profiles[p]=s
 if store and p.UserId>0 then
  local busy=false
  local loaded,data
  for attempt=1,3 do
   loaded,data=pcall(function() return store:UpdateAsync("u_"..p.UserId,function(old)
   if type(old)=="table" and old.Session and old.Session~=token and os.time()-(old.Touch or 0)<120 then busy=true return nil end
   local next=sanitize(old) next.Session=token next.Touch=os.time() return next
   end) end)
   if loaded or Run:IsStudio() then break end if attempt<3 then task.wait(attempt) end
  end
  if loaded and type(data)=="table" then s.Data=sanitize(data) s.Savable=true elseif busy then s.ReadOnly=true end
 end
 s.Loading=false attrs(p,s) return s
end
function P.Get(p)
 local s=profiles[p] or P.Load(p)
 local deadline=os.clock()+10 while s.Loading and p.Parent and os.clock()<deadline do task.wait(.05) end
 return s.Data,s
end
function P.Save(p,release)
 local s=profiles[p] if not s or not s.Savable or s.Loading or s.Saving then return false end s.Saving=true
 local written=false local writtenRevision=-1
 local success=pcall(function() store:UpdateAsync("u_"..p.UserId,function(old)
  if type(old)=="table" and old.Session and old.Session~=token then return nil end
  written=true writtenRevision=s.Revision or 0 local out=sanitize(s.Data) out.Session=release and nil or token out.Touch=os.time() return out
 end) end)
 s.Saving=false if success and written then s.Dirty=(s.Revision or 0)~=writtenRevision else if success then s.Savable=false s.ReadOnly=true attrs(p,s) end end return success and written
end
function P.Snapshot(p)
 local d,s=P.Get(p) local prices={} for id in pairs(Catalog.Weapons) do prices[id]=P.Price(id,"Weapon") end return {Prices=prices,Featured=Catalog.Order[math.floor(os.time()/86400)%#Catalog.Order+1],Credits=d.Credits,Weapons=d.Weapons,Agents=d.Agents,Primary=d.Primary,Secondary=d.Secondary,Agent=d.Agent,Elo=d.Elo,RankMatches=d.RankMatches,Wins=d.Wins,Storage=s.Loading and "Carregando" or s.Savable and "Persistente" or s.ReadOnly and "Em uso" or "Sessao"}
end
function P.Price(id,kind)
 if kind=="Agent" then local a=Agents.Agents[id] return a and a.Price end
 local w=Catalog.Weapons[id] if not w then return nil end
 local day=math.floor(os.time()/86400) local featured=Catalog.Order[day%#Catalog.Order+1]
 return id==featured and math.floor(w.Price*.8) or w.Price
end
function P.Buy(p,kind,id)
 if type(id)~="string" or (kind~="Weapon" and kind~="Agent") then return false,"Item invalido." end
 local d,s=P.Get(p) if s.ReadOnly or s.Loading then return false,"Progresso indisponivel; use o treinamento." end
 local price=P.Price(id,kind) if price==nil then return false,"Item inexistente." end
 local owned=kind=="Agent" and d.Agents or d.Weapons
 if owned[id] then return false,"Voce ja possui este item." end
 if d.Credits<price then return false,"Creditos insuficientes." end
 d.Credits-=price owned[id]=true dirty(s) attrs(p,s) task.spawn(P.Save,p,false) return true,"Desbloqueado!"
end
function P.Equip(p,kind,id)
 local d,s=P.Get(p) if s.Loading then return false,"Carregando perfil." end
 if kind=="Agent" then if not d.Agents[id] then return false,"Operador bloqueado." end d.Agent=id
 elseif kind=="Weapon" then
  if not d.Weapons[id] then return false,"Arma bloqueada." end
  if Catalog.Get(id).Kind=="Pistol" then d.Secondary=id else d.Primary=id end
 else return false,"Categoria invalida." end
 dirty(s) attrs(p,s) return true,"Equipado."
end
function P.Reward(p,amount)
 local d,s=P.Get(p) if s.ReadOnly or s.Loading or amount<=0 then return end
 d.Credits=math.clamp(d.Credits+math.max(0,math.floor(amount)),0,10000000) dirty(s) attrs(p,s)
end
function P.RankedResult(p,win)
 local d,s=P.Get(p) if s.ReadOnly then return end
 d.RankMatches+=1 d.Elo=math.clamp(d.Elo+(win==true and 24 or win==false and -18 or 0),100,3000) if win==true then d.Wins+=1 end
 dirty(s) P.Reward(p,win==true and 100 or win==false and 45 or 60) attrs(p,s) task.spawn(P.Save,p,false)
end
function P.Init()
 if initialized then return end initialized=true
 Players.PlayerAdded:Connect(function(p) task.spawn(P.Load,p) end)
 Players.PlayerRemoving:Connect(function(p) if P.BeforeRelease then P.BeforeRelease(p) end local s=profiles[p] local deadline=os.clock()+10 while s and s.Saving and os.clock()<deadline do task.wait(.05) end P.Save(p,true) profiles[p]=nil end)
 for _,p in ipairs(Players:GetPlayers()) do task.spawn(P.Load,p) end
 local accumulated=0 Run.Heartbeat:Connect(function(dt) accumulated+=dt if accumulated>=45 then accumulated=0 for p in pairs(profiles) do task.spawn(P.Save,p,false) end end end)
 game:BindToClose(function() local pending=0 for p in pairs(profiles) do pending+=1 task.spawn(function() P.Save(p,true) pending-=1 end) end local untilTime=os.clock()+6 while pending>0 and os.clock()<untilTime do task.wait(.1) end end)
end
P.Default=default P.Sanitize=sanitize
return P
