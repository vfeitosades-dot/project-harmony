local modules=game:GetService("ReplicatedStorage"):WaitForChild("FPSSystem"):WaitForChild("Modules")
require(modules.SessionService).Init()
require(modules.SkillService).Init()
require(modules.BotService).Init()
