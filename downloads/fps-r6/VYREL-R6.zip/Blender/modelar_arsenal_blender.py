import bpy,json,math
from pathlib import Path
from mathutils import Matrix,Vector
b=Path(__file__).resolve().parent;data=json.loads((b/'vyrel/arsenal.json').read_text());out=b/'BlenderArsenal';out.mkdir(exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
P=Matrix(((1,0,0),(0,0,-1),(0,1,0)));materials={}
for index,(ident,rows) in enumerate(data['models'].items()):
 collection=bpy.data.collections.new(ident);bpy.context.scene.collection.children.link(collection)
 offset=Vector(((index%3)*6.1,(index//3)*4.3,1.5))
 for d in rows:
  if d.get('alpha',0)>=1:continue
  size=d['size'];name=d['name'];shape=d['shape'];pos=d['pos']
  if shape=='Tube':
   bpy.ops.mesh.primitive_cylinder_add(vertices=24,radius=.5,depth=1);o=bpy.context.object;o.rotation_euler=(math.pi/2,0,0);bpy.ops.object.transform_apply(location=False,rotation=True,scale=False)
  elif shape=='Wedge':
   sx,sy,sz=[v/2 for v in size];v=[(-sx,-sy,-sz),(sx,-sy,-sz),(-sx,-sy,sz),(sx,-sy,sz),(-sx,sy,sz),(sx,sy,sz)]
   mesh=bpy.data.meshes.new(name);mesh.from_pydata([(x,-z,y) for x,y,z in v],[],[(0,1,3,2),(2,3,5,4),(0,2,4),(1,5,3),(0,4,5,1)]);o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o)
  else:bpy.ops.mesh.primitive_cube_add();o=bpy.context.object
  if shape!='Wedge':o.dimensions=(size[0],size[2],size[1]);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
  rx,ry,rz=[math.radians(a) for a in d['rot']];rotation=Matrix.Rotation(rx,3,'X')@Matrix.Rotation(ry,3,'Y')@Matrix.Rotation(rz,3,'Z');o.rotation_euler=(P@rotation@P.inverted()).to_euler();turn=Matrix.Rotation(-math.pi/2,3,'Z');o.location=turn@Vector((pos[0],-pos[2],pos[1]))+offset;o.rotation_euler=(turn@o.rotation_euler.to_matrix()).to_euler();o.name=ident+'_'+name
  for c in list(o.users_collection):c.objects.unlink(o)
  collection.objects.link(o)
  color=tuple(d['color']);key=(color,'rubber' if any(t in name for t in ['Grip','Stock','Pump']) else 'metal')
  if key not in materials:
   mat=bpy.data.materials.new(str(key));mat.diffuse_color=tuple(x/255 for x in color)+(1,);mat.use_nodes=True;bs=mat.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=mat.diffuse_color;bs.inputs['Metallic'].default_value=.72 if key[1]=='metal' else .05;bs.inputs['Roughness'].default_value=.38 if key[1]=='metal' else .7;materials[key]=mat
  o.data.materials.append(materials[key])
  bevel=o.modifiers.new('Usinagem','BEVEL');bevel.width=min(.018,min(size)*.12);bevel.segments=2
  if shape=='Tube':
   for f in o.data.polygons:f.use_smooth=True
 # Label is separate from the editable weapon collection.
 bpy.ops.object.text_add(location=Vector((offset.x-1.8,offset.y-1.15,.03)));label=bpy.context.object;label.name=ident+'_Label';label.data.body=ident;label.data.size=.3;label.data.extrude=.001
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=20;s.cycles.use_denoising=False;s.world.color=(.3,.35,.45)
bpy.ops.mesh.primitive_plane_add(size=200,location=(6,6,-.16));ground=bpy.context.object;gm=bpy.data.materials.new('Background');gm.diffuse_color=(.04,.055,.08,1);ground.data.materials.append(gm)
for pos,power,size in [((0,-4,16),2800,12),((18,12,14),2400,10),((-6,14,8),1500,9)]:
 bpy.ops.object.light_add(type='AREA',location=pos);bpy.context.object.data.energy=power;bpy.context.object.data.size=size
bpy.ops.object.camera_add(location=(9,-13,20));camera=bpy.context.object;camera.rotation_euler=(Vector((6,6.5,1.2))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.type='ORTHO';camera.data.ortho_scale=22;s.camera=camera
s.render.resolution_x=1800;s.render.resolution_y=1500;s.render.resolution_percentage=100;s.view_settings.view_transform='Standard'
bpy.ops.wm.save_as_mainfile(filepath=str(out/'VYREL_Arsenal_12.blend'))
s.render.filepath=str(out/'VYREL_Arsenal_12.png');bpy.ops.render.render(write_still=True)
print('BLENDER_ARSENAL_OK',len(data['models']))
