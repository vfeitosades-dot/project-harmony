import bpy,math
from pathlib import Path
from mathutils import Matrix,Vector
r=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(r/'Vetor30_Modelo_Detalhado.blend'))
P=Matrix(((1,0,0,0),(0,0,-1,0),(0,1,0,0),(0,0,0,1)))
poses={}
for line in (r/'preview_pose.log').read_text().splitlines():
 if not line.startswith('POSE '):continue
 name,values=line[5:].rsplit(' ',1);v=list(map(float,values.split(',')))
 poses[name]=P@Matrix(((v[3],v[4],v[5],v[0]),(v[6],v[7],v[8],v[1]),(v[9],v[10],v[11],v[2]),(0,0,0,1)))@P.inverted()
for o in list(bpy.data.objects):
 if o.type=='MESH':o.matrix_world=poses['Gun']@o.matrix_world
 else:bpy.data.objects.remove(o,do_unlink=True)
def box(name,size,pos,color,cf=None):
 bpy.ops.mesh.primitive_cube_add();o=bpy.context.object;o.name=name;o.dimensions=(size[0],size[2],size[1]);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 o.location=(pos[0],-pos[2],pos[1])
 if cf is not None:o.matrix_world=cf
 mat=bpy.data.materials.new(name);mat.diffuse_color=(*color,1);o.data.materials.append(mat)
 bevel=o.modifiers.new('Edge','BEVEL');bevel.width=.018;bevel.segments=1
box('Torso',(2,2,1),(0,3,0),(.18,.23,.3))
box('Head',(1.6,1,1),(0,4.5,0),(.55,.6,.64))
for x in [-.5,.5]:box('Leg',(1,2,1),(x,1,0),(.13,.17,.22))
box('Right Arm',(1,2,1),(0,0,0),(.55,.6,.64),poses['Right Shoulder'])
box('Left Arm',(1,2,1),(0,0,0),(.55,.6,.64),poses['Left Shoulder'])
box('Floor',(200,.1,200),(0,-.05,0),(.045,.06,.085))
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=16;s.cycles.use_denoising=False;s.world.color=(.25,.3,.4)
for pos,energy in [((4,3,8),950),((-4,-1,5),700)]:
 bpy.ops.object.light_add(type='AREA',location=pos);bpy.context.object.data.energy=energy;bpy.context.object.data.size=5
bpy.ops.object.camera_add(location=(8,10,7));cam=bpy.context.object;cam.rotation_euler=(Vector((0,1,2.5))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=7;s.camera=cam
s.render.resolution_x=1100;s.render.resolution_y=900;s.render.resolution_percentage=100;s.view_settings.view_transform='Standard';s.render.filepath=str(r/'Preview_Pegada_R6.png');bpy.ops.render.render(write_still=True)
