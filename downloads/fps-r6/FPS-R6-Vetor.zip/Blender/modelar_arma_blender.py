import bpy,math,json
from pathlib import Path
from mathutils import Matrix,Vector
R=Path(__file__).resolve().parent
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
D=[];materials={};pal={'navy':(36,48,67),'blue':(48,104,135),'steel':(151,170,184),'black':(24,30,39),'gold':(235,170,62),'rubber':(48,55,62)}
def p(name,size,pos,color='navy',shape='Block',rot=(0,0,0),group='Body'):
 rgb=pal[color];D.append(dict(name=name,size=size,pos=pos,color=rgb,shape=shape,rot=rot,group=group))
 if shape=='Tube':
  bpy.ops.mesh.primitive_cylinder_add(vertices=20,radius=.5,depth=1);o=bpy.context.object;o.rotation_euler=(math.pi/2,0,0);bpy.ops.object.transform_apply(location=False,rotation=True,scale=False)
 elif shape=='Wedge':
  sx,sy,sz=[v/2 for v in size];verts=[(-sx,-sy,-sz),(sx,-sy,-sz),(-sx,-sy,sz),(sx,-sy,sz),(-sx,sy,sz),(sx,sy,sz)]
  mesh=bpy.data.meshes.new(name);mesh.from_pydata([(x,-z,y) for x,y,z in verts],[],[(0,1,3,2),(2,3,5,4),(0,2,4),(1,5,3),(0,4,5,1)]);o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o)
 else:bpy.ops.mesh.primitive_cube_add();o=bpy.context.object
 if shape!='Wedge':o.dimensions=(size[0],size[2],size[1]);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 P=Matrix(((1,0,0),(0,0,-1),(0,1,0)));rx,ry,rz=[math.radians(a) for a in rot];m=Matrix.Rotation(rx,3,'X')@Matrix.Rotation(ry,3,'Y')@Matrix.Rotation(rz,3,'Z')
 o.rotation_euler=(P@m@P.inverted()).to_euler();o.location=(pos[0],-pos[2],pos[1]);o.name=name
 if color not in materials:
  mat=bpy.data.materials.new(color);mat.diffuse_color=tuple(a/255 for a in rgb)+(1,);mat.use_nodes=True;bs=mat.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=mat.diffuse_color;bs.inputs['Metallic'].default_value=.5 if color=='steel' else .15;bs.inputs['Roughness'].default_value=.4;materials[color]=mat
 o.data.materials.append(materials[color]);return o
p('Receiver',(.57,.46,1.9),(0,.25,-.65),'blue')
p('Upper receiver',(.62,.14,1.45),(0,.55,-.55),'navy')
p('Chamfer frente',(.57,.16,.28),(0,.51,-1.55),'blue','Wedge')
p('Chamfer traseiro',(.57,.16,.28),(0,.51,.28),'blue','Wedge',(0,180,0))
p('Handguard',(.49,.4,.9),(0,.24,-1.95),'navy')
p('Cano virtual',(.16,.16,.8),(0,.29,-2.78),'steel','Tube')
p('Emissor',(.29,.29,.28),(0,.29,-3.22),'black','Tube')
p('Anel frontal',(.34,.34,.07),(0,.29,-3.12),'steel','Tube')
p('Trilho',(.29,.07,1.7),(0,.66,-.7),'steel')
for z in [-1.45,-1.2,-.95,-.7,-.45,-.2,.05]:p('Dente do trilho',(.34,.05,.09),(0,.715,z),'navy')
for x in [-.3,.3]:
 p('Painel lateral',(.045,.3,1.1),(x,.26,-.65),'navy')
 p('Faixa lateral',(.05,.055,.7),(x,.46,-.5),'gold')
 for z in [-1.05,-.75,-.45,-.15]:p('Parafuso',(.06,.06,.025),(x,.25,z),'steel','Tube',(0,90,0))
 for z in [-2.22,-2.02,-1.82,-1.62]:p('Janela de ventilacao',(.025,.12,.11),(x*.84,.27,z),'black')
 p('Painel traseiro',(.045,.18,.27),(x,.3,.1),'steel')
p('Coronha',(.38,.34,.65),(0,.2,.77),'navy')
p('Haste da coronha',(.24,.19,.4),(0,.32,.33),'steel')
p('Ombreira',(.44,.57,.12),(0,.13,1.16),'rubber')
for y in [-.04,.08,.2,.32]:p('Textura ombreira',(.46,.035,.13),(0,y,1.17),'black')
p('Cabo',(.33,.58,.36),(0,-.34,.12),'rubber',rot=(-10,0,0))
for y in [-.5,-.38,-.26]:p('Relevo cabo',(.35,.035,.34),(0,y,.13),'black')
p('Guarda inferior',(.34,.055,.43),(0,-.25,-.22),'steel')
p('Guarda frontal',(.34,.2,.055),(0,-.13,-.42),'steel')
p('Magazine',(.39,.63,.53),(0,-.46,-.65),'navy',group='Mag')
for x in [-.205,.205]:
 for y in [-.65,-.48,-.31]:p('Rib magazine',(.035,.045,.48),(x,y,-.65),'rubber',group='Mag')
p('Base magazine',(.44,.08,.56),(0,-.8,-.65),'steel',group='Mag')
p('Mira traseira',(.37,.09,.22),(0,.71,.15),'black')
for x in [-.13,.13]:p('Mira lateral',(.065,.17,.12),(x,.79,.15),'steel')
p('Mira frontal',(.06,.16,.1),(0,.79,-1.7),'gold')
p('Suporte da mira',(.18,.25,.24),(0,.56,-1.7),'navy')
p('Moldura frontal',(.25,.07,.2),(0,.7,-1.7),'black')
# Open reflex optic: no opaque glass obscures the target.
p('Base reflex',(.46,.09,.5),(0,.785,-.25),'black')
for x in [-.235,.235]:p('Arco reflex',(.065,.44,.095),(x,1.04,-.25),'navy')
p('Topo reflex',(.53,.065,.095),(0,1.26,-.25),'navy')
p('Ponto reflex',(.018,.018,.018),(0,1.04,-.25),'gold')
p('Ajuste reflex',(.1,.13,.17),(.3,.85,-.25),'steel')
(R/'weapon_v2.json').write_text(json.dumps(D))
bpy.ops.wm.save_as_mainfile(filepath=str(R/'Vetor30_Modelo_Detalhado.blend'))
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=24;s.cycles.use_denoising=False;s.world.color=(.35,.4,.5)
bpy.ops.object.light_add(type='AREA',location=(3,-2,5));bpy.context.object.data.energy=600;bpy.context.object.data.size=5
bpy.ops.object.light_add(type='AREA',location=(-3,3,3));bpy.context.object.data.energy=350;bpy.context.object.data.size=4
bpy.ops.object.camera_add(location=(5,-1.5,2.4));cam=bpy.context.object;cam.rotation_euler=(Vector((0,1,.1))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=5.8;s.camera=cam;s.view_settings.view_transform='Standard';s.render.resolution_x=1600;s.render.resolution_y=900;s.render.resolution_percentage=100;s.render.filepath=str(R/'Vetor30_Modelo_Detalhado.png');bpy.ops.render.render(write_still=True)
print('BLENDER_WEAPON_OK',len(D),'componentes')
