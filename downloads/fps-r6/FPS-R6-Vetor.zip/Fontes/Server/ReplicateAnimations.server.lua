-- C0 e propriedades visuais atualizados no servidor replicam a todos os clientes.
local system=game:GetService("ReplicatedStorage"):WaitForChild("FPSSystem")
require(system:WaitForChild("Modules"):WaitForChild("ThirdPersonController")).init(true)
