-- Bancada de teste opcional; nao faz parte do sistema instalavel de armas.
local function target(x,z)
 local m=Instance.new("Model") m.Name="AlvoTreino" m:SetAttribute("TrainingTarget",true)
 local function part(name,size,pos,color)
  local p=Instance.new("Part") p.Name=name p.Size=size p.Position=pos p.Color=color p.Anchored=true p.Parent=m return p
 end
 local torso=part("Torso",Vector3.new(2,2,1),Vector3.new(x,3.5,z),Color3.fromRGB(45,139,171))
 part("Head",Vector3.new(2,1,1),Vector3.new(x,5,z),Color3.fromRGB(255,202,98))
 for _,side in ipairs({-1,1}) do
  part(side<0 and "Left Arm" or "Right Arm",Vector3.new(1,2,1),Vector3.new(x+side*1.5,3.5,z),Color3.fromRGB(255,202,98))
  part(side<0 and "Left Leg" or "Right Leg",Vector3.new(1,2,1),Vector3.new(x+side*.5,1.5,z),Color3.fromRGB(44,57,73))
 end
 local root=part("HumanoidRootPart",Vector3.new(2,2,1),Vector3.new(x,3.5,z),Color3.new(1,1,1)) root.Transparency=1 root.CanCollide=false root.CanQuery=false
 local h=Instance.new("Humanoid") h.RequiresNeck=false h.BreakJointsOnDeath=false h.DisplayName="Alvo de teste" h.Parent=m
 m.PrimaryPart=root m.Parent=workspace
 h.Died:Connect(function() task.delay(2,function() m:Destroy() target(x,z) end) end)
end
for _,x in ipairs({-8,0,8}) do target(x,-24) end
