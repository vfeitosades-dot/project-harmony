-- Alvos com aparencia normal da primeira conta que entrar. Sem o boneco noob.
local Players=game:GetService("Players")
local CS=game:GetService("CollectionService")
local Avatar=require(game:GetService("ReplicatedStorage").FPSSystem.Modules.AvatarAppearance)
local ownerId local started=false
local function target(index,x)
 local m,err=Avatar.Create(ownerId)
 if not m then warn("[Bots] "..tostring(err)) task.delay(3,function() target(index,x) end) return end
 m.Name="BotTreino"..index local h=m:FindFirstChildOfClass("Humanoid") local root=m:FindFirstChild("HumanoidRootPart")
 if not h or not root then m:Destroy() return end
 h.DisplayName="BOT "..string.format("%02d",index) h.WalkSpeed=0 h.JumpPower=0 h.AutoRotate=false h.BreakJointsOnDeath=false
 root.Anchored=true m.PrimaryPart=root m:PivotTo(CFrame.new(x,3.5,-24)) m.Parent=workspace m:SetAttribute("TrainingTarget",true) CS:AddTag(m,"FPSDemoBot")
 h.Died:Connect(function() task.delay(2,function() m:Destroy() target(index,x) end) end)
end
local function start(p)
 if started then return end started=true ownerId=p.UserId
 if ownerId<=0 and game.CreatorType==Enum.CreatorType.User and game.CreatorId>0 then ownerId=game.CreatorId end
 for i,x in ipairs({-8,0,8}) do task.spawn(target,i,x) end
end
Players.PlayerAdded:Connect(start) local first=Players:GetPlayers()[1] if first then start(first) end
