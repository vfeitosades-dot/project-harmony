-- Rig R6 proprio: nao depende da configuracao de avatar da experiencia.
local Players=game:GetService("Players")
local C=require(game:GetService("ReplicatedStorage").FPSSystem.Modules.WeaponConfig)
local Physics=game:GetService("PhysicsService")
local S={} local spawning={}
local function spawnCharacter(p)
 if not p.Parent or spawning[p] then return end spawning[p]=true
 local old=p.Character local m=Instance.new("Model") m.Name=p.Name
 local start=CFrame.new(C.LOBBY.ORIGIN+Vector3.new(0,5,-5))
 local function limb(name,size,offset,color,collide)
  local part=Instance.new("Part") part.Name=name part.Size=size part.CFrame=start*CFrame.new(offset) part.Color=color part.TopSurface=Enum.SurfaceType.Smooth part.BottomSurface=Enum.SurfaceType.Smooth part.CanCollide=collide part.CollisionGroup="Characters" part.Parent=m return part
 end
 local skin=Color3.fromRGB(255,207,123) local blue=Color3.fromRGB(40,114,232) local green=Color3.fromRGB(73,133,75)
 local root=limb("HumanoidRootPart",Vector3.new(2,2,1),Vector3.zero,blue,false) root.Transparency=1
 local torso=limb("Torso",Vector3.new(2,2,1),Vector3.zero,blue,true)
 local head=limb("Head",Vector3.new(2,1,1),Vector3.new(0,1.5,0),skin,false)
 local ra=limb("Right Arm",Vector3.new(1,2,1),Vector3.new(1.5,0,0),skin,false)
 local la=limb("Left Arm",Vector3.new(1,2,1),Vector3.new(-1.5,0,0),skin,false)
 local rl=limb("Right Leg",Vector3.new(1,2,1),Vector3.new(.5,-2,0),green,false)
 local ll=limb("Left Leg",Vector3.new(1,2,1),Vector3.new(-.5,-2,0),green,false)
 for _,part in ipairs({head,torso,ra,la,rl,ll}) do part.Massless=true end
 local function motor(name,a,b,c0,c1) local j=Instance.new("Motor6D") j.Name=name j.Part0=a j.Part1=b j.C0=CFrame.new(c0) j.C1=CFrame.new(c1) j.Parent=a end
 motor("RootJoint",root,torso,Vector3.zero,Vector3.zero)
 motor("Neck",torso,head,Vector3.new(0,1,0),Vector3.new(0,-.5,0))
 motor("Right Shoulder",torso,ra,Vector3.new(1.5,.5,0),Vector3.new(0,.5,0)) motor("Left Shoulder",torso,la,Vector3.new(-1.5,.5,0),Vector3.new(0,.5,0))
 motor("Right Hip",torso,rl,Vector3.new(.5,-1,0),Vector3.new(0,1,0)) motor("Left Hip",torso,ll,Vector3.new(-.5,-1,0),Vector3.new(0,1,0))
 -- Rosto desenhado com UI, sem dependencia de asset.
 local gui=Instance.new("SurfaceGui") gui.Name="Rosto" gui.Face=Enum.NormalId.Front gui.CanvasSize=Vector2.new(160,80) gui.Parent=head
 local function facePart(name,x,y,w,h)
  local f=Instance.new("Frame") f.Name=name f.Position=UDim2.fromOffset(x,y) f.Size=UDim2.fromOffset(w,h) f.BackgroundColor3=Color3.fromRGB(40,34,31) f.BorderSizePixel=0 f.Parent=gui return f
 end
 for _,x in ipairs({45,105}) do local eye=facePart("Olho",x,20,10,10) local c=Instance.new("UICorner") c.CornerRadius=UDim.new(1,0) c.Parent=eye end
 facePart("Sorriso",50,56,60,5) facePart("Sorriso",45,47,6,10) facePart("Sorriso",109,47,6,10)

 local h=Instance.new("Humanoid") h.Name="Humanoid" h.RigType=Enum.HumanoidRigType.R6 h.HipHeight=0 h.WalkSpeed=C.RUNNER.WALKSPEED h.UseJumpPower=true h.JumpPower=C.RUNNER.JUMPPOWER h.DisplayName=p.DisplayName h.Parent=m
 local animator=Instance.new("Animator") animator.Parent=h
 m.PrimaryPart=root m.Parent=workspace p.Character=m if old then old:Destroy() end
 spawning[p]=nil
 h.Died:Connect(function() task.delay(3,function() if p.Parent and p.Character==m then spawnCharacter(p) end end) end)
end
function S.init()
 pcall(function() Physics:RegisterCollisionGroup("Characters") end)
 Physics:CollisionGroupSetCollidable("Characters","Characters",false)
 Players.CharacterAutoLoads=false
 Players.PlayerAdded:Connect(function(p) task.defer(spawnCharacter,p) end)
 Players.PlayerRemoving:Connect(function(p) spawning[p]=nil end)
 for _,p in ipairs(Players:GetPlayers()) do task.defer(spawnCharacter,p) end
end
S.init()
