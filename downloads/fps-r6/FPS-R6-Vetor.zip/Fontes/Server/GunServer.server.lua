local Players=game:GetService("Players")
local RS=game:GetService("ReplicatedStorage")
local Physics=game:GetService("PhysicsService")
pcall(function() Physics:RegisterCollisionGroup("FPSViewModel") end)
for _,g in ipairs(Physics:GetRegisteredCollisionGroups()) do Physics:CollisionGroupSetCollidable("FPSViewModel",g.name,false) end
local System=RS:WaitForChild("FPSSystem") local Modules=System.Modules
local C=require(Modules.WeaponConfig) local Logic=require(Modules.WeaponState) local Factory=require(Modules.WeaponFactory)
local Anim=require(Modules.AnimationController)
local Remotes=System:WaitForChild("Remotes")
local states={} local lives={} local windows={}
local function now() return workspace:GetServerTimeNow() end
local function rate(p,key,limit)
 local t=now() local buckets=windows[p] or {} windows[p]=buckets local b=buckets[key] or {t=t,n=0} buckets[key]=b
 if t-b.t>=1 then b.t=t b.n=0 end b.n+=1 return b.n<=limit
end
local function snapshot(p,s,reason)
 if not p.Parent or states[p]~=s then return end s.revision+=1
 if s.tool and s.tool.Parent then for k,v in pairs({ReloadEnd=s.reloadEnd,InspectEnd=s.inspectEnd,Running=s.running,Aiming=s.aiming,AimPitch=s.pitch,EquippedAt=s.readyAt-C.EquipTime}) do s.tool:SetAttribute(k,v) end end
 Remotes.State:FireClient(p,{life=s.life,revision=s.revision,ammo=s.ammo,reserve=s.reserve,ack=s.lastSeq,reloading=s.reloading,reloadEnd=s.reloadEnd,readyAt=s.readyAt,equipped=s.equipped,inspectEnd=s.inspectEnd,reason=reason})
end
local function healthy(p,s)
 local char=p.Character local h=char and char:FindFirstChildOfClass("Humanoid")
 return char and h and h.Health>0 and s.tool and s.tool.Parent==char and s.equipped
end
local function finite(v)
 if typeof(v)~="Vector3" then return false end
 return v.X==v.X and v.Y==v.Y and v.Z==v.Z and math.abs(v.X)<1e5 and math.abs(v.Y)<1e5 and math.abs(v.Z)<1e5
end
Remotes.Fire.OnServerEvent:Connect(function(p,life,seq,origin,direction)
 if not rate(p,"fire",40) then return end local s=states[p] if not s then return end
 if life~=s.life then snapshot(p,s,"Equip") return end
 local function reject(reason) if Logic.Acknowledge(s,seq) then snapshot(p,s,reason) end end
 if not healthy(p,s) then reject("Equip") return end
 if not finite(origin) or not finite(direction) or direction.Magnitude<.5 or direction.Magnitude>1.5 then reject("Intent") return end
 local head=p.Character:FindFirstChild("Head") if not head or (origin-head.Position).Magnitude>5 then reject("Origin") return end
 local params=RaycastParams.new() params.FilterType=Enum.RaycastFilterType.Exclude params.FilterDescendantsInstances={p.Character} params.IgnoreWater=true
 if (origin-head.Position).Magnitude>.1 and workspace:Raycast(head.Position,origin-head.Position,params) then reject("OriginBlocked") return end
 local ok,reason=Logic.Fire(s,seq,now()) if not ok then snapshot(p,s,reason) return end
 local dir=direction.Unit local hit=workspace:Raycast(head.Position,dir*C.Range,params) local target=hit and hit.Position or head.Position+dir*C.Range
 local muzzle=s.tool.Handle:FindFirstChild("Muzzle") local joint=s.tool.Handle:FindFirstChild("WorldGrip") local torso=p.Character:FindFirstChild("Torso")
 local gunCF
 if torso and joint then
  local shoulder=torso:FindFirstChild("Right Shoulder")
  if shoulder and joint.Part0==shoulder.Part1 then
   gunCF=torso.CFrame*shoulder.C0*shoulder.C1:Inverse()*joint.C0*(joint.C1 or CFrame.new()):Inverse()
  else gunCF=torso.CFrame*joint.C0 end
 end
 local start=gunCF and muzzle and (gunCF*muzzle.CFrame).Position or head.Position
 if (start-head.Position).Magnitude>6 or workspace:Raycast(head.Position,start-head.Position,params) then start=head.Position end
 if hit then
  local model=hit.Instance:FindFirstAncestorOfClass("Model") local humanoid=model and model:FindFirstChildOfClass("Humanoid")
  local victim=model and Players:GetPlayerFromCharacter(model)
  local friendly=victim and not p.Neutral and not victim.Neutral and p.Team==victim.Team
  if humanoid and humanoid.Health>0 and model~=p.Character and not friendly and not model:FindFirstChildOfClass("ForceField") then
   local critical=hit.Instance.Name=="Head" local before=humanoid.Health humanoid:TakeDamage(C.Damage*(critical and C.Critical or 1))
   if humanoid.Health<before then Remotes.Hit:FireClient(p,critical) end
  end
 end
 p.Character:SetAttribute("FPSLastShotAt",now())
 Remotes.WeaponFX:FireAllClients(p.UserId,start,target,hit and hit.Normal or nil)
 snapshot(p,s)
end)
Remotes.Reload.OnServerEvent:Connect(function(p,life)
 if not rate(p,"reload",6) then return end local s=states[p]
 if not s or life~=s.life or not healthy(p,s) then return end
 local ok,token=Logic.Reload(s,now()) snapshot(p,s,ok and nil or "ReloadRejected") if not ok then return end
 local function finish()
  if states[p]~=s or s.generation~=token or not healthy(p,s) then return end
  local waitTime=s.reloadEnd-now() if waitTime>.001 then task.delay(waitTime,finish) return end
  Logic.FinishReload(s,token,now()) snapshot(p,s)
 end task.delay(C.ReloadTime,finish)
end)
Remotes.Action.OnServerEvent:Connect(function(p,action,value)
 if not rate(p,"action",20) or type(action)~="string" then return end local s=states[p] if not s then return end
 if action=="Sync" then snapshot(p,s) return end
 if not healthy(p,s) or s.reloading or now()<s.readyAt then return end
 if action=="Pitch" and type(value)=="number" and value==value and math.abs(value)<=1.2 then s.pitch=value s.tool:SetAttribute("AimPitch",value) return end
 if action=="Aim" and type(value)=="boolean" then s.aiming=value if value then s.running=false s.inspectEnd=0 end
 elseif action=="Run" and type(value)=="boolean" then s.running=value if value then s.aiming=false s.inspectEnd=0 end
 elseif action=="Inspect" then s.inspectEnd=now()+C.InspectTime s.aiming=false s.running=false
 elseif action=="CancelInspect" then s.inspectEnd=0
 else return end
 local h=p.Character:FindFirstChildOfClass("Humanoid") if h then h.WalkSpeed=s.running and C.RunSpeed or C.WalkSpeed end snapshot(p,s)
end)
local function character(p,char)
 local h=char:WaitForChild("Humanoid",10) local torso=char:WaitForChild("Torso",10)
 if p.Character~=char or not h or not torso then return end
 local previous=states[p]
 if previous then Logic.Equip(previous,false,now()) for _,c in ipairs(previous.connections or {}) do c:Disconnect() end end
 lives[p]=(lives[p] or 0)+1 local s=Logic.New(lives[p]) s.connections={} states[p]=s
 local function connect(signal,fn) local c=signal:Connect(fn) table.insert(s.connections,c) end
 local backpack=p:WaitForChild("Backpack",10) if not backpack or p.Character~=char or states[p]~=s then return end
 for _,parent in ipairs({backpack,char}) do for _,t in ipairs(parent:GetChildren()) do if t:IsA("Tool") and t.Name=="Rifle" then t:Destroy() end end end
 local tool=game:GetService("StarterPack"):WaitForChild("Rifle"):Clone() Factory.Mount(tool) s.tool=tool tool.CanBeDropped=false
 local function cancel()
  Logic.Equip(s,false,now()) local grip=tool.Handle:FindFirstChild("WorldGrip") if grip then grip:Destroy() end
  if h.Parent then h.WalkSpeed=C.WalkSpeed end snapshot(p,s)
 end
 connect(tool.Equipped,function()
  if states[p]~=s or p.Character~=char or tool.Parent~=char or h.Health<=0 then return end
  local function removeDefault() local arm=char:FindFirstChild("Right Arm") local old=arm and arm:FindFirstChild("RightGrip") if old then old:Destroy() end end
  removeDefault() task.defer(removeDefault)
  local previous=tool.Handle:FindFirstChild("WorldGrip") if previous then previous:Destroy() end
  local right=char:FindFirstChild("Right Arm") local shoulder=torso:FindFirstChild("Right Shoulder")
  local joint=Instance.new("Motor6D") joint.Name="WorldGrip" joint.Part1=tool.Handle joint.C1=CFrame.new()
  local desired=torso.CFrame*Anim.WorldBase(torso)
  if right and shoulder then
   joint.Part0=right joint.C0=(torso.CFrame*shoulder.C0*shoulder.C1:Inverse()):ToObjectSpace(desired)
   tool.Grip=joint.C0:Inverse()*CFrame.new(0,-right.Size.Y*.5,0)
  else joint.Part0=torso joint.C0=Anim.WorldBase(torso) end
  joint.Parent=tool.Handle
  Logic.Equip(s,true,now()) snapshot(p,s)
 end)
 local rightArm=char:FindFirstChild("Right Arm")
 if rightArm then connect(rightArm.ChildAdded,function(j)
  if j.Name=="RightGrip" and j:IsA("JointInstance") and j.Part1==tool.Handle and tool.Parent==char then j:Destroy() end
 end) end
 connect(tool.Unequipped,function() if states[p]==s then cancel() end end)
 connect(h.Died,function() if states[p]==s then cancel() end end)
 tool.Parent=backpack snapshot(p,s)
 local function rejectDuplicate(t) if t:IsA("Tool") and t.Name=="Rifle" and t~=tool then task.defer(function() if t.Parent then t:Destroy() end end) end end
 connect(backpack.ChildAdded,rejectDuplicate) connect(char.ChildAdded,rejectDuplicate)
 local shield=Instance.new("ForceField") shield.Parent=char game:GetService("Debris"):AddItem(shield,3)
end
local function added(p) p.CharacterAdded:Connect(function(char) task.spawn(character,p,char) end) if p.Character then task.spawn(character,p,p.Character) end end
Players.PlayerAdded:Connect(added) Players.PlayerRemoving:Connect(function(p) local s=states[p] if s then for _,c in ipairs(s.connections or {}) do c:Disconnect() end end states[p]=nil windows[p]=nil lives[p]=nil end)
for _,p in ipairs(Players:GetPlayers()) do added(p) end
