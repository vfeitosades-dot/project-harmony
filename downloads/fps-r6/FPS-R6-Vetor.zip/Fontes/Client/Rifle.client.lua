local system=game:GetService("ReplicatedStorage"):WaitForChild("FPSSystem")
require(system.Modules.ClientController).attach(script.Parent)
