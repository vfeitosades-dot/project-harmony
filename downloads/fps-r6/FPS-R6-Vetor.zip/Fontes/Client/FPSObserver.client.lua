local system=game:GetService("ReplicatedStorage"):WaitForChild("FPSSystem")
local modules=system:WaitForChild("Modules")
system:WaitForChild("Remotes"):WaitForChild("WeaponFX")
require(modules:WaitForChild("ThirdPersonController")).init(false)
