local system=game:GetService("ReplicatedStorage"):WaitForChild("FPSSystem")
require(system.Modules.ThirdPersonController).init()
