-- Timelines autorais. Campos: tempo, transformacao da arma, mao esquerda, carregador.
local A={}
local I=CFrame.new()
local function cf(x,y,z,rx,ry,rz) return CFrame.new(x,y,z)*CFrame.Angles(math.rad(rx or 0),math.rad(ry or 0),math.rad(rz or 0)) end
A.Clips={
 Equipping={{0,cf(.12,-1.15,.4,-25,10,14),cf(-.15,-.4,.25),I},{.12,cf(.06,-.55,.18,-12,5,6),cf(-.1,-.18,.1),I},{.27,cf(-.015,.035,-.015,1,0,-2),cf(-.025,-.015,0),I},{.36,cf(0,-.012,0,-.4,0,.6),I,I},{.45,I,I,I}},
 Unequipping={{0,I,I,I},{.3,cf(.2,-1.3,.4,-35,15,20),cf(-.2,-.3,.2),I}},
 Reloading={{0,I,I,I},{.16,cf(-.04,.01,.05,-3,0,-15),cf(-.1,-.1,.2),I},
 {.28,cf(-.07,.025,.09,-5,0,-24),cf(-.15,-.2,.3),I},
 {.5,cf(-.07,.025,.09,-5,0,-26),cf(-.15,-.4,.4),cf(0,-.45,.08,0,0,-7)},
 {.68,cf(-.07,.025,.09,-5,0,-26),cf(-.2,-.65,.4),cf(0,-1.05,.16,0,0,-12)},
 {.86,cf(-.07,.025,.09,-5,0,-25),cf(-.2,-.7,.4),cf(0,-1.15,.18,0,0,-12)},
 {1.01,cf(-.065,.02,.08,-4,0,-22),cf(-.1,-.4,.2),cf(0,-.5,.08,0,0,-5)},
 {1.2,cf(-.03,.035,.04,-2,0,-14),cf(-.04,-.1,.1),cf(0,.025,0)},
 {1.36,cf(0,-.01,.015,.8,0,-4),I,I},{1.65,I,I,I}},
 Inspecting={{0,I,I,I},{.45,cf(-.22,.1,.12,5,-25,-22),cf(-.1,-.05,.05),I},{1.05,cf(-.08,.15,.3,-8,20,30),cf(.05,0,0),I},{1.65,cf(-.15,.06,.15,3,-18,-16),I,I},{2.15,cf(0,.02,0,0,0,2),I,I},{2.5,I,I,I}},
}
function A.Sample(name,time)
 local list=A.Clips[name] if not list then return I,I,I end
 if time<=list[1][1] then return list[1][2],list[1][3],list[1][4] end
 for n=2,#list do local b=list[n] local a=list[n-1] if time<=b[1] then local t=math.clamp((time-a[1])/(b[1]-a[1]),0,1) t=t*t*(3-2*t) return a[2]:Lerp(b[2],t),a[3]:Lerp(b[3],t),a[4]:Lerp(b[4],t) end end
 local last=list[#list] return last[2],last[3],last[4]
end
function A.ReloadHandWeight(time)
 local v=time<.28 and math.clamp(time/.28,0,1) or time>1.35 and 1-math.clamp((time-1.35)/.3,0,1) or 1
 return v*v*(3-2*v)
end
function A.MagazineAlpha(time) if time<.72 or time>1.04 then return 0 end if time<.82 then return (time-.72)/.1 elseif time<.94 then return 1 else return 1-(time-.94)/.1 end end
function A.State(equipped,age,reload,inspect,running,aiming,firing,walking)
 if not equipped then return "Unequipping" elseif age<.45 then return "Equipping" elseif reload then return "Reloading" elseif inspect then return "Inspecting" elseif firing then return "Firing" elseif aiming then return "Aiming" elseif running then return "Running" elseif walking then return "Walking" else return "Idle" end
end
-- Authored third-person chest-ready idle; no uploaded AnimationId required.
-- Stock is kept outside the front of a standard R6 torso.
A.WorldIdle={{0,CFrame.new()},{1.2,CFrame.new(0,.006,0)},{2.4,CFrame.new()}}
local function worldIdle(time)
 local phase=time%2.4
 for i=2,#A.WorldIdle do
  local a,b=A.WorldIdle[i-1],A.WorldIdle[i]
  if phase<=b[1] then local t=(phase-a[1])/(b[1]-a[1]) t=t*t*(3-2*t) return a[2]:Lerp(b[2],t) end
 end
 return CFrame.new()
end
function A.WorldBase(torso)
 return CFrame.new(0,torso.Size.Y*.175,-torso.Size.Z*.5-1.05)
end
function A.WorldSample(now,phase,move,run,jump,aim)
 local steady=1-.8*aim
 return worldIdle(now)*CFrame.new(math.sin(phase)*.012*move*steady,
  math.cos(phase*2)*.012*move*steady+.035*jump+.045*aim,-.025*aim)
  *CFrame.Angles(-.055*run+.035*jump,math.sin(phase)*.012*move*steady,.018*run)
end
return A
