local Players=game:GetService("Players") local Input=game:GetService("UserInputService")
local C=require(script.Parent.WeaponConfig)
local H={} H.__index=H
function H.new(actions)
 local pg=Players.LocalPlayer:WaitForChild("PlayerGui") local gui=pg:FindFirstChild("GunHUD") or Instance.new("ScreenGui") gui.Name="GunHUD" gui.ResetOnSpawn=false gui.DisplayOrder=20 gui.IgnoreGuiInset=true gui.Enabled=false gui.Parent=pg
 local old=gui:FindFirstChild("Root") if old then old:Destroy() end
 local root=Instance.new("Frame") root.Name="Root" root.Size=UDim2.fromScale(1,1) root.BackgroundTransparency=1 root.Parent=gui
 local function label(text,size,pos,fs)
  local t=Instance.new("TextLabel") t.Text=text t.Size=size t.Position=pos t.BackgroundTransparency=1 t.TextColor3=Color3.fromRGB(235,242,248) t.Font=Enum.Font.GothamMedium t.TextSize=fs t.Parent=root return t
 end
 local ammo=label(C.Magazine.." / "..C.Reserve,UDim2.fromOffset(210,44),UDim2.new(1,-230,1,-92),26) ammo.TextXAlignment=Enum.TextXAlignment.Right
 local weapon=label(C.Name,UDim2.fromOffset(210,24),UDim2.new(1,-230,1,-116),12) weapon.TextXAlignment=Enum.TextXAlignment.Right weapon.TextColor3=Color3.fromRGB(130,161,180)
 local debugLabel=label("",UDim2.fromOffset(240,24),UDim2.fromOffset(12,12),12) debugLabel.Visible=C.DebugHUD
 local status=label("",UDim2.new(.8,0,0,24),UDim2.new(.1,0,.6,0),13)
 local hint=label("R  recarregar    H  inspecionar    Shift  correr",UDim2.new(.9,0,0,22),UDim2.new(.05,0,1,-30),11) hint.TextColor3=Color3.fromRGB(151,168,187) hint.Visible=not Input.TouchEnabled
 local cross={}
 for _,v in ipairs({{-7,0,4,1},{4,0,4,1},{0,-7,1,4},{0,4,1,4}}) do local f=Instance.new("Frame") f.Size=UDim2.fromOffset(v[3],v[4]) f.Position=UDim2.new(.5,v[1],.5,v[2]) f.BackgroundColor3=Color3.fromRGB(225,240,248) f.BorderSizePixel=0 f.Parent=root table.insert(cross,f) end
 local dot=Instance.new("Frame") dot.Name="CenterDot" dot.Size=UDim2.fromOffset(2,2) dot.Position=UDim2.new(.5,-1,.5,-1) dot.BorderSizePixel=0 dot.BackgroundColor3=Color3.fromRGB(255,207,109) dot.Parent=root
 local hit=label("×",UDim2.fromOffset(42,42),UDim2.new(.5,-21,.5,-21),32) hit.Visible=false
 local track=Instance.new("Frame") track.Size=UDim2.fromOffset(130,2) track.Position=UDim2.new(.5,-65,.6,26) track.BackgroundColor3=Color3.fromRGB(36,53,71) track.BorderSizePixel=0 track.Visible=false track.Parent=root
 local fill=Instance.new("Frame") fill.Size=UDim2.fromScale(0,1) fill.BackgroundColor3=Color3.fromRGB(76,197,214) fill.BorderSizePixel=0 fill.Parent=track
 local connections={}
 local function button(text,pos,fn,hold)
  local b=Instance.new("TextButton") b.Text=text b.Size=UDim2.fromOffset(64,48) b.Position=pos b.BackgroundColor3=Color3.fromRGB(25,41,58) b.BackgroundTransparency=.15 b.TextColor3=Color3.fromRGB(234,244,248) b.Font=Enum.Font.GothamMedium b.TextSize=12 b.Parent=root b.Visible=Input.TouchEnabled
  local c=Instance.new("UICorner") c.CornerRadius=UDim.new(0,12) c.Parent=b
  if hold then
   local finger
   table.insert(connections,b.InputBegan:Connect(function(i) if i.UserInputType==Enum.UserInputType.Touch or i.UserInputType==Enum.UserInputType.MouseButton1 then finger=i fn(true) end end))
   table.insert(connections,Input.InputEnded:Connect(function(i) if i==finger then finger=nil fn(false) end end))
  else table.insert(connections,b.Activated:Connect(fn)) end
 end
 button("ATIRAR",UDim2.new(1,-84,.5,30),actions.fire,true)
 button("MIRA",UDim2.new(1,-158,.5,30),actions.aim)
 button("RELOAD",UDim2.new(1,-84,.5,90),actions.reload)
 button("CORRER",UDim2.new(0,20,.5,90),actions.run)
 button("INSPECT",UDim2.new(0,20,.5,30),actions.inspect)
 return setmetatable({gui=gui,root=root,ammo=ammo,status=status,debugLabel=debugLabel,hit=hit,cross=cross,dot=dot,bloom=0,track=track,fill=fill,connections=connections},H)
end
function H:SetVisible(v) self.gui.Enabled=v end
function H:Update(ammo,reserve,state,progress,phase)
 if C.DebugHUD then self.debugLabel.Text=string.format("%s · %.2fs",state,phase or 0) end
 self.ammo.Text=string.format("%02d / %02d",math.max(0,ammo),reserve)
 self.ammo.TextColor3=ammo<=5 and Color3.fromRGB(255,151,133) or Color3.fromRGB(235,242,248)
 self.status.Text=state=="Reloading" and "Recarregando" or state=="Equipping" and "Equipando" or state=="Inspecting" and "Inspecionando" or ""
 self.track.Visible=state=="Reloading" self.fill.Size=UDim2.fromScale(math.clamp(progress or 0,0,1),1)
end
function H:Hit(critical)
 self.hitAt=os.clock()+.15 self.hit.Visible=true self.hit.TextColor3=critical and Color3.fromRGB(255,192,91) or Color3.fromRGB(235,242,248)
end
function H:Pulse() self.bloom=math.min((self.bloom or 0)+3,13) end
function H:Tick(aim,dt,speed,running)
 dt=dt or 1/60 self.bloom=(self.bloom or 0)*math.exp(-dt*13)
 local gap=5+math.clamp((speed or 0)/16,0,1)*4+self.bloom+(running and 6 or 0)
 local offsets={{-gap-4,-.5},{gap,-.5},{-.5,-gap-4},{-.5,gap}}
 for i,f in ipairs(self.cross) do
  f.Position=UDim2.new(.5,offsets[i][1],.5,offsets[i][2]) f.BackgroundTransparency=aim f.Visible=aim<.98
 end
 self.dot.BackgroundTransparency=aim self.dot.Visible=aim<.98
 local left=(self.hitAt or 0)-os.clock() self.hit.Visible=left>0 self.hit.TextTransparency=1-math.clamp(left/.15,0,1)
end
function H:Destroy() for _,c in ipairs(self.connections) do c:Disconnect() end if self.root.Parent then self.root:Destroy() end end
return H
