-- Persistent custom loadout: one real weapon slot, never decorative fake weapons.
local Players=game:GetService("Players") local Input=game:GetService("UserInputService")
local StarterGui=game:GetService("StarterGui") local C=require(script.Parent.WeaponConfig)
local L={} local previousCleanup
function L.init()
 if previousCleanup then previousCleanup() end
 local player=Players.LocalPlayer local pg=player:WaitForChild("PlayerGui")
 local alive=true local links={} local charLinks={} local saved={}
 local function connect(list,event,fn) table.insert(list,event:Connect(fn)) end
 local function disconnect(list) for _,c in ipairs(list) do c:Disconnect() end table.clear(list) end
 local function disable(attempt)
  if not alive then return end
  local ok=pcall(function()
   for _,kind in ipairs({Enum.CoreGuiType.Backpack,Enum.CoreGuiType.Health}) do
    if saved[kind]==nil then saved[kind]=StarterGui:GetCoreGuiEnabled(kind) end
    StarterGui:SetCoreGuiEnabled(kind,false)
   end
  end)
  if not ok and attempt<24 then task.delay(.25,function() disable(attempt+1) end) end
 end
 disable(0)
 local old=pg:FindFirstChild("FPSLoadout") if old then old:Destroy() end
 local gui=Instance.new("ScreenGui") gui.Name="FPSLoadout" gui.ResetOnSpawn=false gui.IgnoreGuiInset=true gui.DisplayOrder=19 gui.Parent=pg
 local function frame(parent,name,size,pos,color,alpha)
  local f=Instance.new("Frame") f.Name=name f.Size=size f.Position=pos f.BackgroundColor3=color f.BackgroundTransparency=alpha or 0 f.BorderSizePixel=0 f.Parent=parent return f
 end
 local function label(parent,name,text,size,pos,fontSize)
  local t=Instance.new("TextLabel") t.Name=name t.Text=text t.Size=size t.Position=pos t.BackgroundTransparency=1 t.Font=Enum.Font.GothamMedium t.TextSize=fontSize t.TextColor3=Color3.fromRGB(241,245,250) t.TextXAlignment=Enum.TextXAlignment.Left t.Parent=parent return t
 end
 local width=Input.TouchEnabled and 150 or 186
 local slot=Instance.new("TextButton") slot.Name="PrimarySlot" slot.Text="" slot.Size=UDim2.fromOffset(width,56) slot.Position=UDim2.new(1,-width-18,1,-74) slot.BackgroundColor3=Color3.fromRGB(17,22,29) slot.BackgroundTransparency=.22 slot.BorderSizePixel=0 slot.Parent=gui
 local corner=Instance.new("UICorner") corner.CornerRadius=UDim.new(0,5) corner.Parent=slot
 local border=Instance.new("UIStroke") border.Thickness=1 border.Transparency=.65 border.Color=Color3.fromRGB(220,230,240) border.Parent=slot
 local selected=frame(slot,"Selection",UDim2.new(1,0,0,2),UDim2.new(0,0,1,-2),Color3.fromRGB(255,207,104))
 label(slot,"Key","1",UDim2.fromOffset(16,18),UDim2.fromOffset(9,31),12)
 local name=label(slot,"Weapon",C.Name,UDim2.new(1,-18,0,16),UDim2.fromOffset(9,5),10)
 local caption=label(slot,"State","EQUIPAR",UDim2.fromOffset(68,14),UDim2.fromOffset(28,33),9) caption.TextColor3=Color3.fromRGB(152,166,180) caption.Visible=not Input.TouchEnabled
 -- Original vector silhouette of this rifle, no external icon assets.
 local icon=frame(slot,"RifleIcon",UDim2.fromOffset(70,24),UDim2.new(1,-79,0,23),Color3.fromRGB(255,255,255),1)
 for i,d in ipairs({{17,7,30,8},{46,8,19,3},{63,7,5,5},{8,9,10,7},{2,8,7,12},{21,15,5,7},{32,15,7,8},{23,4,17,2}}) do
  frame(icon,"Piece"..i,UDim2.fromOffset(d[3],d[4]),UDim2.fromOffset(d[1],d[2]),Color3.fromRGB(226,234,242))
 end
 local healthWidth=Input.TouchEnabled and 108 or 140
 local health=frame(gui,"Health",UDim2.fromOffset(healthWidth,44),UDim2.new(0,18,1,-62),Color3.fromRGB(15,20,27),1)
 local hp=label(health,"Value","100",UDim2.fromOffset(80,30),UDim2.fromOffset(0,0),28)
 label(health,"Unit","HP",UDim2.fromOffset(22,18),UDim2.fromOffset(67,10),10)
 local track=frame(health,"Track",UDim2.new(1,0,0,3),UDim2.fromOffset(0,37),Color3.fromRGB(64,72,84),.35)
 local fill=frame(track,"Fill",UDim2.fromScale(1,1),UDim2.fromScale(0,0),Color3.fromRGB(239,243,248))
 local function humanoid() local char=player.Character return char and char:FindFirstChildOfClass("Humanoid") end
 local function rifle()
  local char=player.Character local bag=player:FindFirstChild("Backpack")
  local tool=char and char:FindFirstChild("Rifle") or bag and bag:FindFirstChild("Rifle")
  return tool and tool:IsA("Tool") and tool or nil
 end
 local function refresh()
  if not alive then return end
  local tool=rifle() local equipped=tool and tool.Parent==player.Character
  slot.Active=tool~=nil selected.Visible=equipped==true border.Transparency=equipped and .15 or .7
  name.Text=tool and C.Name or "AGUARDANDO" caption.Text=equipped and "EQUIPADO" or "EQUIPAR"
  local h=humanoid() local value=h and math.max(0,h.Health) or 0 local max=h and math.max(1,h.MaxHealth) or 100
  hp.Text=tostring(math.ceil(value)) fill.Size=UDim2.fromScale(math.clamp(value/max,0,1),1)
  fill.BackgroundColor3=value<=max*.3 and Color3.fromRGB(255,112,100) or Color3.fromRGB(239,243,248)
 end
 local function toggle()
  local h=humanoid() local tool=rifle()
  if not h or h.Health<=0 or not tool then return end
  if tool.Parent==player.Character then h:UnequipTools() else h:EquipTool(tool) end
  task.defer(refresh)
 end
 connect(links,slot.Activated,toggle)
 connect(links,Input.InputBegan,function(i,processed)
  if not processed and not Input:GetFocusedTextBox() and (i.KeyCode==Enum.KeyCode.One or i.KeyCode==Enum.KeyCode.ButtonR1) then toggle() end
 end)
 local function bindCharacter(char)
  disconnect(charLinks)
  if not char then refresh() return end
  connect(charLinks,char.ChildAdded,function() task.defer(refresh) end)
  connect(charLinks,char.ChildRemoved,function() task.defer(refresh) end)
  local h=char:WaitForChild("Humanoid",10)
  if h and player.Character==char then
   connect(charLinks,h.HealthChanged,refresh) connect(charLinks,h.Died,refresh)
  end
  refresh()
 end
 local bag=player:WaitForChild("Backpack",10)
 if bag then connect(links,bag.ChildAdded,refresh) connect(links,bag.ChildRemoved,function() task.defer(refresh) end) end
 connect(links,player.CharacterAdded,bindCharacter)
 if player.Character then bindCharacter(player.Character) else refresh() end
 local function cleanup()
  if not alive then return end alive=false disconnect(links) disconnect(charLinks) gui:Destroy()
  for kind,value in pairs(saved) do pcall(function() StarterGui:SetCoreGuiEnabled(kind,value) end) end
 end
 previousCleanup=cleanup return cleanup
end
return L
