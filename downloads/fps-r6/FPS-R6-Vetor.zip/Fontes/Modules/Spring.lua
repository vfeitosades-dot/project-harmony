-- Solucao analitica criticamente amortecida: independente da taxa de quadros.
local S={} S.__index=S
function S.new(value,frequency) return setmetatable({position=value,velocity=value*0,target=value,frequency=frequency or 18},S) end
function S:Impulse(value) self.velocity+=value end
function S:Step(dt)
 dt=math.max(0,dt) local w=self.frequency local offset=self.position-self.target
 local j=self.velocity+offset*w local decay=math.exp(-w*dt)
 self.position=self.target+(offset+j*dt)*decay self.velocity=(self.velocity-j*w*dt)*decay
 return self.position
end
return S
