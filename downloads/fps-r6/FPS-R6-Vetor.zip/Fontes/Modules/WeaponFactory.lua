-- Rifle virtual original em pecas nativas, sem assets externos.
local F={}
local dark=Color3.fromRGB(35,47,65) local blue=Color3.fromRGB(47,139,171) local pale=Color3.fromRGB(182,203,214) local gold=Color3.fromRGB(255,197,80)
function F.Build(parent)
 local m=Instance.new("Model") m.Name="RifleModel"
 local root=Instance.new("Part") root.Name="Handle" root.Size=Vector3.new(.25,.25,.25) root.CFrame=CFrame.new() root.Transparency=1 root.CanCollide=false root.CanTouch=false root.CanQuery=false root.Massless=true root.Parent=m m.PrimaryPart=root
 local magazine
 local function part(name,size,pos,color,attach)
  local p=Instance.new("Part") p.Name=name p.Size=size p.CFrame=CFrame.new(pos) p.TopSurface=Enum.SurfaceType.Smooth p.BottomSurface=Enum.SurfaceType.Smooth p.Color=color p.Material=Enum.Material.SmoothPlastic p.CanCollide=false p.CanTouch=false p.CanQuery=false p.Massless=true p.Parent=m
  if attach~=false then local w=Instance.new("Weld") w.Part0=root w.Part1=p w.C0=root.CFrame:Inverse()*p.CFrame w.Parent=p end return p
 end
 part("Corpo",Vector3.new(.55,.58,2.1),Vector3.new(0,.23,-.65),blue)
 part("Cobertura",Vector3.new(.6,.13,1.8),Vector3.new(0,.57,-.7),dark)
 part("Guarda frontal",Vector3.new(.5,.42,.85),Vector3.new(0,.18,-1.8),dark)
 part("Cano virtual",Vector3.new(.2,.2,1.2),Vector3.new(0,.29,-2.65),pale)
 part("Emissor",Vector3.new(.32,.3,.35),Vector3.new(0,.29,-3.18),dark)
 part("Coronha",Vector3.new(.4,.42,.8),Vector3.new(0,.16,.75),dark)
 part("Apoio",Vector3.new(.48,.65,.2),Vector3.new(0,.1,1.18),pale)
 part("Cabo",Vector3.new(.35,.65,.38),Vector3.new(0,-.34,.1),dark)
 magazine=part("Magazine",Vector3.new(.4,.65,.55),Vector3.new(0,-.46,-.65),pale,false)
 local magMotor=Instance.new("Motor6D") magMotor.Name="MagazineMotor" magMotor.Part0=root magMotor.Part1=magazine magMotor.C0=magazine.CFrame magMotor.Parent=root
 for _,x in ipairs({-.29,.29}) do
  for z=-1.3,-.3,.25 do part("Rebaixo",Vector3.new(.035,.15,.12),Vector3.new(x,.23,z),dark) end
  part("Faixa",Vector3.new(.035,.08,.65),Vector3.new(x,.43,-.6),gold)
 end
 part("Mira traseira",Vector3.new(.38,.12,.25),Vector3.new(0,.7,.15),dark)
 for _,x in ipairs({-.13,.13}) do part("Mira lateral",Vector3.new(.07,.18,.12),Vector3.new(x,.78,.15),pale) end
 part("Mira frontal",Vector3.new(.06,.18,.1),Vector3.new(0,.78,-1.7),gold)
 for _,z in ipairs({-.9,-.55,-.2}) do part("Indicador",Vector3.new(.025,.06,.12),Vector3.new(-.298,.3,z),gold) end
 local function point(name,pos) local a=Instance.new("Attachment") a.Name=name a.CFrame=CFrame.new(pos) a.Parent=root return a end
 point("AimPoint",Vector3.new(0,.78,.65)) point("Muzzle",Vector3.new(0,.29,-3.38)) point("LeftGrip",Vector3.new(-.3,-.4,-1.0)) point("RightGripPoint",Vector3.new(.05,-.45,.1)) point("MagazinePivot",Vector3.new(0,-.46,-.65))
 m.Parent=parent return m
end
function F.Mount(tool)
 if tool:GetAttribute("FactoryRuntimeBuilt") then return end
 for _,old in ipairs(tool:GetChildren()) do if old:IsA("BasePart") or old:IsA("Model") then old:Destroy() end end
 tool:SetAttribute("FactoryRuntimeBuilt",true)
 local model=F.Build(nil) for _,p in ipairs(model:GetChildren()) do p.Parent=tool end model:Destroy()
end
return F
