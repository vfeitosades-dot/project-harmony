-- Rifle virtual original em pecas nativas, sem assets externos.
local F={}
local dark=Color3.fromRGB(35,47,65) local blue=Color3.fromRGB(47,139,171) local pale=Color3.fromRGB(182,203,214) local gold=Color3.fromRGB(255,197,80)
function F.Build(parent,scale)
 scale=scale or 1
 local m=Instance.new("Model") m.Name="RifleModel"
 local root=Instance.new("Part") root.Name="Handle" root.Size=Vector3.new(.25,.25,.25) root.CFrame=CFrame.new() root.Transparency=1 root.CanCollide=false root.CanTouch=false root.CanQuery=false root.Massless=true root.Parent=m m.PrimaryPart=root
 local magazine
 for _,d in ipairs(require(script.Parent.WeaponGeometry)) do
  local p=Instance.new(d.shape=="Wedge" and "WedgePart" or "Part") p.Name=d.name
  p.Size=Vector3.new(d.size[1],d.size[2],d.size[3])*scale
  p.CFrame=CFrame.new(Vector3.new(d.pos[1],d.pos[2],d.pos[3])*scale)*CFrame.Angles(math.rad(d.rot[1]),math.rad(d.rot[2]),math.rad(d.rot[3]))
  if d.shape=="Tube" then p.Shape=Enum.PartType.Cylinder p.Size=Vector3.new(d.size[3],d.size[1],d.size[2])*scale p.CFrame=p.CFrame*CFrame.Angles(0,math.pi/2,0) end
  p.Color=Color3.fromRGB(d.color[1],d.color[2],d.color[3]) p.Material=d.name=="Ponto reflex" and Enum.Material.Neon or Enum.Material.SmoothPlastic p.TopSurface=Enum.SurfaceType.Smooth p.BottomSurface=Enum.SurfaceType.Smooth
  p.Reflectance=0 p.CanCollide=false p.CanTouch=false p.CanQuery=false p.Massless=true p.Parent=m
  if d.name=="Magazine" then
   magazine=p p:SetAttribute("MagazinePart",true)
   local motor=Instance.new("Motor6D") motor.Name="MagazineMotor" motor.Part0=root motor.Part1=p motor.C0=p.CFrame motor.Parent=root
  else
   local parentPart=d.group=="Mag" and magazine or root
   if d.group=="Mag" then p:SetAttribute("MagazinePart",true) end
   local w=Instance.new("Weld") w.Part0=parentPart w.Part1=p w.C0=parentPart.CFrame:Inverse()*p.CFrame w.Parent=p
  end
 end
 local function point(name,pos) local a=Instance.new("Attachment") a.Name=name a.CFrame=CFrame.new(pos*scale) a.Parent=root return a end
 point("WorldLeftGrip",Vector3.new(-.58,-.08,-.24))
 point("AimPoint",Vector3.new(0,1.04,.55)) point("Muzzle",Vector3.new(0,.29,-3.38)) point("LeftGrip",Vector3.new(-.3,-.08,-.95)) point("RightGripPoint",Vector3.new(.05,-.3,.12)) point("MagazinePivot",Vector3.new(0,-.46,-.65))
 m.Parent=parent return m
end
function F.Mount(tool)
 if tool:GetAttribute("FactoryRuntimeBuilt") then return end
 for _,old in ipairs(tool:GetChildren()) do if old:IsA("BasePart") or old:IsA("Model") then old:Destroy() end end
 tool:SetAttribute("FactoryRuntimeBuilt",true)
 local model=F.Build(nil,.82) for _,p in ipairs(model:GetChildren()) do p.Parent=tool end model:Destroy()
end
return F
