local Players=game:GetService("Players") local Run=game:GetService("RunService") local RS=game:GetService("ReplicatedStorage")
local CS=game:GetService("CollectionService")
local C=require(script.Parent.WeaponConfig) local Anim=require(script.Parent.AnimationController) local Effects=require(script.Parent.WeaponEffects)
local T={} local rigs={} local shotAt={}
local function bind(p,char)
 local torso=char:WaitForChild("Torso",8) local h=char:FindFirstChildOfClass("Humanoid") local root=char:FindFirstChild("HumanoidRootPart") if not torso or not h or not root then return end
 if p:IsA("Player") and p.Character~=char then return end
 local j={} for _,v in ipairs(char:GetDescendants()) do if v:IsA("Motor6D") and v.Name~="WorldGrip" and v.Name~="MagazineMotor" then j[v.Name]=v end end
 rigs[p]={char=char,torso=torso,h=h,root=root,j=j,pose=CFrame.new(),magPose=CFrame.new(),phase=0,magAlpha=0}
end
local function arm(joint,torso,target,dt)
 if not joint or not joint.Parent then return end
 local shoulder=(torso.CFrame*joint.C0).Position local delta=target-shoulder if delta.Magnitude<.05 then return end
 local rotation=CFrame.lookAt(Vector3.zero,delta.Unit)*CFrame.Angles(math.pi/2,0,0)
 local desired=CFrame.new(target-delta.Unit)*rotation.Rotation
 local transform=joint.C0:Inverse()*torso.CFrame:ToObjectSpace(desired)*joint.C1
 joint.Transform=joint.Transform:Lerp(transform,1-math.exp(-dt*18))
end
function T.init()
 local function add(p) p.CharacterAdded:Connect(function(char) task.spawn(bind,p,char) end) if p.Character then task.spawn(bind,p,p.Character) end end
 Players.PlayerAdded:Connect(add) Players.PlayerRemoving:Connect(function(p) rigs[p]=nil shotAt[p]=nil end) for _,p in ipairs(Players:GetPlayers()) do add(p) end
 for _,bot in ipairs(CS:GetTagged("FPSDemoBot")) do task.spawn(bind,bot,bot) end
 CS:GetInstanceAddedSignal("FPSDemoBot"):Connect(function(bot) task.spawn(bind,bot,bot) end)
 CS:GetInstanceRemovedSignal("FPSDemoBot"):Connect(function(bot) rigs[bot]=nil end)
 RS.FPSSystem.Remotes.WeaponFX.OnClientEvent:Connect(function(id,a,b)
  local p=Players:GetPlayerByUserId(id) if p then shotAt[p]=workspace:GetServerTimeNow() end
  if id~=Players.LocalPlayer.UserId then Effects.Shot(a,b) end
 end)
 Run.PreSimulation:Connect(function(dt)
  local now=workspace:GetServerTimeNow() local alpha=1-math.exp(-dt*16)
  for p,r in pairs(rigs) do
   if not r.char.Parent then rigs[p]=nil continue end
   local speed=Vector3.new(r.root.AssemblyLinearVelocity.X,0,r.root.AssemblyLinearVelocity.Z).Magnitude r.phase+=speed*dt*1.15 local stride=math.sin(r.phase)*math.min(speed/16,1)*.7
   local jump=r.h.FloorMaterial==Enum.Material.Air and not r.root.Anchored
   for name,j in pairs(r.j) do if j.Parent then
    local target=CFrame.new()
    if name=="Right Hip" then target=CFrame.Angles(jump and -.25 or stride,0,0) elseif name=="Left Hip" then target=CFrame.Angles(jump and .25 or -stride,0,0)
    elseif name=="Right Shoulder" then target=CFrame.Angles(-stride,0,.04) elseif name=="Left Shoulder" then target=CFrame.Angles(stride,0,-.04)
    elseif name=="RootJoint" then target=CFrame.new(0,math.sin(now*2)*.02,0) end
    local basis=j.C0.Rotation j.Transform=j.Transform:Lerp(basis:Inverse()*target*basis,alpha)
   end end
   local tool=r.char:FindFirstChild("Rifle") local handle=tool and tool:FindFirstChild("Handle") local grip=handle and handle:FindFirstChild("WorldGrip")
   if handle and grip then
    local age=now-(tool:GetAttribute("EquippedAt") or now) local reloadEnd=tool:GetAttribute("ReloadEnd") or 0 local inspectEnd=tool:GetAttribute("InspectEnd") or 0 local running=tool:GetAttribute("Running")
    local state=Anim.State(true,age,reloadEnd>now,inspectEnd>now,running,tool:GetAttribute("Aiming"),now-(shotAt[p] or -1e5)<.12)
    local phase=state=="Reloading" and now-(reloadEnd-C.ReloadTime) or state=="Inspecting" and now-(inspectEnd-C.InspectTime) or age
    local pose,left,mag=Anim.Sample(state,math.max(0,phase))
    if state=="Running" then pose=CFrame.new(.1,-.2,.1)*CFrame.Angles(-.25,.15,.15) end
    if tool:GetAttribute("Aiming") then pose=CFrame.new(0,.65,.05)*pose end
    local since=now-(shotAt[p] or -1e5) if since>=0 and since<.15 then pose=pose*CFrame.new(0,0,.08*math.exp(-since*25))*CFrame.Angles(.035*math.exp(-since*25),0,0) end
    r.pose=r.pose:Lerp(CFrame.Angles(tool:GetAttribute("AimPitch") or 0,0,0)*pose,alpha) r.magPose=r.magPose:Lerp(mag,alpha) grip.Transform=r.pose
    local neck=r.j.Neck
    if neck and neck.Parent then local basis=neck.C0.Rotation local target=CFrame.Angles((tool:GetAttribute("AimPitch") or 0)*.4,0,0) neck.Transform=neck.Transform:Lerp(basis:Inverse()*target*basis,alpha) end
    local gunCF=r.torso.CFrame*grip.C0*r.pose
    local right=handle:FindFirstChild("RightGripPoint") local support=handle:FindFirstChild("LeftGrip")
    if right then arm(r.j["Right Shoulder"],r.torso,(gunCF*right.CFrame).Position,dt) end
    if support then
     local target=support.CFrame*left
     if state=="Reloading" then target=support.CFrame:Lerp(handle.MagazinePivot.CFrame*r.magPose*CFrame.new(-.25,0,0),Anim.ReloadHandWeight(phase)) end
     arm(r.j["Left Shoulder"],r.torso,(gunCF*target).Position,dt)
    end
    local magazine=handle:FindFirstChild("MagazineMotor") if magazine then magazine.Transform=r.magPose end
    local targetAlpha=state=="Reloading" and Anim.MagazineAlpha(phase) or 0 r.magAlpha+=(targetAlpha-r.magAlpha)*alpha
    for _,part in ipairs(tool:GetDescendants()) do if part:IsA("BasePart") and part:GetAttribute("MagazinePart") then part.Transparency=r.magAlpha end end
   end
  end
 end)
end
return T
