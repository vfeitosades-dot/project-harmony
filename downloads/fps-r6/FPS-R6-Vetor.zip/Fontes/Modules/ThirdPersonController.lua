local Players=game:GetService("Players") local Run=game:GetService("RunService") local RS=game:GetService("ReplicatedStorage")
local CS=game:GetService("CollectionService")
local C=require(script.Parent.WeaponConfig) local Anim=require(script.Parent.AnimationController) local Effects=require(script.Parent.WeaponEffects)
local T={} local rigs={} local bases={} local poses={}
local function unbind(p)
 local r=rigs[p] if r then for _,j in pairs(r.j) do bases[j]=nil poses[j]=nil end end rigs[p]=nil
end
local function apply(j,target,alpha)
 local base=bases[j] if not base then base=j.C0 bases[j]=base poses[j]=CFrame.new() end
 poses[j]=poses[j]:Lerp(target,alpha) j.Transform=CFrame.new() j.C0=base*poses[j]
end
local function bind(p,char)
 if rigs[p] and rigs[p].char==char then return end
 local torso=char:WaitForChild("Torso",8) local h=char:WaitForChild("Humanoid",10) local root=char:WaitForChild("HumanoidRootPart",10) if not torso or not h or not root then return end
 if p:IsA("Player") and p.Character~=char then return end
 for _,name in ipairs({"Right Shoulder","Left Shoulder","Right Hip","Left Hip","Neck"}) do if not torso:WaitForChild(name,10) then return end end
 unbind(p)
 local j={} for _,v in ipairs(char:GetDescendants()) do if v:IsA("Motor6D") and v.Name~="WorldGrip" and v.Name~="MagazineMotor" then j[v.Name]=v bases[v]=v.C0 poses[v]=CFrame.new() end end
 rigs[p]={char=char,torso=torso,h=h,root=root,j=j,pose=CFrame.new(),magPose=CFrame.new(),phase=0,moveWeight=0,runWeight=0,magAlpha=0}
end
local function arm(joint,torso,target,dt)
 if not joint or not joint.Parent then return end
 local base=bases[joint] or joint.C0
 local part=joint.Part1 if not part then return end
 local half=part.Size.Y*.5
 -- Solve the palm at the actual bottom of the R6 arm, not its centre.
 local rest=torso.CFrame*base*joint.C1:Inverse()
 local shoulder=(rest*CFrame.new(0,half,0)).Position
 local delta=target-shoulder if delta.Magnitude<.05 then return end
 -- Roll around the arm length: keep the palm contact, turn sleeves outward.
 local roll=joint.Name=="Right Shoulder" and -.3 or .4
 local rotation=CFrame.lookAt(Vector3.zero,delta.Unit)*CFrame.Angles(math.pi/2,0,0)*CFrame.Angles(0,roll,0)
 local desired=CFrame.new(target-delta.Unit*half)*rotation.Rotation
 local transform=base:Inverse()*torso.CFrame:ToObjectSpace(desired)*joint.C1
 -- Weapon motion is already smoothed. A second arm lerp breaks palm contact.
 apply(joint,transform,1)
end
function T.init(serverMode)
 if not serverMode then
  -- Animator.Transform is client-local; neutralize its tool/idle arm offsets
  -- after animation evaluation, preserving the replicated server C0 pose.
  Run.PreSimulation:Connect(function()
   for _,player in ipairs(Players:GetPlayers()) do
    local char=player.Character local torso=char and char:FindFirstChild("Torso") local tool=char and char:FindFirstChild("Rifle")
    if torso and tool and tool:FindFirstChild("Handle") and tool.Handle:FindFirstChild("WorldGrip") then
     for _,name in ipairs({"Right Shoulder","Left Shoulder","Neck"}) do local joint=torso:FindFirstChild(name) if joint then joint.Transform=CFrame.new() end end
     tool.Handle.WorldGrip.Transform=CFrame.new() local mag=tool.Handle:FindFirstChild("MagazineMotor") if mag then mag.Transform=CFrame.new() end
    end
   end
  end)
  RS:WaitForChild("FPSSystem"):WaitForChild("Remotes"):WaitForChild("WeaponFX").OnClientEvent:Connect(function(id,a,b,normal)
   if id~=Players.LocalPlayer.UserId then Effects.Shot(a,b,normal) end
  end)
  return
 end
 local function add(p) p.CharacterAdded:Connect(function(char) task.spawn(bind,p,char) end) if p.Character then task.spawn(bind,p,p.Character) end end
 Players.PlayerAdded:Connect(add) Players.PlayerRemoving:Connect(unbind) for _,p in ipairs(Players:GetPlayers()) do add(p) end
 for _,bot in ipairs(CS:GetTagged("FPSDemoBot")) do task.spawn(bind,bot,bot) end
 CS:GetInstanceAddedSignal("FPSDemoBot"):Connect(function(bot) task.spawn(bind,bot,bot) end)
 CS:GetInstanceRemovedSignal("FPSDemoBot"):Connect(function(bot) unbind(bot) end)
 local accumulated=0
 Run.Heartbeat:Connect(function(dt)
  accumulated+=dt if accumulated<1/30 then return end dt=accumulated accumulated=0
  local now=workspace:GetServerTimeNow() local alpha=1-math.exp(-dt*16)
  for p,r in pairs(rigs) do
   if not r.char.Parent then unbind(p) continue end
   local speed=Vector3.new(r.root.AssemblyLinearVelocity.X,0,r.root.AssemblyLinearVelocity.Z).Magnitude
   if speed<1 or r.root.Anchored then speed=0 end
   local held=r.char:FindFirstChild("Rifle") local sprint=held and held:GetAttribute("Running")==true
   r.moveWeight+=(math.clamp(speed/C.WalkSpeed,0,1)-r.moveWeight)*alpha
   r.runWeight+=((sprint and 1 or 0)-r.runWeight)*alpha
   r.phase+=dt*(7.5+3.5*r.runWeight)*math.clamp(speed/C.WalkSpeed,0,1.5)
   local stride=math.sin(r.phase)*(.5+.4*r.runWeight)*r.moveWeight
   local jump=r.h.FloorMaterial==Enum.Material.Air and not r.root.Anchored
   for name,j in pairs(r.j) do if j.Parent and not (held and (name=="Right Shoulder" or name=="Left Shoulder")) then
    local target=CFrame.new()
    if name=="Right Hip" then target=CFrame.Angles(jump and -.25 or stride,0,0) elseif name=="Left Hip" then target=CFrame.Angles(jump and .25 or -stride,0,0)
    elseif name=="Right Shoulder" then target=CFrame.Angles(-stride,0,.04) elseif name=="Left Shoulder" then target=CFrame.Angles(stride,0,-.04)
    elseif name=="RootJoint" then target=CFrame.new(0,math.sin(now*2)*.012,0)*CFrame.Angles(-.12*r.runWeight*r.moveWeight,0,0) end
    local basis=bases[j].Rotation apply(j,basis:Inverse()*target*basis,alpha)
   end end
   local tool=r.char:FindFirstChild("Rifle") local handle=tool and tool:FindFirstChild("Handle") local grip=handle and handle:FindFirstChild("WorldGrip")
   if handle and grip then
    local age=now-(tool:GetAttribute("EquippedAt") or now) local reloadEnd=tool:GetAttribute("ReloadEnd") or 0 local inspectEnd=tool:GetAttribute("InspectEnd") or 0 local running=tool:GetAttribute("Running")
    local state=Anim.State(true,age,reloadEnd>now,inspectEnd>now,running,tool:GetAttribute("Aiming"),now-(r.char:GetAttribute("FPSLastShotAt") or -1e5)<.12)
    local phase=state=="Reloading" and now-(reloadEnd-C.ReloadTime) or state=="Inspecting" and now-(inspectEnd-C.InspectTime) or age
    local pose,left,mag=Anim.Sample(state,math.max(0,phase))
    local stance=CFrame.Angles(-.14,-.06,.025)
    if state=="Running" then stance=CFrame.new(.05,-.22,.1)*CFrame.Angles(-.45,.1,.1)
    elseif tool:GetAttribute("Aiming") then stance=CFrame.new(.08,.28,-.1)*CFrame.Angles(0,-.025,0) end
    local moving=math.clamp(speed/C.WalkSpeed,0,1)*(tool:GetAttribute("Aiming") and .2 or 1)
    local breathe=CFrame.new(0,math.sin(now*2)*.008,0)
    local walk=CFrame.new(math.sin(r.phase)*.012*moving,math.cos(r.phase*2)*.016*moving,0)
    pose=stance*breathe*walk*pose
    local since=now-(r.char:GetAttribute("FPSLastShotAt") or -1e5) if since>=0 and since<.15 then pose=pose*CFrame.new(0,0,.08*math.exp(-since*25))*CFrame.Angles(.035*math.exp(-since*25),0,0) end
    r.pose=r.pose:Lerp(CFrame.Angles(tool:GetAttribute("AimPitch") or 0,0,0)*pose,alpha) r.magPose=r.magPose:Lerp(mag,alpha) if r.grip~=grip then r.grip=grip r.gripBase=grip.C0 end
    grip.Transform=CFrame.new() grip.C0=r.gripBase*r.pose
    local neck=r.j.Neck
    if neck and neck.Parent then local basis=bases[neck].Rotation local target=CFrame.Angles((tool:GetAttribute("AimPitch") or 0)*.4,0,0) apply(neck,basis:Inverse()*target*basis,alpha) end
    local gunCF=r.torso.CFrame*grip.C0
    local right=handle:FindFirstChild("RightGripPoint") local support=handle:FindFirstChild("LeftGrip")
    if right then arm(r.j["Right Shoulder"],r.torso,(gunCF*right.CFrame).Position,dt) end
    if support then
     local target=support.CFrame*left
     if state=="Reloading" then target=support.CFrame:Lerp(handle.MagazinePivot.CFrame*r.magPose*CFrame.new(-.25,0,0),Anim.ReloadHandWeight(phase)) end
     arm(r.j["Left Shoulder"],r.torso,(gunCF*target).Position,dt)
    end
    local magazine=handle:FindFirstChild("MagazineMotor") if magazine then if r.magazine~=magazine then r.magazine=magazine r.magBase=magazine.C0 end magazine.Transform=CFrame.new() magazine.C0=r.magBase*r.magPose end
    local targetAlpha=state=="Reloading" and Anim.MagazineAlpha(phase) or 0 r.magAlpha+=(targetAlpha-r.magAlpha)*alpha
    for _,part in ipairs(tool:GetDescendants()) do if part:IsA("BasePart") and part:GetAttribute("MagazinePart") then part.Transparency=r.magAlpha end end
   end
  end
 end)
end
return T
