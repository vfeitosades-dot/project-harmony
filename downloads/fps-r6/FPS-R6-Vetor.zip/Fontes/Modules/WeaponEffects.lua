local Debris=game:GetService("Debris") local Tween=game:GetService("TweenService")
local E={}
function E.Shot(a,b)
 local distance=(b-a).Magnitude
 if distance>.01 then
  local p=Instance.new("Part") p.Name="TracerVirtual" p.Anchored=true p.CanCollide=false p.CanTouch=false p.CanQuery=false p.Material=Enum.Material.Neon p.Color=Color3.fromRGB(255,208,116) p.Size=Vector3.new(.025,.025,math.min(distance,500)) p.CFrame=CFrame.lookAt((a+b)/2,b) p.Parent=workspace Debris:AddItem(p,.065)
 end
 local flash=Instance.new("Part") flash.Shape=Enum.PartType.Ball flash.Size=Vector3.new(.16,.16,.16) flash.Position=a flash.Material=Enum.Material.Neon flash.Color=Color3.fromRGB(255,214,134) flash.Anchored=true flash.CanCollide=false flash.CanTouch=false flash.CanQuery=false flash.Parent=workspace Debris:AddItem(flash,.045)
 local chip=Instance.new("Part") chip.Size=Vector3.new(.08,.08,.08) chip.Position=b chip.Color=Color3.fromRGB(145,198,214) chip.Anchored=true chip.CanCollide=false chip.CanTouch=false chip.CanQuery=false chip.Parent=workspace
 Tween:Create(chip,TweenInfo.new(.2),{Transparency=1,Size=Vector3.new(.2,.2,.2)}):Play() Debris:AddItem(chip,.22)
end
return E
