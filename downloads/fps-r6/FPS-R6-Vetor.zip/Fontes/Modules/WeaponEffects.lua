-- Local, short-lived effects. No physical forces or external texture assets.
local Debris=game:GetService("Debris") local Tween=game:GetService("TweenService")
local E={}
local warm=Color3.fromRGB(255,201,104)
local function part(name,size,cf,color,material,alpha)
 local p=Instance.new("Part") p.Name=name p.Size=size p.CFrame=cf p.Color=color p.Material=material
 p.Transparency=alpha or 0 p.Anchored=true p.CanCollide=false p.CanTouch=false p.CanQuery=false p.CastShadow=false p.Parent=workspace
 return p
end
local function fade(p,duration,goal)
 Tween:Create(p,TweenInfo.new(duration),goal):Play() Debris:AddItem(p,duration+.03)
end
function E.Shot(a,b,normal)
 local delta=b-a if delta.Magnitude<.01 then return end
 local forward=CFrame.lookAt(a,b)
 local tracer=part("TracerVirtual",Vector3.new(.018,.018,math.min(delta.Magnitude,500)),CFrame.lookAt((a+b)/2,b),warm,Enum.Material.Neon,.25)
 fade(tracer,.065,{Transparency=1})
 local flash=part("MuzzleFlash",Vector3.new(.12,.12,.38),forward*CFrame.new(0,0,-.12),warm,Enum.Material.Neon,.12)
 flash.Shape=Enum.PartType.Ball
 local light=Instance.new("PointLight") light.Color=warm light.Brightness=2 light.Range=7 light.Shadows=false light.Parent=flash
 fade(flash,.045,{Transparency=1,Size=Vector3.new(.025,.025,.1)})
 -- Cross-shaped flash gives a crisp arcade silhouette without texture assets.
 for i=1,2 do
  local petal=part("MuzzlePetal",Vector3.new(.28,.035,.2),forward*CFrame.new(0,0,-.18)*CFrame.Angles(0,0,i*math.pi/2+.3),warm,Enum.Material.Neon,.25)
  fade(petal,.04,{Transparency=1,Size=Vector3.new(.07,.015,.05)})
 end
 local shell=part("Cartridge",Vector3.new(.06,.12,.06),forward*CFrame.new(.16,-.06,.35),Color3.fromRGB(194,157,78),Enum.Material.SmoothPlastic)
 fade(shell,.24,{Transparency=1,CFrame=forward*CFrame.new(.7,-.42,.6)*CFrame.Angles(1.6,.8,2.2)})
 local smoke=part("MuzzleSmoke",Vector3.new(.12,.12,.18),forward*CFrame.new(0,.04,-.28),Color3.fromRGB(163,176,184),Enum.Material.SmoothPlastic,.85)
 smoke.Shape=Enum.PartType.Ball fade(smoke,.22,{Transparency=1,Size=Vector3.new(.4,.4,.5),CFrame=forward*CFrame.new(0,.2,-.55)})
 -- A miss ends at range and must not produce an impact floating in the sky.
 if typeof(normal)~="Vector3" or normal.Magnitude<.5 then return end
 local surface=CFrame.lookAt(b+normal*.025,b+normal,math.abs(normal.Y)>.95 and Vector3.new(0,0,1) or Vector3.new(0,1,0))
 local ring=part("ImpactGlow",Vector3.new(.13,.13,.025),surface,Color3.fromRGB(255,217,151),Enum.Material.Neon,.1)
 fade(ring,.16,{Transparency=1,Size=Vector3.new(.3,.3,.025)})
 local mark=part("ImpactMark",Vector3.new(.1,.1,.012),surface,Color3.fromRGB(65,68,73),Enum.Material.SmoothPlastic,.3)
 fade(mark,.65,{Transparency=1})
 local dust=part("ImpactDust",Vector3.new(.16,.16,.16),surface,Color3.fromRGB(167,160,143),Enum.Material.SmoothPlastic,.6)
 dust.Shape=Enum.PartType.Ball fade(dust,.28,{Transparency=1,Size=Vector3.new(.55,.55,.55),CFrame=surface*CFrame.new(0,.12,-.22)})
 for i=1,3 do
  local angle=i*2.399 local offset=Vector3.new(math.cos(angle)*.25,math.sin(angle)*.25,-.35)
  local spark=part("ImpactSpark",Vector3.new(.025,.025,.11),surface,warm,Enum.Material.Neon)
  fade(spark,.1+i*.018,{Transparency=1,CFrame=surface*CFrame.new(offset)})
 end
end
return E
