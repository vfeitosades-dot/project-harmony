--!strict
return table.freeze({
 Name="VETOR-30", DebugHUD=false, Magazine=30, Reserve=90, Damage=20, Critical=1.5,
 FireInterval=.11, ReloadTime=1.65, EquipTime=.45, UnequipTime=.3, InspectTime=2.5,
 Range=500, FOV=70, ADSFOV=55, ADSTime=.22, WalkSpeed=16, RunSpeed=22,
 LOBBY={ORIGIN=Vector3.new(0,4,16)},RUNNER={WALKSPEED=16,JUMPPOWER=50},
 Sounds={}, -- Silencioso ate configurar audios proprios/licenciados.
})
