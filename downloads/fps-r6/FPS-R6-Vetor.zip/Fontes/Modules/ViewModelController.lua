local Factory=require(script.Parent.WeaponFactory)
local Spring=require(script.Parent.Spring)
local Recoil=require(script.Parent.Recoil)
local Anim=require(script.Parent.AnimationController)
local C=require(script.Parent.WeaponConfig)
local V={} V.__index=V
function V.new(camera)
 local model=Instance.new("Model") model.Name="R6ViewModel"
 local root=Instance.new("Part") root.Name="CameraRoot" root.Size=Vector3.new(.1,.1,.1) root.CFrame=CFrame.new() root.Transparency=1 root.Anchored=true root.CanCollide=false root.CanQuery=false root.CanTouch=false root.Parent=model model.PrimaryPart=root
 local gun=Factory.Build(model) local handle=gun.Handle for _,p in ipairs(gun:GetDescendants()) do if p:IsA("BasePart") then p.CastShadow=false end end
 local joint=Instance.new("Motor6D") joint.Name="WeaponMotor" joint.Part0=root joint.Part1=handle joint.Parent=root
 local function arm(name,point,angle)
  local p=Instance.new("Part") p.Name=name p.Size=Vector3.new(.8,1.8,.8) p.TopSurface=Enum.SurfaceType.Smooth p.BottomSurface=Enum.SurfaceType.Smooth p.Color=Color3.fromRGB(240,194,124) p.Material=Enum.Material.SmoothPlastic p.CanCollide=false p.CanQuery=false p.CanTouch=false p.Massless=true p.CastShadow=false p.Parent=model
  local rot=CFrame.Angles(angle,0,name=="LeftArm" and .12 or -.12)
  local motor=Instance.new("Motor6D") motor.Name=name.."Joint" motor.Part0=handle motor.Part1=p motor.C0=point.CFrame*rot*CFrame.new(0,.9,0) motor.Parent=handle p.CFrame=motor.C0
  return motor
 end
 local right=arm("RightArm",handle.RightGripPoint,1.1) local left=arm("LeftArm",handle.LeftGrip,1.15)
 local controller=Instance.new("AnimationController") controller.Parent=model local animator=Instance.new("Animator") animator.Parent=controller
 model.Parent=camera
 return setmetatable({model=model,root=root,gun=gun,joint=joint,right=right,left=left,leftBase=left.C0,leftRotation=CFrame.Angles(1.15,0,.12),mag=handle.MagazineMotor,magBase=handle.MagazineMotor.C0,magAlpha=0,recoil=Recoil.new(),sway=Spring.new(Vector3.zero,14),aim=0,run=0,phase=0,pose=CFrame.new(),leftPose=CFrame.new(),magPose=CFrame.new()},V)
end
function V:Fire() self.recoil:Fire(self.aim>.5) end
function V:Step(dt,camera,info,mouse)
 local smoothing=1-math.exp(-dt*16)
 self.aim+=((info.aim and 1 or 0)-self.aim)*(1-math.exp(-dt/C.ADSTime*4)) self.run+=((info.running and 1 or 0)-self.run)*smoothing
 local gunPose,leftPose,magPose=Anim.Sample(info.state,info.time)
 if info.state=="Running" then gunPose=CFrame.new(.12,-.22,.12)*CFrame.Angles(-.2,.15,.15) end
 self.pose=self.pose:Lerp(gunPose,smoothing) self.leftPose=self.leftPose:Lerp(leftPose,smoothing) self.magPose=self.magPose:Lerp(magPose,smoothing)
 local targetAlpha=info.state=="Reloading" and Anim.MagazineAlpha(info.time) or 0 self.magAlpha+=(targetAlpha-self.magAlpha)*smoothing self.gun.Magazine.Transparency=self.magAlpha
 self.mag.C0=self.magBase*self.magPose
 local leftTarget=self.leftBase
 if info.state=="Reloading" then
  local hand=self.gun.Handle.LeftGrip.CFrame:Lerp(self.magBase*self.magPose*CFrame.new(-.25,0,0),Anim.ReloadHandWeight(info.time))
  leftTarget=hand*self.leftRotation*CFrame.new(0,.9,0) self.left.Transform=CFrame.new()
 else self.left.Transform=self.leftPose end
 self.left.C0=self.left.C0:Lerp(leftTarget,smoothing)
 local kick=self.recoil:Step(dt) self.right.Transform=CFrame.Angles(kick.X*.3,0,0)
 local rate=mouse/math.max(dt,1/300)
 self.sway.target=Vector3.new(math.clamp(-rate.Y*.000012,-.025,.025),math.clamp(-rate.X*.000012,-.025,.025),0)
 local sway=self.sway:Step(dt)*(1-self.aim) self.phase+=info.speed*dt*1.1
 local moving=math.clamp(info.speed/16,0,1)
 local bob=Vector3.new(math.sin(self.phase)*.018,math.cos(self.phase*2)*.025,0)*moving*(1-self.aim)
 local breath=Vector3.new(0,math.sin(os.clock()*3.49)*.0035,0)*(1-self.aim)
 local offset=CFrame.new(.65,-.8,-1.2):Lerp(self.gun.Handle.AimPoint.CFrame:Inverse(),self.aim)
 local visualKick=CFrame.new(0,0,kick.X*6)*CFrame.Angles(kick.X,kick.Y,0)
 self.root.CFrame=camera.CFrame
 self.joint.C0=offset*CFrame.new(bob+breath)*CFrame.Angles(sway.X,sway.Y,0)*self.pose*visualKick
 return CFrame.Angles(kick.X,kick.Y,0),self.aim
end
function V:Destroy() if self.model then self.model:Destroy() end end
return V
