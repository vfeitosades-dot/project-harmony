local Players=game:GetService("Players") local Input=game:GetService("UserInputService") local Run=game:GetService("RunService") local Gui=game:GetService("GuiService")
local System=game:GetService("ReplicatedStorage").FPSSystem local R=System.Remotes
local C=require(script.Parent.WeaponConfig) local Anim=require(script.Parent.AnimationController) local View=require(script.Parent.ViewModelController) local HUD=require(script.Parent.HUD) local Effects=require(script.Parent.WeaponEffects)
local Controller={} Controller.__index=Controller local active
local function now() return workspace:GetServerTimeNow() end
function Controller:Cleanup()
 self.token+=1 self.equipped=false self.holding=false self.wantAim=false self.wantRun=false
 if self.vm then self.vm:Destroy() self.vm=nil end
 if self.descendant then self.descendant:Disconnect() self.descendant=nil end
 for object,value in pairs(self.hidden) do if object.Parent then if object:IsA("BasePart") then object.LocalTransparencyModifier=value else object.Enabled=value end end end self.hidden={}
 if active==self then
  Run:UnbindFromRenderStep("VetorFPSPre") Run:UnbindFromRenderStep("VetorFPSPost")
  local camera=workspace.CurrentCamera if camera then camera.CFrame=camera.CFrame*self.lastKick:Inverse() camera.FieldOfView=self.oldFOV or C.FOV end self.lastKick=CFrame.new()
  Players.LocalPlayer.CameraMode=self.oldMode or Enum.CameraMode.Classic Input.MouseIconEnabled=self.oldIcon~=false Input.MouseBehavior=self.oldMouse or Enum.MouseBehavior.Default
  self.hud:SetVisible(false) active=nil
 end
end
function Controller:Equip()
 if active then active:Cleanup() end self:Cleanup() active=self
 self.token+=1 self.equipped=true self.at=now() self.lastFire=-1e5 self.pending={} self.sentAim=false self.sentRun=false
 local camera=workspace.CurrentCamera self.oldFOV=camera.FieldOfView self.oldMode=Players.LocalPlayer.CameraMode self.oldMouse=Input.MouseBehavior self.oldIcon=Input.MouseIconEnabled
 Players.LocalPlayer.CameraMode=Enum.CameraMode.LockFirstPerson Input.MouseIconEnabled=false
 self.vm=View.new(camera) self.hud:SetVisible(true)
 local char=Players.LocalPlayer.Character self.character=char
 local function hide(obj)
  if obj:IsA("BasePart") then if self.hidden[obj]==nil then self.hidden[obj]=obj.LocalTransparencyModifier end obj.LocalTransparencyModifier=1
  elseif obj:IsA("SurfaceGui") or obj:IsA("BillboardGui") then if self.hidden[obj]==nil then self.hidden[obj]=obj.Enabled end obj.Enabled=false end
 end
 if char then for _,obj in ipairs(char:GetDescendants()) do hide(obj) end self.descendant=char.DescendantAdded:Connect(hide) end
 R.Action:FireServer("Sync")
 Run:BindToRenderStep("VetorFPSPre",Enum.RenderPriority.Camera.Value-1,function()
  local cam=workspace.CurrentCamera if cam then cam.CFrame=cam.CFrame*self.lastKick:Inverse() end self.lastKick=CFrame.new()
 end)
 Run:BindToRenderStep("VetorFPSPost",Enum.RenderPriority.Camera.Value+1,function(dt) self:Step(dt) end)
end
function Controller:Unequip()
 if not self.vm then self:Cleanup() return end
 self.equipped=false self.holding=false self.wantAim=false self.wantRun=false self.exitAt=now() self.token+=1 local token=self.token
 task.delay(C.UnequipTime,function() if self.token==token then self:Cleanup() end end)
end
function Controller:Reload()
 if not self.equipped or self.life==0 or self.reloading or now()<self.at+C.EquipTime or self:Ammo()>=C.Magazine or self.reserve<=0 then return end
 self.wantRun=false self.sentRun=false R.Action:FireServer("Run",false)
 self.reloadRequestedAt=now() self.reloading=true self.reloadEnd=now()+C.ReloadTime self.inspectEnd=0 R.Reload:FireServer(self.life)
end
function Controller:Inspect()
 if not self.equipped or self.reloading or now()<self.at+C.EquipTime then return end
 self.wantAim=false self.wantRun=false self.holding=false
 if self.inspectEnd>now() then self.inspectEnd=0 R.Action:FireServer("CancelInspect") else self.inspectEnd=now()+C.InspectTime R.Action:FireServer("Inspect") end
end
function Controller:Ammo() local count=0 for seq in pairs(self.pending) do if seq>self.ack then count+=1 end end return math.max(0,self.ammo-count) end
function Controller:Shoot()
 if not self.equipped or self.life==0 or self.reloading or not self.serverEquipped or now()<self.readyAt or now()<self.at+C.EquipTime or now()-self.lastFire<C.FireInterval then return end
 if self:Ammo()<=0 then self:Reload() return end
 self.lastFire=now() self.inspectEnd=0 self.seq+=1 self.pending[self.seq]=true self.vm:Fire()
 local camera=workspace.CurrentCamera local direction=camera.CFrame.LookVector
 R.Fire:FireServer(self.life,self.seq,camera.CFrame.Position,direction)
 local params=RaycastParams.new() params.FilterType=Enum.RaycastFilterType.Exclude params.FilterDescendantsInstances={self.character,self.vm.model} params.IgnoreWater=true
 local hit=workspace:Raycast(camera.CFrame.Position,direction*C.Range,params)
 local muzzle=self.vm.gun.Handle.Muzzle.WorldPosition Effects.Shot(muzzle,hit and hit.Position or camera.CFrame.Position+direction*C.Range)
end
function Controller:Step(dt)
 if active~=self or not self.vm then return end
 local char=Players.LocalPlayer.Character local h=char and char:FindFirstChildOfClass("Humanoid")
 if char~=self.character or not h or h.Health<=0 then self:Cleanup() return end
 if Input:GetFocusedTextBox() then self.holding=false self.wantAim=false self.wantRun=false end
 if self.equipped and not Input.TouchEnabled and not Input:GetFocusedTextBox() then
  if Input.IsKeyDown then self.wantRun=Input:IsKeyDown(Enum.KeyCode.LeftShift) or Input:IsKeyDown(Enum.KeyCode.RightShift) end
  if self.holding and Input.IsMouseButtonPressed and not Input:IsMouseButtonPressed(Enum.UserInputType.MouseButton1) then self.holding=false end
 end
 local t=now() local age=t-self.at local busy=self.reloading or age<C.EquipTime or not self.equipped
 local aim=self.wantAim and not busy
 local running=self.wantRun and not self.wantAim and not self.holding and not busy and h.MoveDirection.Magnitude>.05
 if self.equipped then
  local pitch=math.clamp(math.asin(math.clamp(workspace.CurrentCamera.CFrame.LookVector.Y,-1,1)),-1.1,1.1)
  if t-(self.pitchAt or 0)>.125 and math.abs(pitch-(self.pitch or 0))>.025 then self.pitchAt=t self.pitch=pitch R.Action:FireServer("Pitch",pitch) end
  if self.reloadRequestedAt and t-self.reloadRequestedAt>.4 then self.reloadRequestedAt=nil R.Action:FireServer("Sync") end
  if aim~=self.sentAim then self.sentAim=aim R.Action:FireServer("Aim",aim) end
  if running~=self.sentRun then self.sentRun=running R.Action:FireServer("Run",running) end
 end
 if (aim or running or self.holding) and self.inspectEnd>t then self.inspectEnd=0 R.Action:FireServer("CancelInspect") end
 if self.holding and not Input:GetFocusedTextBox() then self:Shoot() end
 local state=Anim.State(self.equipped,age,self.reloading,self.inspectEnd>t,running,aim,t-self.lastFire<.12,h.MoveDirection.Magnitude>.05)
 local phase=state=="Reloading" and t-(self.reloadEnd-C.ReloadTime) or state=="Inspecting" and t-(self.inspectEnd-C.InspectTime) or state=="Unequipping" and t-self.exitAt or age
 local root=char:FindFirstChild("HumanoidRootPart") local speed=root and h.MoveDirection.Magnitude>.05 and h.FloorMaterial~=Enum.Material.Air and Vector3.new(root.AssemblyLinearVelocity.X,0,root.AssemblyLinearVelocity.Z).Magnitude or 0
 local camera=workspace.CurrentCamera local kick,alpha=self.vm:Step(dt,camera,{state=state,time=math.max(0,phase),speed=speed,running=running,aim=aim},Input:GetMouseDelta())
 camera.CFrame=camera.CFrame*kick self.lastKick=kick self.vm.root.CFrame=camera.CFrame
 camera.FieldOfView=self.oldFOV+(C.ADSFOV-self.oldFOV)*alpha
 self.hud:Tick(alpha) self.hud:Update(self:Ammo(),self.reserve,state,self.reloading and math.clamp(phase/C.ReloadTime,0,1) or 0,phase)
end
function Controller.attach(tool)
 local self=setmetatable({tool=tool,token=0,connections={},hidden={},pending={},life=0,revision=0,seq=0,ack=0,ammo=C.Magazine,reserve=C.Reserve,reloading=false,reloadEnd=0,inspectEnd=0,readyAt=0,equipped=false,lastKick=CFrame.new()},Controller)
 self.hud=HUD.new({fire=function(v) if self.equipped then self.holding=v end end,aim=function() self.wantAim=not self.wantAim end,run=function() self.wantRun=not self.wantRun end,reload=function() self:Reload() end,inspect=function() self:Inspect() end})
 local function connect(signal,fn) table.insert(self.connections,signal:Connect(fn)) end
 connect(tool.Equipped,function() self:Equip() end) connect(tool.Unequipped,function() self:Unequip() end)
 connect(tool.Activated,function() if self.equipped then self.holding=true end end) connect(tool.Deactivated,function() self.holding=false end)
 connect(Input.InputBegan,function(i,processed)
  if not self.equipped or processed or Input:GetFocusedTextBox() then return end
  if i.UserInputType==Enum.UserInputType.MouseButton1 then self.holding=true elseif i.UserInputType==Enum.UserInputType.MouseButton2 then self.wantAim=true
  elseif i.KeyCode==Enum.KeyCode.R then self:Reload() elseif i.KeyCode==Enum.KeyCode.H then self:Inspect() elseif (i.KeyCode==Enum.KeyCode.LeftShift or i.KeyCode==Enum.KeyCode.RightShift) then self.wantRun=true end
 end)
 connect(Input.InputEnded,function(i)
  if i.UserInputType==Enum.UserInputType.MouseButton1 then self.holding=false elseif i.UserInputType==Enum.UserInputType.MouseButton2 then self.wantAim=false elseif (i.KeyCode==Enum.KeyCode.LeftShift or i.KeyCode==Enum.KeyCode.RightShift) then self.wantRun=false end
 end)
 local function release() self.holding=false self.wantAim=false self.wantRun=false end
 connect(Input.WindowFocusReleased,release) connect(Gui.MenuOpened,release)
 connect(R.State.OnClientEvent,function(d)
  if type(d)~="table" or d.life<self.life or (d.life==self.life and d.revision<=self.revision) then return end
  if d.life~=self.life then self.life=d.life self.seq=0 self.ack=0 self.pending={} end
  self.revision=d.revision self.ammo=d.ammo self.reserve=d.reserve self.ack=d.ack self.seq=math.max(self.seq,d.ack)
  for seq in pairs(self.pending) do if seq<=d.ack then self.pending[seq]=nil end end
  if d.reloading then self.reloading=true self.reloadEnd=d.reloadEnd self.reloadRequestedAt=nil
  elseif not self.reloadRequestedAt or now()-self.reloadRequestedAt>.35 or d.reason then self.reloading=false self.reloadEnd=0 self.reloadRequestedAt=nil end
  self.inspectEnd=d.inspectEnd self.readyAt=d.readyAt self.serverEquipped=d.equipped
 end)
 connect(R.Hit.OnClientEvent,function(critical) if active==self then self.hud:Hit(critical) end end)
 connect(tool.Destroying,function() self:Cleanup() for _,c in ipairs(self.connections) do c:Disconnect() end self.hud:Destroy() end)
 R.Action:FireServer("Sync")
 return self
end
return Controller
