-- Cenario de tijolos classicos. Todos os prefabs vieram da biblioteca do Blender.
local RS=game:GetService("ReplicatedStorage")
local Art=require(script.Parent.ModelArt)
local C=require(script.Parent.Config)
local A={}
local function brick(parent,name,size,pos,color,collide)
 local p=Instance.new("Part") p.Name=name p.Anchored=true p.Size=size p.Position=pos
 p.Color=color p.Material=Enum.Material.Plastic p.TopSurface=Enum.SurfaceType.Studs p.BottomSurface=Enum.SurfaceType.Inlet
 p.CanCollide=collide==true p.CanTouch=false p.CanQuery=false p.Parent=parent return p
end
local function group(parent,name) local m=Instance.new("Model") m.Name=name m.Parent=parent return m end
local red=Color3.fromRGB(231,58,54) local blue=Color3.fromRGB(40,114,232) local yellow=Color3.fromRGB(255,200,47)
local white=Color3.fromRGB(239,239,223) local green=Color3.fromRGB(95,183,76) local brown=Color3.fromRGB(131,90,57)
function A.lobby()
 local plaza=workspace.Lobby.Praca local o=C.LOBBY.ORIGIN
 local floor=plaza.PracaCircular floor.Shape=Enum.PartType.Block floor.Size=Vector3.new(64,2,64) floor.Orientation=Vector3.zero floor.Position=o-Vector3.new(0,1,0) floor.Color=green floor.Material=Enum.Material.Plastic floor.TopSurface=Enum.SurfaceType.Studs
 local remove={Anel=true,Banco=true,Vaso=true,Planta=true}
 for _,p in ipairs(plaza:GetChildren()) do if remove[p.Name] then p:Destroy() end end
 local decor=group(plaza,"PracaRemodeladaBlender")
 brick(decor,"Terra",Vector3.new(60,5,60),o+Vector3.new(0,-4.5,0),brown)
 brick(decor,"Rocha",Vector3.new(48,6,48),o+Vector3.new(0,-10,0),Color3.fromRGB(111,121,133))
 brick(decor,"Fundacao",Vector3.new(32,6,32),o+Vector3.new(0,-16,0),Color3.fromRGB(69,78,87))
 for i=-3,3 do
  for _,axis in ipairs({"X","Z"}) do
   local pos=axis=="X" and Vector3.new(i*8,.02,0) or Vector3.new(0,.02,i*8)
   brick(decor,"Caminho",Vector3.new(7.7,.18,7.7),o+pos,yellow)
  end
 end
 for _,x in ipairs({-25,25}) do
  for _,z in ipairs({-24,23}) do Art.spawn("Arvore",CFrame.new(o+Vector3.new(x,0,z)),decor) end
  Art.spawn("Banco",CFrame.new(o+Vector3.new(x,0,-8))*CFrame.Angles(0,x>0 and math.pi/2 or -math.pi/2,0),decor)
  Art.spawn("Poste",CFrame.new(o+Vector3.new(x,0,7)),decor)
 end
 for _,p in ipairs(plaza:GetChildren()) do
  if p:IsA("SpawnLocation") then p.Material=Enum.Material.Plastic p.Color=blue p.TopSurface=Enum.SurfaceType.Studs end
  if p:IsA("BasePart") and p.Name=="Placa" then
   local s=p.Size
   for _,x in ipairs({-s.X/2,s.X/2}) do brick(decor,"Moldura",Vector3.new(.6,s.Y+1,1.3),p.Position+Vector3.new(x,0,0),red) end
   for _,y in ipairs({-s.Y/2,s.Y/2}) do brick(decor,"Moldura",Vector3.new(s.X+1,.6,1.3),p.Position+Vector3.new(0,y,0),yellow) end
  end
 end
end
function A.arena()
 local arena=workspace.Arena local o=C.ARENA.ORIGIN
 arena.Decor:ClearAllChildren()
 -- Substitui os antigos arcos finos por porticos de blocos.
 for _,name in ipairs({"Start","Finish"}) do
  local parent=arena[name] local z=name=="Start" and 0 or C.ARENA.LENGTH
  for _,p in ipairs(parent:GetChildren()) do if p.Name=="Pilar" or p.Name=="Arco" then p:Destroy() end end
  Art.spawn("Arco",CFrame.new(o+Vector3.new(0,0,z)),parent)
  local board=parent:FindFirstChild("Placa") if board then board.Position=o+Vector3.new(0,17,z) end
  for x=-16,16,8 do for dz=-8,8,8 do
   brick(parent,"Piso xadrez",Vector3.new(7.9,.1,7.9),o+Vector3.new(x,.01,z+dz),((x/8+dz/8)%2==0) and white or blue)
  end end
  brick(parent,"Fundacao",Vector3.new(38,4,22),o+Vector3.new(0,-3,z),brown)
 end
 local trophy=arena.Finish:FindFirstChild("Trofeu")
 if trophy then trophy.Transparency=1 end
 Art.spawn("Trofeu",CFrame.new(o+Vector3.new(0,.1,248)),arena.Finish)
 for i,z in ipairs(C.ARENA.CHECKPOINTS_Z) do
  local cp=arena.Checkpoints["CP"..i]
  local mast=cp:FindFirstChild("Mastro") if mast then mast:Destroy() end
  local flag=cp:FindFirstChild("Bandeira") if flag then flag.Size=Vector3.new(4,2.5,.3) flag.Color=green flag.Material=Enum.Material.Plastic flag.TopSurface=Enum.SurfaceType.Studs end
  Art.spawn("Bandeira",CFrame.new(o+Vector3.new(-8,0,z)),cp)
  brick(cp,"Fundacao",Vector3.new(19,3,11),o+Vector3.new(0,-2,z),brown)
  for _,x in ipairs({-10,10}) do
   brick(cp,"Marca",Vector3.new(1,2,12),o+Vector3.new(x,0,z),yellow)
  end
 end
 arena.BuilderCabin:ClearAllChildren()
 Art.spawn("Oficina",CFrame.new(C.BUILDER_CABIN),arena.BuilderCabin)
 -- Chao da oficina precisa de colisao; resto e decoracao.
 local workshop=arena.BuilderCabin.Oficina workshop.PrimaryPart.CanCollide=true
 for i=1,12 do
  local z=(i-1)*23-7 local x=(i%2==0 and 1 or -1)*(43+(i%3)*8)
  Art.spawn("Ilha",CFrame.new(o+Vector3.new(x,-6,z)),arena.Decor)
  Art.spawn(i%3==0 and "Pinheiro" or "Arvore",CFrame.new(o+Vector3.new(x,-6,z)),arena.Decor)
  if i%2==0 then Art.spawn("Rocha",CFrame.new(o+Vector3.new(x+8,-6,z-6)),arena.Decor) end
  if i%3==0 then Art.spawn("Nuvem",CFrame.new(o+Vector3.new(x*1.8,28,z)),arena.Decor) end
 end
 for z=12,228,12 do for _,x in ipairs({-20,20}) do
  brick(arena.Walls,"Guarda-corpo",Vector3.new(.9,2,1),o+Vector3.new(x,0,z),z%24==0 and yellow or blue)
 end end
 for _,p in ipairs(arena:GetDescendants()) do
  if p:IsA("BasePart") and string.sub(p.Name,1,4)=="Slot" then p.Material=Enum.Material.Plastic p.Color=yellow end
  if p:IsA("BasePart") and p.Transparency<1 and p.Material~=Enum.Material.Neon then
   p.TopSurface=Enum.SurfaceType.Studs p.BottomSurface=Enum.SurfaceType.Inlet
  end
 end
end
return A
