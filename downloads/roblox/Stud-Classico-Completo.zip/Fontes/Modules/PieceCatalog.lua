local C=require(script.Parent.Config)
local rows={
 {"Plataforma",5,8,1,8,"Basica",true,"Ponte segura"},
 {"PlataformaPeq",4,4,1,4,"Basica",true,"Salto preciso"},
 {"DegrauFalso",6,8,1,8,"Basica",true,"Degrau falso"},
 {"ParedeBaixa",7,8,4,1,"Basica",true,"Barreira para saltar"},
 {"PlataformaMovel",12,8,1,8,"Movimento",false,"Plataforma movel"},
 {"PlataformaGiratoria",14,12,1,12,"Movimento",false,"Plataforma giratoria"},
 {"Esteira",10,8,1,12,"Movimento",false,"Esteira"},
 {"Serra",18,4,4,12,"Perigo",false,"Serra",true},
 {"Espinhos",12,8,1,8,"Perigo",false,"Espinhos"},
 {"EspinhosEscondidos",16,8,1,8,"Perigo",false,"Espinhos ocultos"},
 {"Laser",20,12,4,2,"Perigo",false,"Laser",false,true},
 {"Pendulo",22,4,8,4,"Perigo",false,"Pendulo"},
 {"MarteloEmpurrao",15,8,4,4,"Perigo",false,"Martelo de empurrao"},
 {"BombaRelogio",25,4,4,4,"Perigo",false,"Bomba relogio",true},
 {"Lava",14,8,1,8,"Perigo",false,"Lava"},
 {"Trampolim",10,8,1,8,"Troll",true,"Trampolim"},
 {"Ventilador",13,4,4,4,"Troll",false,"Ventilador"},
 {"PortalTroll",24,4,6,4,"Troll",false,"Portal troll",true},
 {"BlocoEscorregadio",8,8,1,8,"Troll",true,"Bloco de gelo"},
 {"ParedeFantasma",9,8,6,1,"Troll",false,"Parede fantasma"},
 {"CheckpointFalso",20,8,1,8,"Troll",false,"Checkpoint falso"}}
local colors={Basica=C.COLORS.CYAN,Movimento=C.COLORS.GOLD,Perigo=C.COLORS.DANGER,Troll=C.COLORS.PURPLE}
local list,byId={},{}
for _,r in ipairs(rows) do
 local d={id=r[1],custo=r[2],tamanho=Vector3.new(r[3],r[4],r[5]),categoria=r[6],helper=r[7],nome=r[8],descricao=r[8],epic=r[9] or false,warning=r[10] or false,cooldown=C.ENERGY.PLACE_COOLDOWN,cor=colors[r[6]],material=Enum.Material.SmoothPlastic,vidaUtil=C.PIECES.LIFETIME,height=true,icone=string.sub(r[8],1,2),dica="R gira · Z desfaz · Expira em 25s"}
 table.freeze(d) table.insert(list,d) byId[d.id]=d
end
local P={}
function P.get(id) return byId[id] end
function P.list() return table.clone(list) end
function P.listForRole(role) local out={} for _,d in ipairs(list) do if role=="Builder" or (role=="Helper" and d.helper) then table.insert(out,d) end end return out end
function P.byCategory(cat) local out={} for _,d in ipairs(list) do if d.categoria==cat then table.insert(out,d) end end return out end
return P
