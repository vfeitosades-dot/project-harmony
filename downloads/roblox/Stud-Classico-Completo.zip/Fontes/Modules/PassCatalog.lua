-- Crie os passes na experiencia publicada e coloque os IDs reais aqui.
return {
 {key="VIP",id=0,name="Clube VIP",description="Titulo VIP dourado e rastro dourado. Beneficio cosmetico.",attribute="PassVIP"},
 {key="Neon",id=0,name="Rastro Neon",description="Rastro ciano e roxo exclusivo. Beneficio cosmetico.",attribute="PassNeon"}
}
