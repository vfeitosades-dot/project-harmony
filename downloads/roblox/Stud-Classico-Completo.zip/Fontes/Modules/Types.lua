--!strict
export type Role="Lobby"|"Builder"|"Runner"|"Helper"|"Spectator"
export type State="WAITING"|"INTERMISSION"|"PREPARING"|"RUNNING"|"ENDING"|"RESET"
export type PieceDef={id:string,nome:string,descricao:string,categoria:string,custo:number,cooldown:number,tamanho:Vector3,cor:Color3,material:Enum.Material,vidaUtil:number?,helper:boolean,epic:boolean,warning:boolean,height:boolean,icone:string,dica:string}
export type RoundStateData={state:State,timeLeft:number,round:number,builderUserId:number?,theme:string}
export type SettingsData={audio:{[string]:any},graphics:{[string]:any},controls:{[string]:any},accessibility:{[string]:any},game:{[string]:any}}
export type PlayerData={version:number,coins:number,xp:number,level:number,stats:{[string]:number},settings:SettingsData,owned:{[string]:any},equipped:{[string]:any},tutorialDone:boolean}
export type PlaceRequest={pieceId:string,cf:CFrame}
export type RoundResultData={winner:string,podium:{{userId:number,place:number,points:number}},mvpUserId:number?,rewards:{coins:number,xp:number},stats:{eliminations:number}}
return {}
