local TweenService=game:GetService("TweenService")
local Players=game:GetService("Players")
local U={}
function U.snapToGrid(pos,grid) return Vector3.new(math.round(pos.X/grid)*grid,math.round(pos.Y/grid)*grid,math.round(pos.Z/grid)*grid) end
function U.clamp(n,low,high) return math.clamp(n,low,high) end
function U.round(n,decimals) local f=10^(decimals or 0) return math.round(n*f)/f end
function U.formatTime(seconds) seconds=math.max(0,math.ceil(seconds)) return string.format("%d:%02d",math.floor(seconds/60),seconds%60) end
function U.weldParts(a,b) local w=Instance.new("WeldConstraint") w.Part0=a w.Part1=b w.Parent=a return w end
function U.makePart(props)
 local p=Instance.new("Part") p.Anchored=true p.TopSurface=Enum.SurfaceType.Smooth p.BottomSurface=Enum.SurfaceType.Smooth
 for k,v in pairs(props) do if k~="Parent" then p[k]=v end end
 p.Parent=props.Parent return p
end
function U.tween(obj,info,goal) local t=TweenService:Create(obj,info,goal) t:Play() return t end
function U.getCharacterRoot(player) return player.Character and player.Character:FindFirstChild("HumanoidRootPart") end
function U.shuffle(list) local r=table.clone(list) for i=#r,2,-1 do local j=math.random(i) r[i],r[j]=r[j],r[i] end return r end
function U.weightedPick(list,weightFn)
 local total=0 for _,v in ipairs(list) do total+=math.max(0,weightFn(v)) end
 local pick=math.random()*total for _,v in ipairs(list) do pick-=math.max(0,weightFn(v)) if pick<=0 then return v end end return list[#list]
end
function U.deepCopy(t) if type(t)~="table" then return t end local r={} for k,v in pairs(t) do r[k]=U.deepCopy(v) end return r end
function U.rateLimiter(maxPerSecond)
 local windows=setmetatable({},{__mode="k"})
 Players.PlayerRemoving:Connect(function(p) windows[p]=nil end)
 return function(p)
  local now=os.clock() local w=windows[p] or {} windows[p]=w
  while w[1] and now-w[1]>=1 do table.remove(w,1) end
  if #w>=maxPerSecond then return false end table.insert(w,now) return true
 end
end
function U.createSound(parent,id,props) local s=Instance.new("Sound") s.SoundId=id for k,v in pairs(props or {}) do s[k]=v end s.Parent=parent return s end
function U.playEmitter(emitter,count) if emitter and emitter:IsA("ParticleEmitter") then emitter:Emit(count) end end
return U
