local C=require(script.Parent.Config)
local Art=require(script.Parent.ModelArt)
local W={}
local function block(parent,name,size,pos,color,collide)
 local p=Instance.new("Part") p.Name=name p.Size=size p.Position=pos p.Color=color p.Anchored=true p.CanCollide=collide==true p.CanTouch=false p.CanQuery=collide==true p.Material=Enum.Material.Plastic p.TopSurface=Enum.SurfaceType.Studs p.BottomSurface=Enum.SurfaceType.Inlet p.Parent=parent return p
end
function W.build(theme)
 local arena=workspace.Arena local o=C.ARENA.ORIGIN local parent=Instance.new("Model") parent.Name="Mapa_"..theme parent.Parent=arena
 local data=C.THEME_DATA[theme]
 -- Caminho inicial permite terminar a pista sem depender de pontes do construtor.
 for z=16,224,8 do
  local protected=false for _,cp in ipairs(C.ARENA.CHECKPOINTS_Z) do if math.abs(z-cp)<10 then protected=true end end
  if not protected then
   local x=0
   if theme=="Deserto" then x=math.sin(z/30)*8 elseif theme=="Gelo" then x=math.sin(z/21)*10 elseif theme=="Lava" then x=z%32<16 and -6 or 6 elseif theme=="Espaco" then x=math.sin(z/38)*12 end
   local path=block(parent,"Trilha",Vector3.new(theme=="Lava" and 14 or 10,1,8),o+Vector3.new(x,-.5,z),data.floor,true)
   if theme=="Gelo" then path.Material=Enum.Material.Ice path.CustomPhysicalProperties=PhysicalProperties.new(.7,.12,.1) end
  end
 end
 for side=-1,1,2 do
  for i=1,6 do
   local x=side*(62+i%2*12) local z=i*37-12 local p=o+Vector3.new(x,-6,z)
   if theme=="NeonCidade" then
    local h=20+(i%3)*12 block(parent,"Predio",Vector3.new(16,h,16),p+Vector3.new(0,h/2,0),Color3.fromRGB(53,74,109))
    for y=5,h-2,7 do for dx=-4,4,8 do block(parent,"Janela",Vector3.new(3,3,.2),p+Vector3.new(dx,y,-8.2),Color3.fromRGB(255,215,105)) end end
    block(parent,"Antena",Vector3.new(1,8,1),p+Vector3.new(0,h+4,0),data.neon)
   elseif theme=="Deserto" then
    for j=1,4 do block(parent,"Piramide",Vector3.new(26-j*4,4,26-j*4),p+Vector3.new(0,j*4,0),Color3.fromRGB(218,174,99)) end
    block(parent,"Cacto",Vector3.new(3,12,3),p+Vector3.new(12,6,0),Color3.fromRGB(67,131,75))
    block(parent,"Braco cacto",Vector3.new(9,2,2),p+Vector3.new(12,8,0),Color3.fromRGB(67,131,75))
   elseif theme=="Gelo" then
    block(parent,"Torre gelo",Vector3.new(10,28,10),p+Vector3.new(0,14,0),Color3.fromRGB(180,225,255))
    for dx=-4,4,4 do block(parent,"Ameia",Vector3.new(2,4,10),p+Vector3.new(dx,30,0),Color3.fromRGB(210,240,255)) end
    Art.spawn("Pinheiro",CFrame.new(p+Vector3.new(13,0,0)),parent)
   elseif theme=="Lava" then
    for j=1,4 do block(parent,"Vulcao",Vector3.new(30-j*5,5,30-j*5),p+Vector3.new(0,j*5,0),Color3.fromRGB(64,51,57)) end
    local lava=block(parent,"Cratera",Vector3.new(10,1,10),p+Vector3.new(0,20.6,0),Color3.fromRGB(255,125,32)) lava.Material=Enum.Material.Neon
    local fire=Instance.new("ParticleEmitter") fire.Rate=3 fire.Lifetime=NumberRange.new(1,3) fire.Speed=NumberRange.new(2,5) fire.Color=ColorSequence.new(data.neon) fire.Size=NumberSequence.new(.3) fire.Parent=lava
   else
    local planet=block(parent,"Planeta",Vector3.new(18,18,18),p+Vector3.new(0,20,0),i%2==0 and data.neon or Color3.fromRGB(85,152,206)) planet.Shape=Enum.PartType.Ball
    block(parent,"Estacao orbital",Vector3.new(26,2,12),p+Vector3.new(0,5,0),Color3.fromRGB(162,177,198))
    for dx=-9,9,18 do block(parent,"Painel solar",Vector3.new(10,.5,18),p+Vector3.new(dx,7,0),Color3.fromRGB(49,91,171)) end
   end
  end
 end
end
function W.lobby()
 local o=C.LOBBY.ORIGIN local m=Instance.new("Model") m.Name="Treino" m.Parent=workspace.Lobby
 -- Percurso lateral acessivel, sem premiacao repetivel.
 block(m,"Passarela treino",Vector3.new(12,2,18),o+Vector3.new(27,-1,-36),Color3.fromRGB(95,183,76),true)
 for i=1,8 do block(m,"Salto treino",Vector3.new(6,1,6),o+Vector3.new(27+(i%2)*3,math.min(i,4)*.7,-45-i*7),Color3.fromRGB(40,114,232),true) end
 block(m,"Fim do treino",Vector3.new(14,2,14),o+Vector3.new(28,1.8,-108),Color3.fromRGB(255,200,47),true)
 local save=Instance.new("Part") save.Name="Seguranca treino" save.Size=Vector3.new(36,1,108) save.Position=o+Vector3.new(27,-8,-65) save.Anchored=true save.Transparency=.25 save.Color=Color3.fromRGB(95,183,76) save.TopSurface=Enum.SurfaceType.Studs save.Parent=m
 for i=1,4 do block(m,"Escada de retorno",Vector3.new(7,1,7),o+Vector3.new(13,-8+i*2,-64+i*7),Color3.fromRGB(95,183,76),true) end
 local marker=block(m,"Retorno",Vector3.new(2,4,2),o+Vector3.new(32,5,-108),Color3.fromRGB(255,200,47),false)
 local prompt=Instance.new("ProximityPrompt") prompt.ActionText="Voltar ao lobby" prompt.ObjectText="Treino concluido" prompt.HoldDuration=.25 prompt.MaxActivationDistance=12 prompt.RequiresLineOfSight=false prompt.Parent=marker
 prompt.Triggered:Connect(function(p)
  local root=p.Character and p.Character:FindFirstChild("HumanoidRootPart") local role=p:GetAttribute("Role")
  if root and (role=="Lobby" or role=="Spectator") and (root.Position-marker.Position).Magnitude<16 then p.Character:PivotTo(CFrame.new(o+Vector3.new(0,5,-5))) end
 end)
end
return W
