local U=require(script.Parent.Util)
local S={}
S.DEFAULTS={
 audio={master=80,music=60,sfx=80,ui=70,muteMusicInRound=false,dangerAlert=true},
 graphics={quality="Alta",shadows=true,bloom=true,dof=true,sunrays=true,particles="Completas",motionBlur=false,effectDistance=200,showFps=false,fpsCap=60},
 controls={sensitivity=50,fov=70,invertY=false,builderCamSpeed=50,touchButtonSize=100,touchSide="Direita",keybinds={Dash="Q",Emote="G",Rotate="R",Undo="Z"}},
 accessibility={reduceShake=false,reduceFlashes=false,colorblind="Normal",textSize="M",highContrast=false,captions=false},
 game={showNames=true,showTips=true,killfeed=true,language="pt"}}
S.RANGES={audio={},graphics={quality={"Baixa","Media","Alta"},particles={"Desligadas","Reduzidas","Completas"},effectDistance={25,500},fpsCap={30,60,120,144,240}},controls={sensitivity={0,100},fov={50,100},builderCamSpeed={10,100},touchButtonSize={70,150},touchSide={"Direita","Esquerda"},keybinds={Dash={"Q","E","F","LeftShift"},Emote={"G","H","T"},Rotate={"R","T","E"},Undo={"Z","X","U"}}},accessibility={colorblind={"Normal","Protanopia","Deuteranopia","Tritanopia"},textSize={"P","M","G"}},game={language={"pt","en"}}}
for _,key in ipairs({"master","music","sfx","ui"}) do S.RANGES.audio[key]={0,100} end
local function clean(defaults,incoming,ranges)
 local out={} incoming=type(incoming)=="table" and incoming or {}
 for k,d in pairs(defaults) do
  local v=incoming[k] local r=ranges and ranges[k]
  if type(d)=="table" then out[k]=clean(d,v,r)
  elseif type(d)=="boolean" then if type(v)=="boolean" then out[k]=v else out[k]=d end
  elseif type(d)=="number" then
   if type(v)~="number" or v~=v or math.abs(v)==math.huge then v=d end
   if k=="fpsCap" then out[k]=table.find(r,v) and v or d else out[k]=math.clamp(v,r[1],r[2]) end
  else out[k]=(type(v)=="string" and r and table.find(r,v)) and v or d end
 end return out
end
function S.validate(incoming) return clean(S.DEFAULTS,incoming,S.RANGES) end
S.TEXT={pt={audio="Audio",graphics="Graficos",controls="Controles",accessibility="Acessibilidade",game="Jogo",save="Salvar",close="Fechar"},en={audio="Audio",graphics="Graphics",controls="Controls",accessibility="Accessibility",game="Game",save="Save",close="Close"}}
local labels={master={"Volume geral","Master volume"},music={"Musica","Music"},sfx={"Efeitos sonoros","Sound effects"},ui={"Interface","Interface"},muteMusicInRound={"Silenciar na rodada","Mute in round"},dangerAlert={"Alerta de perigo","Danger alert"},quality={"Qualidade","Quality"},shadows={"Sombras","Shadows"},bloom={"Brilho","Bloom"},dof={"Profundidade de campo","Depth of field"},sunrays={"Raios solares","Sun rays"},particles={"Particulas","Particles"},motionBlur={"Desfoque de movimento","Motion blur"},effectDistance={"Distancia de efeitos","Effect distance"},showFps={"Mostrar FPS","Show FPS"},fpsCap={"Limite de FPS desejado","Preferred FPS cap"},sensitivity={"Sensibilidade","Sensitivity"},fov={"Campo de visao","Field of view"},invertY={"Inverter Y","Invert Y"},builderCamSpeed={"Velocidade da camera","Camera speed"},touchButtonSize={"Tamanho dos botoes","Button size"},touchSide={"Lado dos botoes","Button side"},keybinds={"Teclas","Keybinds"},reduceShake={"Reduzir tremor","Reduce shake"},reduceFlashes={"Reduzir flashes","Reduce flashes"},colorblind={"Daltonismo","Colorblind mode"},textSize={"Tamanho do texto","Text size"},highContrast={"Alto contraste","High contrast"},captions={"Legendas","Captions"},showNames={"Mostrar nomes","Show names"},showTips={"Mostrar dicas","Show tips"},killfeed={"Registro de eliminacoes","Elimination feed"},language={"Idioma","Language"}}
for k,v in pairs(labels) do S.TEXT.pt[k]=v[1] S.TEXT.en[k]=v[2] end
-- Teste: validate({audio={master=999},alien=true}).audio.master == 100
return S
