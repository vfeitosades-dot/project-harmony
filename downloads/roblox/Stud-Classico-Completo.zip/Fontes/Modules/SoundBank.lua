-- IDs reservados; COLOQUE AQUI seus audios autorizados.
local B={MUSIC={},SFX={},UI={}}
for _,k in ipairs({"lobby","preparing","running","lastSeconds","victory"}) do B.MUSIC[k]="rbxassetid://0" end
for _,k in ipairs({"place","error","saw","laser","bounce","explosion","checkpoint","finish","countdown"}) do B.SFX[k]="rbxassetid://0" end
for _,k in ipairs({"click","hover","toast"}) do B.UI[k]="rbxassetid://0" end
function B.volumeOf(key) return B.MUSIC[key] and .35 or .65 end
return B
