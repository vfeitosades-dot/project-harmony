return {
 {id="Menta",name="Camisa menta",cost=100,color=Color3.fromRGB(73,192,154)},
 {id="Violeta",name="Camisa violeta",cost=200,color=Color3.fromRGB(147,87,204)},
 {id="Ouro",name="Camisa dourada",cost=350,color=Color3.fromRGB(255,200,47)}
}
