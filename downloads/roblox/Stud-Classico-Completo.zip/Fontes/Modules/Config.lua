--!strict
local function freeze(t: any): any
 for _,v in pairs(t) do if type(v)=="table" then freeze(v) end end
 return table.freeze(t)
end
return freeze({
 GAME_NAME="Construtor vs Corredores", MIN_PLAYERS=2, MAX_PLAYERS=16,
 TIMES={WAITING=0,INTERMISSION=15,PREPARING=8,RUNNING=150,ENDING=10,RESET=3},FINISH_GRACE=10,
 ENERGY={MAX=100,REGEN=6,HELPER_MAX=30,HELPER_REGEN=2,PLACE_COOLDOWN=.35,SURGE_INTERVAL=40,SURGE_DURATION=5,SURGE_MULTIPLIER=3,UNDO_WINDOW=2,UNDO_REFUND=.5},
 PIECES={MAX_ACTIVE=120,LIFETIME=25,GRID=4,WARNING_TIME=1.5,MAX_EPIC_ACTIVE=1,EPIC_COOLDOWN=6},
 RUNNER={LIVES=3,WALKSPEED=16,JUMPPOWER=50,DASH_COOLDOWN=8,DASH_FORCE=60,INVULN_TIME=2},
 ARENA={ORIGIN=Vector3.new(0,50,0),WIDTH=40,LENGTH=240,CHECKPOINTS_Z={60,120,180},KILL_Y=-10,FORBIDDEN_RADIUS=12,MAX_BLOCK_RATIO=.7},
 LOBBY={ORIGIN=Vector3.new(0,50,-250)},BUILDER_CABIN=Vector3.new(0,130,120),
 SCORE={PLACE={100,70,50},PLACE_DEFAULT=30,SURVIVE_PER_5S=1,BUILDER_PER_ELIM=10,BUILDER_ELIM_MAX=80,BUILDER_WIN=60,BUILDER_COMBO=20,HELPER_ELIM=5,COINS_FACTOR=.5},
 THEMES={"NeonCidade","Deserto","Gelo","Lava","Espaco"},
 THEME_DATA={
 NeonCidade={floor=Color3.fromRGB(179,188,197),neon=Color3.fromRGB(40,114,232),sky=Color3.fromRGB(155,187,220),fog=Color3.fromRGB(192,220,245),ClockTime=14,Brightness=2,special="Neon intenso"},
 Deserto={floor=Color3.fromRGB(218,174,99),neon=Color3.fromRGB(255,200,61),sky=Color3.fromRGB(255,210,155),fog=Color3.fromRGB(222,178,133),ClockTime=15,Brightness=3,special="Tons quentes"},
 Gelo={floor=Color3.fromRGB(184,225,255),neon=Color3.fromRGB(89,171,255),sky=Color3.fromRGB(199,226,255),fog=Color3.fromRGB(177,207,232),ClockTime=12,Brightness=2,special="Baixa friccao"},
 Lava={floor=Color3.fromRGB(65,35,42),neon=Color3.fromRGB(255,113,45),sky=Color3.fromRGB(120,51,53),fog=Color3.fromRGB(98,42,43),ClockTime=19,Brightness=2,special="Brilho laranja"},
 Espaco={floor=Color3.fromRGB(30,24,65),neon=Color3.fromRGB(180,105,255),sky=Color3.fromRGB(24,20,52),fog=Color3.fromRGB(37,26,65),ClockTime=0,Brightness=1,special="Estrelas e planetas"}},
 ANIM_IDS={Win="rbxassetid://0",Lose="rbxassetid://0",Dash="rbxassetid://0",Scare="rbxassetid://0",BuilderCheer="rbxassetid://0",Emote1="rbxassetid://0",Emote2="rbxassetid://0",Emote3="rbxassetid://0",Emote4="rbxassetid://0"}, -- COLOQUE AQUI
 EMOTES={{id="Emote1",nome="Acenar",icone="Oi!"},{id="Emote2",nome="Dancar",icone="♪"},{id="Emote3",nome="Comemorar",icone="!"},{id="Emote4",nome="Rir",icone=":D"}},
 -- Ajustes tecnicos centralizados.
 DATA={AUTOSAVE=60,RANK_INTERVAL=120,RETRIES=5,SESSION_TTL=180},
 BUILD={HEIGHT_STEP=4,HEIGHT_LEVELS=3,REQUESTS_PER_SECOND=8,SEND_INTERVAL=.2},
 COLORS={BACKGROUND=Color3.fromRGB(16,26,42),PURPLE=Color3.fromRGB(116,80,213),CYAN=Color3.fromRGB(39,224,255),GOLD=Color3.fromRGB(255,200,61),DANGER=Color3.fromRGB(255,77,109),SUCCESS=Color3.fromRGB(61,220,132),TEXT=Color3.fromRGB(242,244,255)}
})
