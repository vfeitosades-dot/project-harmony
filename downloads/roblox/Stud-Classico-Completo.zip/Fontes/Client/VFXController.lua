local RS=game:GetService("ReplicatedStorage")
local Tween=game:GetService("TweenService")
local Run=game:GetService("RunService")
local Debris=game:GetService("Debris")
local Settings=require(script.Parent.SettingsController)
local V={} local animated={} local last=0
local function burst(pos,color)
 if (workspace.CurrentCamera.CFrame.Position-pos).Magnitude>Settings.current.graphics.effectDistance then return end
 if Settings.current.graphics.particles=="Desligadas" then return end
 local count=Settings.current.graphics.particles=="Reduzidas" and 5 or 12
 for i=1,count do
  local p=Instance.new("Part") p.Size=Vector3.new(.18,.18,.18) p.Anchored=true p.CanCollide=false p.CanTouch=false p.CanQuery=false p.Material=Enum.Material.Neon p.Color=color p.Position=pos p.Parent=workspace
  local a=i*math.pi*2/count
  Tween:Create(p,TweenInfo.new(.55,Enum.EasingStyle.Quad,Enum.EasingDirection.Out),{Position=pos+Vector3.new(math.cos(a)*3,1+math.random()*2,math.sin(a)*3),Transparency=1,Size=Vector3.new(.03,.03,.03)}):Play() Debris:AddItem(p,.6)
 end
end
local function track(model)
 local parts={}
 for _,p in ipairs(model:GetDescendants()) do
  if p:IsA("BasePart") and p.Name~="Colisao" then
   local size=p.Size p.Size=size*.85 Tween:Create(p,TweenInfo.new(.3,Enum.EasingStyle.Back,Enum.EasingDirection.Out),{Size=size}):Play()
   if p.Name=="Helice" or p.Name=="Disco de corte" or p.Name=="Runas" or p.Name=="Faisca" or p.Name=="Lente" then table.insert(parts,{p=p,cf=p.CFrame,color=p.Color}) end
  end
 end
 if #parts>0 then animated[model]=parts end
end
function V.init()
 local folder=workspace:WaitForChild("PiecesActive") folder.ChildAdded:Connect(function(m) task.delay(.15,function() if m.Parent then track(m) end end) end)
 folder.ChildRemoved:Connect(function(m) animated[m]=nil end)
 Run.RenderStepped:Connect(function(dt)
  local now=os.clock()
  for model,parts in pairs(animated) do
   if not model.Parent then animated[model]=nil else
    for _,r in ipairs(parts) do if r.p.Parent then
     if r.p.Name=="Helice" then r.p.CFrame=r.cf*CFrame.Angles(0,now*4,0)
     elseif r.p.Name=="Disco de corte" then r.p.CFrame=CFrame.new(r.p.Position)*r.cf.Rotation*CFrame.Angles(0,0,now*3)
     elseif not Settings.current.accessibility.reduceFlashes then r.p.Transparency=.15+.2*math.sin(now*3)^2 end
    end end
   end
  end
 end)
 RS.Remotes.PieceActivated.OnClientEvent:Connect(function(id,pos)
  if os.clock()-last<.12 then return end last=os.clock() burst(pos,Color3.fromRGB(39,224,255))
 end)
 RS.Remotes.ReachedFinish.OnClientEvent:Connect(function(userId)
  local p=game:GetService("Players"):GetPlayerByUserId(userId) local root=p and p.Character and p.Character:FindFirstChild("HumanoidRootPart")
  if root then burst(root.Position,Color3.fromRGB(255,204,69)) end
 end)
 RS.Remotes.ScreenFX.OnClientEvent:Connect(function(kind,intensity)
  if Settings.current.accessibility.reduceFlashes or kind~="flash" then return end
  local e=Instance.new("ColorCorrectionEffect") e.TintColor=Color3.fromRGB(255,195,210) e.Brightness=math.clamp(intensity,0,.1) e.Parent=workspace.CurrentCamera
  Tween:Create(e,TweenInfo.new(.35),{Brightness=0,TintColor=Color3.new(1,1,1)}):Play() Debris:AddItem(e,.4)
 end)
end
return V
