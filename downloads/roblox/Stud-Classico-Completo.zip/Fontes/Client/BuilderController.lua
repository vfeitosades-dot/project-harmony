local RS=game:GetService("ReplicatedStorage")
local Input=game:GetService("UserInputService")
local GuiService=game:GetService("GuiService")
local Run=game:GetService("RunService")
local Players=game:GetService("Players")
local C=require(RS.Modules.Config)
local U=require(RS.Modules.Util)
local Catalog=require(RS.Modules.PieceCatalog)
local B={} local selected="Plataforma" local rotation=0 local level=0 local role="Lobby" local state="WAITING" local ghost local target=nil local pointer=nil
function B.select(id) selected=id end
function B.rotate() rotation=(rotation+1)%4 end
function B.height() level=(level+1)%C.BUILD.HEIGHT_LEVELS return level end
function B.setRole(value) role=value end
function B.setState(value) state=value end
function B.init()
 ghost=U.makePart({Name="PreviewLocal",Anchored=true,CanCollide=false,CanTouch=false,CanQuery=false,Transparency=1,Material=Enum.Material.ForceField,Parent=workspace})
 local function canBuild() return (role=="Builder" or role=="Helper") and state=="RUNNING" end
 Input.InputBegan:Connect(function(input,gp)
  if gp then return end
  if input.KeyCode==Enum.KeyCode.G then RS.Remotes.Emote:FireServer("Emote1") end
  if input.KeyCode==Enum.KeyCode.Q then RS.Remotes.UseDash:FireServer() end
  if not canBuild() then return end
  if input.KeyCode==Enum.KeyCode.R then B.rotate()
  elseif input.KeyCode==Enum.KeyCode.Z then RS.Remotes.UndoPiece:FireServer()
  elseif input.KeyCode==Enum.KeyCode.T then B.height()
  elseif input.UserInputType==Enum.UserInputType.MouseButton1 and target then RS.Remotes.PlacePiece:FireServer(selected,target) end
 end)
 local function atPoint(point)
  local camera=workspace.CurrentCamera if not camera then return nil end
  local ray=camera:ViewportPointToRay(point.X,point.Y) if math.abs(ray.Direction.Y)<.001 then return nil end
  local t=(C.ARENA.ORIGIN.Y-ray.Origin.Y)/ray.Direction.Y if t<0 then return nil end
  local pos=U.snapToGrid(ray.Origin+ray.Direction*t,C.PIECES.GRID) local d=Catalog.get(selected)
  return CFrame.new(pos.X,C.ARENA.ORIGIN.Y+d.tamanho.Y/2-1+level*C.BUILD.HEIGHT_STEP,pos.Z)*CFrame.Angles(0,rotation*math.pi/2,0)
 end
 Input.TouchTapInWorld:Connect(function(point,processed)
  if processed or not canBuild() then return end local inset=GuiService:GetGuiInset() local cf=atPoint(point-inset) if cf then pointer=point-inset RS.Remotes.PlacePiece:FireServer(selected,cf) end
 end)
 Run.RenderStepped:Connect(function()
  if not canBuild() then ghost.Transparency=1 target=nil return end
  local inset=GuiService:GetGuiInset() local pos=Input.TouchEnabled and pointer or (Input:GetMouseLocation()-inset)
  if not pos then ghost.Transparency=1 return end target=atPoint(pos)
  local d=Catalog.get(selected)
  if target then ghost.Size=d.tamanho ghost.CFrame=target ghost.Color=d.cor ghost.Transparency=.45 else ghost.Transparency=1 end
 end)
end
return B
