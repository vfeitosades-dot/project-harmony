-- Animacoes R6 autorais por Motor6D, executadas para todos os personagens visiveis.
local Players=game:GetService("Players")
local Run=game:GetService("RunService")
local RS=game:GetService("ReplicatedStorage")
local A={} local rigs={} local emotes={}
local function bind(p,char)
 local torso=char:WaitForChild("Torso",8) local h=char:FindFirstChildOfClass("Humanoid") local root=char:FindFirstChild("HumanoidRootPart") if not torso or not h or not root then return end
 local joints={} for _,j in ipairs(char:GetDescendants()) do if j:IsA("Motor6D") then joints[j.Name]=j end end local eyes={} local head=char:FindFirstChild("Head") local face=head and head:FindFirstChild("Rosto") if face then for _,f in ipairs(face:GetChildren()) do if f.Name=="Olho" then table.insert(eyes,f) end end end rigs[p]={char=char,h=h,root=root,j=joints,eyes=eyes}
end
function A.init()
 local function add(p) p.CharacterAdded:Connect(function(c) task.spawn(bind,p,c) end) if p.Character then task.spawn(bind,p,p.Character) end end
 Players.PlayerAdded:Connect(add) Players.PlayerRemoving:Connect(function(p) rigs[p]=nil emotes[p]=nil end) for _,p in ipairs(Players:GetPlayers()) do add(p) end
 RS.Remotes.EmoteBroadcast.OnClientEvent:Connect(function(id) local p=Players:GetPlayerByUserId(id) if p then emotes[p]=os.clock()+2 end end)
 RS.Remotes.ReachedFinish.OnClientEvent:Connect(function(id) local p=Players:GetPlayerByUserId(id) if p and rigs[p] then rigs[p].winUntil=os.clock()+3 end end)
 RS.Remotes.RoundResult.OnClientEvent:Connect(function(d) for p,r in pairs(rigs) do local role=p:GetAttribute("Role") if (d.winner=="Builder" and role=="Builder") or (d.winner=="Runners" and (role=="Runner" or role=="Helper")) then r.winUntil=os.clock()+3 end end end)
 Run.PreSimulation:Connect(function(dt)
  local t=os.clock()
  for p,r in pairs(rigs) do
   if not r.char.Parent then rigs[p]=nil continue end
   local speed=Vector3.new(r.root.AssemblyLinearVelocity.X,0,r.root.AssemblyLinearVelocity.Z).Magnitude
   local walking=speed>1 and r.h.FloorMaterial~=Enum.Material.Air and not r.root.Anchored
   local jump=r.h.FloorMaterial==Enum.Material.Air and not r.root.Anchored
   local stride=walking and math.sin(t*math.clamp(speed*.65,6,16))*.75 or math.sin(t*2)*.025
   local pose={}
   pose["Right Hip"]=CFrame.Angles(stride,0,0) pose["Left Hip"]=CFrame.Angles(-stride,0,0)
   pose["Right Shoulder"]=CFrame.Angles(-stride,0,.04) pose["Left Shoulder"]=CFrame.Angles(stride,0,-.04)
   pose.RootJoint=CFrame.new(0,walking and math.abs(math.sin(t*10))*.045 or math.sin(t*2)*.025,0)*CFrame.Angles(walking and -.06 or 0,0,0)
   pose.Neck=CFrame.Angles(math.sin(t*1.5)*.02,0,0)
   if jump then pose["Right Shoulder"]=CFrame.Angles(-.5,0,.65) pose["Left Shoulder"]=CFrame.Angles(-.5,0,-.65) pose["Right Hip"]=CFrame.Angles(-.25,0,0) pose["Left Hip"]=CFrame.Angles(.25,0,0) end
   if (emotes[p] or 0)>t then pose["Right Shoulder"]=CFrame.Angles(0,0,2.3+math.sin(t*12)*.3) end
   if (r.winUntil or 0)>t then pose["Right Shoulder"]=CFrame.Angles(0,0,2.5+math.sin(t*8)*.15) pose["Left Shoulder"]=CFrame.Angles(0,0,-2.5-math.sin(t*8)*.15) end
   for _,eye in ipairs(r.eyes) do if eye.Parent then eye.Size=UDim2.fromOffset(10,math.sin(t*1.7)> .995 and 2 or 10) end end
   for name,j in pairs(r.j) do if j.Parent then j.Transform=j.Transform:Lerp(pose[name] or CFrame.new(),math.min(1,dt*16)) end end
  end
 end)
end
return A
