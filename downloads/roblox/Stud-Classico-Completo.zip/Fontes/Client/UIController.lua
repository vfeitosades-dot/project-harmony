local RS=game:GetService("ReplicatedStorage")
local Players=game:GetService("Players")
local Tween=game:GetService("TweenService")
local C=require(RS.Modules.Config)
local U=require(RS.Modules.Util)
local Catalog=require(RS.Modules.PieceCatalog)
local UI={} local actions={} local root local header local role local detail local energy local energyTrack local timer local toast local dock local cards local selectedText local dash local menu local modal local result local balance
local buttons={} local fg=Color3.fromRGB(236,241,248) local muted=Color3.fromRGB(159,174,193) local bg=Color3.fromRGB(20,28,41) local accent=Color3.fromRGB(80,205,219)
local function text(p,s,size,pos,fs)
 local t=Instance.new("TextLabel") t.BackgroundTransparency=1 t.Text=s t.Size=size t.Position=pos t.Font=Enum.Font.GothamMedium t.TextSize=fs or 14 t.TextColor3=fg t.TextWrapped=true t.Parent=p return t
end
local function panel(p,size,pos)
 local f=Instance.new("Frame") f.Active=true f.Size=size f.Position=pos f.BackgroundColor3=bg f.BackgroundTransparency=.08 f.BorderSizePixel=0 f.Parent=p
 local c=Instance.new("UICorner") c.CornerRadius=UDim.new(0,10) c.Parent=f
 local s=Instance.new("UIStroke") s.Color=Color3.fromRGB(77,94,117) s.Transparency=.65 s.Parent=f return f
end
local function button(p,s,size,pos,fn)
 local b=Instance.new("TextButton") b.Size=size b.Position=pos b.Text=s b.Font=Enum.Font.GothamMedium b.TextSize=13 b.TextColor3=fg b.BackgroundColor3=Color3.fromRGB(35,47,65) b.BorderSizePixel=0 b.Parent=p
 local c=Instance.new("UICorner") c.CornerRadius=UDim.new(0,7) c.Parent=b
 b.MouseEnter:Connect(function() Tween:Create(b,TweenInfo.new(.12),{BackgroundColor3=Color3.fromRGB(48,65,85)}):Play() end)
 b.MouseLeave:Connect(function() Tween:Create(b,TweenInfo.new(.12),{BackgroundColor3=Color3.fromRGB(35,47,65)}):Play() end)
 b.Activated:Connect(fn) return b
end
local function hideModal() if modal then modal:Destroy() modal=nil end end
local function openModal(title,height)
 hideModal() menu.Visible=false
 local visibleHeight=math.min(height,workspace.CurrentCamera.ViewportSize.Y-24)
 modal=panel(root,UDim2.new(.9,0,0,visibleHeight),UDim2.fromScale(.5,.5)) modal.AnchorPoint=Vector2.new(.5,.5) modal.ZIndex=20
 local max=Instance.new("UISizeConstraint") max.MaxSize=Vector2.new(500,height) max.Parent=modal
 local body=Instance.new("ScrollingFrame") body.Size=UDim2.fromScale(1,1) body.BackgroundTransparency=1 body.BorderSizePixel=0 body.ScrollBarThickness=3 body.ScrollingDirection=Enum.ScrollingDirection.Y body.CanvasSize=UDim2.fromOffset(0,height) body.ClipsDescendants=true body.Active=true body.Parent=modal
 text(body,title,UDim2.new(1,-70,0,40),UDim2.fromOffset(14,8),19).TextXAlignment=Enum.TextXAlignment.Left
 button(modal,"×",UDim2.fromOffset(32,32),UDim2.new(1,-44,0,12),hideModal)
 return body
end
function UI.toast(s,kind)
 local token={} UI.token=token toast.Text=s toast.TextColor3=kind=="bad" and C.COLORS.DANGER or kind=="good" and C.COLORS.SUCCESS or fg toast.Visible=true toast.TextTransparency=1
 Tween:Create(toast,TweenInfo.new(.2),{TextTransparency=0}):Play()
 task.delay(3,function() if UI.token==token then toast.Visible=false end end)
end
function UI.setState(d)
 local names={WAITING="Esperando 2 jogadores",INTERMISSION="Proxima rodada",PREPARING="Prepare-se",RUNNING="Chegue ao final",ENDING="Rodada encerrada",RESET="Voltando ao lobby"}
 header.Text=(names[d.state] or d.state)..(d.state=="PREPARING" and " · "..(d.theme or "") or "")..(d.timeLeft>0 and "  ·  "..U.formatTime(d.timeLeft) or "")
 Tween:Create(timer,TweenInfo.new(.6),{Size=UDim2.fromScale(math.clamp(d.timeLeft/math.max(1,C.TIMES[d.state] or 150),0,1),1)}):Play()
 if d.state~="ENDING" and result then result:Destroy() result=nil end
end
function UI.select(id)
 local d=Catalog.get(id) if not d then return end
 selectedText.Text=d.nome.."  ·  "..d.custo.." energia"
 for key,b in pairs(buttons) do b.TextColor3=key==id and accent or fg end
 if actions.select then actions.select(id) end
end
function UI.setRole(value)
 local build=value=="Builder" or value=="Helper"
 role.Text=({Builder="Construtor",Helper="Ajudante",Runner="Corredor",Lobby="Lobby",Spectator="Espectador"})[value] or value
 dock.Visible=build energyTrack.Visible=build dash.Visible=value=="Runner" detail.Visible=build or value=="Runner"
 for _,b in pairs(buttons) do b:Destroy() end buttons={}
 if build then
  local list=Catalog.listForRole(value)
  for i,d in ipairs(list) do
   local b=button(cards,d.nome.."\n"..d.custo,UDim2.fromOffset(126,48),UDim2.fromOffset((i-1)*134,0),function() UI.select(d.id) end)
   buttons[d.id]=b
   local mark=Instance.new("Frame") mark.Size=UDim2.new(0,3,1,-16) mark.Position=UDim2.fromOffset(0,8) mark.BackgroundColor3=d.cor mark.BorderSizePixel=0 mark.Parent=b
  end
  cards.CanvasSize=UDim2.fromOffset(#list*134,0) if list[1] then UI.select(list[1].id) end
 end
end
function UI.setEnergy(n,max)
 detail.Text=string.format("%d / %d energia",math.floor(n),max)
 Tween:Create(energy,TweenInfo.new(.2),{Size=UDim2.fromScale(math.clamp(n/math.max(1,max),0,1),1)}):Play()
end
function UI.setLives(n) detail.Text=tostring(n).." vidas" end
function UI.dashCooldown(seconds)
 local token={} UI.dashToken=token task.spawn(function() for i=math.ceil(seconds),1,-1 do if UI.dashToken~=token then return end dash.Text="Dash · "..i task.wait(1) end dash.Text="Dash · Q" end)
end
function UI.showResult(d)
 local content=openModal(d.winner=="Runners" and "Corredores venceram" or "Construtor venceu",math.max(180,114+#d.podium*34)) result=modal
 local reward=text(content,"+"..d.rewards.coins.." moedas   ·   +"..d.rewards.xp.." XP",UDim2.new(1,-32,0,28),UDim2.fromOffset(16,58),15) reward.TextColor3=accent
 for i,r in ipairs(d.podium) do
  local p=Players:GetPlayerByUserId(r.userId)
  local name=text(content,"#"..r.place.."   "..(p and p.DisplayName or tostring(r.userId)),UDim2.new(.7,-16,0,30),UDim2.fromOffset(16,100+(i-1)*34),14)
  name.TextWrapped=false name.TextTruncate=Enum.TextTruncate.AtEnd name.TextXAlignment=Enum.TextXAlignment.Left
  local points=text(content,r.points.." pts",UDim2.new(.3,-16,0,30),UDim2.new(.7,0,0,100+(i-1)*34),13) points.TextXAlignment=Enum.TextXAlignment.Right points.TextColor3=muted
 end
end
local function help()
 local m=openModal("Como jogar",320)
 text(m,"CORREDOR\nSiga as plataformas e salve os 3 checkpoints.\nQ: dash. Cair ou tocar um perigo custa uma vida.\n\nCONSTRUTOR\nEscolha uma peca e clique na pista.\nR: girar · T: altura · Z: desfazer.\n\nSem vidas? Ajude construindo plataformas.",UDim2.new(1,-32,1,-70),UDim2.fromOffset(16,60),14)
end
local function shop()
 local m=openModal("Loja",485)
 UI.shopBalance=text(m,"Saldo: "..tostring(UI.coins or 0).." moedas · Apenas cosmeticos",UDim2.new(1,-32,0,28),UDim2.fromOffset(16,53),12) UI.shopBalance.TextColor3=muted
 for i,d in ipairs(require(RS.Modules.PassCatalog)) do
  local b=button(m,d.name.." · "..(d.id>0 and "Ver preco" or "Em breve"),UDim2.new(1,-32,0,44),UDim2.fromOffset(16,94+(i-1)*88),function()
   if Players.LocalPlayer:GetAttribute(d.attribute) then UI.toast("Voce ja possui este passe.","info") return end
   if d.id==0 then UI.toast("Disponivel em breve.","info") return end
   local ok=pcall(function() game:GetService("MarketplaceService"):PromptGamePassPurchase(Players.LocalPlayer,d.id) end) if not ok then UI.toast("Loja indisponivel no momento.","warn") end
  end)
  text(m,d.description,UDim2.new(1,-40,0,36),UDim2.fromOffset(20,140+(i-1)*88),12).TextColor3=muted
  if d.id>0 then task.spawn(function() local ok,info=pcall(function() return game:GetService("MarketplaceService"):GetProductInfo(d.id,Enum.InfoType.GamePass) end) if ok and b.Parent then b.Text=d.name.." · "..(info.IsForSale and tostring(info.PriceInRobux).." Robux" or "Indisponivel") end end) end
 end
 text(m,"COM MOEDAS · Se ja possui, equipa sem cobrar",UDim2.new(1,-32,0,24),UDim2.fromOffset(16,310),11).TextColor3=muted
 for i,c in ipairs(require(RS.Modules.CosmeticCatalog)) do
  button(m,c.name.." · "..c.cost.." moedas",UDim2.new(1,-32,0,36),UDim2.fromOffset(16,342+(i-1)*44),function() RS.Remotes.BuyCosmetic:FireServer(c.id) end)
 end
end
local function settings()
 local m=openModal("Opcoes",265)
 button(m,"Reduzir flashes: alternar",UDim2.new(1,-32,0,40),UDim2.fromOffset(16,65),function() actions.setting("accessibility","reduceFlashes") end)
 button(m,"Sombras: alternar",UDim2.new(1,-32,0,40),UDim2.fromOffset(16,115),function() actions.setting("graphics","shadows") end)
 button(m,"Acenar · G",UDim2.new(1,-32,0,40),UDim2.fromOffset(16,165),function() RS.Remotes.Emote:FireServer("Emote1") end)
end
function UI.init(callbacks)
 actions=callbacks or {}
 local gui=Instance.new("ScreenGui") gui.Name="ConstrutorVsCorredores" gui.ResetOnSpawn=false gui.DisplayOrder=10 gui.ZIndexBehavior=Enum.ZIndexBehavior.Sibling gui.Parent=Players.LocalPlayer:WaitForChild("PlayerGui")
 root=Instance.new("Frame") root.BackgroundTransparency=1 root.Size=UDim2.fromScale(1,1) root.Parent=gui
 local top=panel(root,UDim2.new(.65,0,0,50),UDim2.new(.5,0,0,10)) top.AnchorPoint=Vector2.new(.5,0)
 local limit=Instance.new("UISizeConstraint") limit.MaxSize=Vector2.new(400,50) limit.Parent=top
 header=text(top,"Carregando...",UDim2.new(1,-20,1,-4),UDim2.fromOffset(10,0),14)
 local track=Instance.new("Frame") track.Size=UDim2.new(1,-20,0,2) track.Position=UDim2.new(0,10,1,-3) track.BorderSizePixel=0 track.BackgroundColor3=Color3.fromRGB(45,59,76) track.Parent=top
 timer=Instance.new("Frame") timer.BorderSizePixel=0 timer.Size=UDim2.fromScale(0,1) timer.BackgroundColor3=accent timer.Parent=track
 local status=panel(root,UDim2.new(.42,0,0,58),UDim2.fromOffset(12,72)) local cap=Instance.new("UISizeConstraint") cap.MaxSize=Vector2.new(210,58) cap.Parent=status
 role=text(status,"Lobby",UDim2.new(1,-20,0,26),UDim2.fromOffset(10,2),14) role.TextXAlignment=Enum.TextXAlignment.Left
 detail=text(status,"",UDim2.new(1,-20,0,22),UDim2.fromOffset(10,27),12) detail.TextColor3=muted detail.TextXAlignment=Enum.TextXAlignment.Left
 energyTrack=Instance.new("Frame") energyTrack.Size=UDim2.new(1,-20,0,2) energyTrack.Position=UDim2.new(0,10,1,-4) energyTrack.BackgroundTransparency=1 energyTrack.Parent=status
 energy=Instance.new("Frame") energy.Size=UDim2.fromScale(1,1) energy.BackgroundColor3=accent energy.BorderSizePixel=0 energy.Parent=energyTrack
 menu=panel(root,UDim2.fromOffset(184,232),UDim2.new(1,-196,0,64)) menu.Visible=false menu.ZIndex=10
 balance=text(menu,"0 moedas · Nivel 1",UDim2.new(1,-16,0,38),UDim2.fromOffset(8,5),12) balance.TextColor3=muted
 for i,item in ipairs({{"Como jogar",help},{"Loja",shop},{"Opcoes",settings},{"Acenar",function() RS.Remotes.Emote:FireServer("Emote1") end}}) do button(menu,item[1],UDim2.new(1,-16,0,36),UDim2.fromOffset(8,46+(i-1)*44),item[2]) end
 button(root,"☰",UDim2.fromOffset(40,40),UDim2.new(1,-52,0,10),function() menu.Visible=not menu.Visible hideModal() end)
 toast=text(root,"",UDim2.new(.8,0,0,44),UDim2.new(.1,0,0,140),14) toast.Visible=false toast.ZIndex=50
 dock=panel(root,UDim2.new(1,-24,0,134),UDim2.new(0,12,1,-146)) dock.Visible=false
 selectedText=text(dock,"",UDim2.new(.5,0,0,28),UDim2.fromOffset(10,0),12) selectedText.TextXAlignment=Enum.TextXAlignment.Left
 for i,item in ipairs({{"Girar · R",function() actions.rotate() end},{"Altura · T",function() actions.height() end},{"Desfazer · Z",function() RS.Remotes.UndoPiece:FireServer() end}}) do button(dock,item[1],UDim2.new(.31,0,0,30),UDim2.new(.02+(i-1)*.33,0,0,32),item[2]) end
 cards=Instance.new("ScrollingFrame") cards.Size=UDim2.new(1,-20,0,57) cards.Position=UDim2.fromOffset(10,70) cards.BackgroundTransparency=1 cards.BorderSizePixel=0 cards.ScrollBarThickness=3 cards.ScrollingDirection=Enum.ScrollingDirection.X cards.Parent=dock
 dash=button(root,"Dash · Q",UDim2.fromOffset(106,46),UDim2.new(1,-118,1,-70),function() RS.Remotes.UseDash:FireServer() end) dash.Visible=false
 RS.Remotes.StatsUpdate.OnClientEvent:Connect(function(d) UI.coins=d.coins or 0 balance.Text=tostring(UI.coins).." moedas · Nivel "..tostring(d.level or 1) if UI.shopBalance and UI.shopBalance.Parent then UI.shopBalance.Text="Saldo: "..tostring(UI.coins).." moedas · Apenas cosmeticos" end end)
 return UI
end
return UI
