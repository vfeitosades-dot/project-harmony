local RS=game:GetService("ReplicatedStorage")
local Lighting=game:GetService("Lighting")
local S=require(RS.Modules.Settings)
local U=require(RS.Modules.Util)
local X={current=U.deepCopy(S.DEFAULTS)}
function X.apply(data)
 X.current=S.validate(data) Lighting.GlobalShadows=X.current.graphics.shadows
 local cam=workspace.CurrentCamera if cam then cam.FieldOfView=X.current.controls.fov end
 local bloom=Lighting:FindFirstChildOfClass("BloomEffect") if bloom then bloom.Enabled=X.current.graphics.bloom end
end
function X.toggle(category,key)
 local d=U.deepCopy(X.current)
 if type(d[category])=="table" and type(d[category][key])=="boolean" then d[category][key]=not d[category][key] X.apply(d) RS.Remotes.SaveSettings:FireServer(d) end
end
function X.init() RS.Remotes.SettingsLoad.OnClientEvent:Connect(X.apply) end
return X
