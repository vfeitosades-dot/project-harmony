-- Sem audios externos: os placeholders silenciosos podem ser substituidos no SoundBank.
local RS=game:GetService("ReplicatedStorage")
local SoundService=game:GetService("SoundService")
local Bank=require(RS.Modules.SoundBank)
local U=require(RS.Modules.Util)
local Settings=require(script.Parent.SettingsController)
local A={} local music=nil
local function play(key,group)
 local id=Bank.SFX[key] or Bank.UI[key] if not id or id=="rbxassetid://0" then return end
 local s=U.createSound(SoundService,id,{Volume=Bank.volumeOf(key)*Settings.current.audio.master/100})
 local master=SoundService:FindFirstChild("Master") s.SoundGroup=master and master:FindFirstChild(group or "SFX")
 s:Play() s.Ended:Once(function() s:Destroy() end) game:GetService("Debris"):AddItem(s,30)
end
function A.setState(state)
 if music then music:Destroy() music=nil end local key=state=="RUNNING" and "running" or state=="PREPARING" and "preparing" or "lobby" local id=Bank.MUSIC[key]
 if id and id~="rbxassetid://0" then music=U.createSound(SoundService,id,{Looped=true,Volume=Settings.current.audio.music/100*Settings.current.audio.master/100}) music:Play() end
end
function A.init() RS.Remotes.PieceActivated.OnClientEvent:Connect(function(id) play(id=="Dash" and "place" or id) end) end
return A
