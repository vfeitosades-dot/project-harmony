local Players=game:GetService("Players")
local Run=game:GetService("RunService")
local Input=game:GetService("UserInputService")
local C=require(game:GetService("ReplicatedStorage").Modules.Config)
local Cam={} local building=false local focus=Vector3.new(0,50,120) local height=230
function Cam.setRole(role) building=role=="Builder" or role=="Helper" if building then focus=C.ARENA.ORIGIN+Vector3.new(0,0,120) end end
function Cam.init()
 local pinchHeight=height
 Input.TouchPinch:Connect(function(_,scale,_,state,processed)
  if not building or processed then return end
  if state==Enum.UserInputState.Begin then pinchHeight=height elseif state==Enum.UserInputState.Change and scale>0 then height=math.clamp(pinchHeight/scale,65,300) end
 end)
 Input.InputChanged:Connect(function(i,gp) if building and not gp and i.UserInputType==Enum.UserInputType.MouseWheel then height=math.clamp(height-i.Position.Z*16,65,300) end end)
 Run:BindToRenderStep("BuilderCamera",Enum.RenderPriority.Camera.Value+1,function(dt)
  local camera=workspace.CurrentCamera if not camera then return end
  if building then
   camera.CameraType=Enum.CameraType.Scriptable
   if not Input:GetFocusedTextBox() then
    local x=(Input:IsKeyDown(Enum.KeyCode.D) and 1 or 0)-(Input:IsKeyDown(Enum.KeyCode.A) and 1 or 0)
    local z=(Input:IsKeyDown(Enum.KeyCode.W) and 1 or 0)-(Input:IsKeyDown(Enum.KeyCode.S) and 1 or 0)
    focus+=Vector3.new(-x,0,z)*dt*60 focus=Vector3.new(math.clamp(focus.X,-40,40),C.ARENA.ORIGIN.Y,math.clamp(focus.Z,0,240))
   end
   camera.CFrame=CFrame.lookAt(focus+Vector3.new(0,height,0),focus,Vector3.new(0,0,1))
  elseif camera.CameraType==Enum.CameraType.Scriptable then
   camera.CameraType=Enum.CameraType.Custom local char=Players.LocalPlayer.Character local hum=char and char:FindFirstChildOfClass("Humanoid") if hum then camera.CameraSubject=hum end
  end
 end)
end
return Cam
