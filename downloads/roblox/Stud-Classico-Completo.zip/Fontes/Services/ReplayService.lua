-- Reservado para a etapa 10; nenhum replay e gravado nesta base.
local R={}
function R.init() end
return R
