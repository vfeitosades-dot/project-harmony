local RS=game:GetService("ReplicatedStorage")
local DSS=game:GetService("DataStoreService")
local Players=game:GetService("Players")
local C=require(RS.Modules.Config)
local D=require(script.Parent.DataService)
local R=RS:WaitForChild("Remotes")
local S={} local participants={} local scores={} local roles={} local kills={} local finishes={} local top={} local dirty={}
local store=DSS:GetOrderedDataStore("Wins_v1")
function S.startRound(list)
 participants=table.clone(list) scores={} roles={} kills={} finishes={}
 for _,p in ipairs(list) do scores[p]=0 roles[p]=p:GetAttribute("Role") p:SetAttribute("Points",0) end
end
function S.addPoints(p,amount,reason)
 if not p or not p.Parent or scores[p]==nil then return end scores[p]+=amount p:SetAttribute("Points",scores[p])
 if reason~="Sobrevivencia" then R.Toast:FireClient(p,"+"..amount.." · "..(reason or "Pontos"),"good") end
end
function S.registerFinish(p,place) if finishes[p] then return end finishes[p]=place S.addPoints(p,C.SCORE.PLACE[place] or C.SCORE.PLACE_DEFAULT,"Chegada #"..place) end
function S.registerElimination(victim,killer,pieceId)
 if killer and killer~=victim then
  kills[killer]=(kills[killer] or 0)+1
  if roles[killer]=="Builder" then
   local before=(kills[killer]-1)*C.SCORE.BUILDER_PER_ELIM local grant=math.max(0,math.min(C.SCORE.BUILDER_PER_ELIM,C.SCORE.BUILDER_ELIM_MAX-before))
   if grant>0 then S.addPoints(killer,grant,"Eliminacao") end
  else S.addPoints(killer,C.SCORE.HELPER_ELIM,"Ajuda") end
 end
end
function S.registerCombo(p) S.addPoints(p,C.SCORE.BUILDER_COMBO,"Combo") end
function S.tickSurvival(runners) for _,p in ipairs(runners) do S.addPoints(p,C.SCORE.SURVIVE_PER_5S,"Sobrevivencia") end end
function S.finishRound(winner,summary)
 local podium={} local mvp=nil local highest=-1
 for _,p in ipairs(participants) do
  if p.Parent then
   if roles[p]=="Builder" and winner=="Builder" then S.addPoints(p,C.SCORE.BUILDER_WIN,"Vitoria") end
   if (scores[p] or 0)>highest then mvp=p highest=scores[p] or 0 end
   if finishes[p] then table.insert(podium,{userId=p.UserId,place=finishes[p],points=scores[p] or 0}) end
   D.update(p,function(d)
    d.stats.rounds+=1 d.stats.eliminations+=(kills[p] or 0)
    if roles[p]=="Builder" then d.stats.timesBuilder+=1 if winner=="Builder" then d.stats.winsBuilder+=1 end
    elseif winner=="Runners" then d.stats.winsRunner+=1 end
    if finishes[p] and (d.stats.bestPlace==0 or finishes[p]<d.stats.bestPlace) then d.stats.bestPlace=finishes[p] end
   end)
   local d=D.get(p) if d and D.isPersistent(p) then dirty[p.UserId]=d.stats.winsRunner+d.stats.winsBuilder end
   D.addCoins(p,math.round((scores[p] or 0)*C.SCORE.COINS_FACTOR)) D.addXp(p,scores[p] or 0)
  end
 end
 table.sort(podium,function(a,b) return a.place<b.place end)
 for _,p in ipairs(Players:GetPlayers()) do
  R.RoundResult:FireClient(p,{winner=winner,podium=podium,mvpUserId=mvp and mvp.UserId,rewards={coins=math.round((scores[p] or 0)*C.SCORE.COINS_FACTOR),xp=scores[p] or 0},stats={eliminations=kills[p] or 0}})
 end
 return {winner=winner,podium=podium,mvpUserId=mvp and mvp.UserId,rewards={coins=0,xp=0},stats={eliminations=0}}
end
function S.getTopWins(n) local out={} for i=1,math.min(n or 10,#top) do out[i]=top[i] end return out end
function S.init()
 -- Uma escrita por jogador alterado a cada 120s; uma leitura global por ciclo.
 task.spawn(function()
  while true do
   task.wait(C.DATA.RANK_INTERVAL)
   for userId,value in pairs(dirty) do
    local ok=pcall(function() store:UpdateAsync(tostring(userId),function(old) return math.max(old or 0,value) end) end)
    if ok and dirty[userId]==value then dirty[userId]=nil end
   end
   local ok,page=pcall(function() return store:GetSortedAsync(false,10):GetCurrentPage() end)
   if ok then
    top={} for _,entry in ipairs(page) do table.insert(top,{userId=tonumber(entry.key),wins=entry.value}) end
    local map=require(script.Parent.MapService) map.updateLeaderboard(top)
   end
  end
 end)
end
return S
