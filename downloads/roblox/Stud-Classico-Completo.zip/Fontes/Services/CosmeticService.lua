local RS=game:GetService("ReplicatedStorage")
local Players=game:GetService("Players")
local Data=require(script.Parent.DataService)
local Catalog=require(RS.Modules.CosmeticCatalog)
local U=require(RS.Modules.Util)
local S={}
local function apply(p)
 local d=Data.get(p) local torso=p.Character and p.Character:FindFirstChild("Torso")
 if not d or not torso then return end
 for _,c in ipairs(Catalog) do if d.equipped.shirt==c.id then torso.Color=c.color break end end
end
function S.init()
 local limit=U.rateLimiter(2)
 RS.Remotes.BuyCosmetic.OnServerEvent:Connect(function(p,id)
  if not limit(p) or type(id)~="string" or #id>32 then return end
  local choice=nil for _,c in ipairs(Catalog) do if c.id==id then choice=c break end end if not choice then return end
  local granted=false
  Data.update(p,function(d)
   d.owned.shirts=d.owned.shirts or {}
   if not table.find(d.owned.shirts,id) then
    if d.coins<choice.cost then return end
    d.coins-=choice.cost table.insert(d.owned.shirts,id)
   end
   d.equipped.shirt=id granted=true
  end)
  if granted then apply(p) Data.addCoins(p,0) RS.Remotes.Toast:FireClient(p,"Camisa equipada!","good") else RS.Remotes.Toast:FireClient(p,"Moedas insuficientes.","warn") end
 end)
 local function add(p)
  p.CharacterAdded:Connect(function(char) char:WaitForChild("Torso",10) Data.waitForData(p,25) if p.Character==char then apply(p) end end)
  task.spawn(function() Data.waitForData(p,25) apply(p) end)
 end
 Players.PlayerAdded:Connect(add) for _,p in ipairs(Players:GetPlayers()) do add(p) end
end
return S
