local RS=game:GetService("ReplicatedStorage")
local Players=game:GetService("Players")
local Run=game:GetService("RunService")
local C=require(RS.Modules.Config)
local U=require(RS.Modules.Util)
local Catalog=require(RS.Modules.PieceCatalog)
local Map=require(script.Parent.MapService)
local Piece=require(script.Parent.PieceService)
local Runner=require(script.Parent.RunnerService)
local B={}
B.REASONS={SemEnergia="Sem energia",Cooldown="Aguarde um instante",ZonaProibida="Perto de largada/checkpoint/chegada",ForaDoMapa="Fora do mapa",Sobreposicao="Ja existe uma peca aqui",CaminhoBloqueado="Deixe passagem livre",LimiteEpica="Limite de peca epica",PecaInvalida="Peca invalida",Estado="Espere a corrida comecar"}
local active=false local accounts={} local placed={} local started=0 local lastSend=0 local lastSurge=-1
local rate=U.rateLimiter(C.BUILD.REQUESTS_PER_SECOND)
local function reject(p,reason) RS.Remotes.PlaceResult:FireClient(p,false,reason) return false,reason end
local function register(p,helper)
 local max=helper and C.ENERGY.HELPER_MAX or C.ENERGY.MAX
 accounts[p]={energy=max,max=max,regen=helper and C.ENERGY.HELPER_REGEN or C.ENERGY.REGEN,last=-math.huge,epicAt=-math.huge,cooldowns={},lastPiece=nil}
 p:SetAttribute("Energy",max) p:SetAttribute("MaxEnergy",max) RS.Remotes.EnergyUpdate:FireClient(p,max,max)
end
function B.addHelper(p) if active and p.Parent and p:GetAttribute("Role")=="Helper" then register(p,true) end end
function B.startRound(builder) B.endRound() active=true started=os.clock() lastSurge=-1 register(builder,false) end
function B.endRound()
 active=false accounts={}
 for _,entry in ipairs(placed) do Piece.dissolve(entry.model) end placed={}
end
local function solidWidth(cf,size)
 local x=math.abs(cf.RightVector.X)*size.X+math.abs(cf.LookVector.X)*size.Z
 local z=math.abs(cf.RightVector.Z)*size.X+math.abs(cf.LookVector.Z)*size.Z
 return x,z
end
local function blocked(cf,size)
 if size.Y<=1 then return false end
 local w,z=solidWidth(cf,size) local half=C.ARENA.WIDTH/2
 -- Calcula a uniao de intervalos em X por faixa, sem dupla contagem.
 for strip=0,math.ceil(C.ARENA.LENGTH/8)-1 do
  local low=strip*8 local high=low+8 local intervals={}
  local function add(c,s)
   if s.Y<=1 then return end local xw,zw=solidWidth(c,s) local rel=c.Position-C.ARENA.ORIGIN
   if rel.Z+zw/2>low and rel.Z-zw/2<high then table.insert(intervals,{math.max(-half,rel.X-xw/2),math.min(half,rel.X+xw/2)}) end
  end
  add(cf,size)
  for _,e in ipairs(placed) do if e.model.Parent then add(e.cf,e.size) end end
  table.sort(intervals,function(a,b) return a[1]<b[1] end)
  local total=0 local right=-math.huge
  for _,v in ipairs(intervals) do if v[2]>right then total+=v[2]-math.max(v[1],right) right=v[2] end end
  if total>C.ARENA.WIDTH*C.ARENA.MAX_BLOCK_RATIO then return true end
 end return false
end
function B.handlePlace(p,id,cf)
 if not rate(p) then return reject(p,"Cooldown") end
 if type(id)~="string" or #id>64 or typeof(cf)~="CFrame" then return reject(p,"PecaInvalida") end
 for _,n in ipairs({cf:GetComponents()}) do if n~=n or math.abs(n)>1000000 then return reject(p,"ForaDoMapa") end end
 local a=accounts[p] local role=p:GetAttribute("Role")
 if not active or not a or (role~="Builder" and role~="Helper") then return reject(p,"Estado") end
 local d=Catalog.get(id) if not d or (role=="Helper" and not d.helper) then return reject(p,"PecaInvalida") end
 local now=os.clock()
 if a.energy<d.custo then return reject(p,"SemEnergia") end
 if now-a.last<C.ENERGY.PLACE_COOLDOWN or now-(a.cooldowns[id] or -math.huge)<d.cooldown then return reject(p,"Cooldown") end
 local pos=cf.Position
 if not Map.isInsideArena(pos) then return reject(p,"ForaDoMapa") end
 if Map.isInForbiddenZone(pos) then return reject(p,"ZonaProibida") end
 local baseY=C.ARENA.ORIGIN.Y+d.tamanho.Y/2-1
 local level=math.clamp(math.round((pos.Y-baseY)/C.BUILD.HEIGHT_STEP),0,C.BUILD.HEIGHT_LEVELS-1)
 local snapped=U.snapToGrid(Vector3.new(pos.X,0,pos.Z),C.PIECES.GRID)
 local _,yaw=cf:ToOrientation() yaw=math.round(yaw/(math.pi/2))*(math.pi/2)
 local target=CFrame.new(snapped.X,baseY+level*C.BUILD.HEIGHT_STEP,snapped.Z)*CFrame.Angles(0,yaw,0)
 local width,depth=solidWidth(target,d.tamanho) local rel=target.Position-C.ARENA.ORIGIN
 if math.abs(rel.X)+width/2>C.ARENA.WIDTH/2 or rel.Z-depth/2<0 or rel.Z+depth/2>C.ARENA.LENGTH then return reject(p,"ForaDoMapa") end
 if Map.isInForbiddenZone(target.Position) then return reject(p,"ZonaProibida") end
 if (target.Position-(C.ARENA.ORIGIN+Vector3.new(0,0,C.ARENA.LENGTH/2))).Magnitude>C.ARENA.LENGTH then return reject(p,"ForaDoMapa") end
 local filter=OverlapParams.new() filter.FilterType=Enum.RaycastFilterType.Include filter.FilterDescendantsInstances={workspace.PiecesActive}
 if #workspace:GetPartBoundsInBox(target,d.tamanho-Vector3.new(.15,.15,.15),filter)>0 then return reject(p,"Sobreposicao") end
 local epics=0 for _,e in ipairs(placed) do if e.model.Parent and e.epic then epics+=1 end end
 if d.epic and (epics>=C.PIECES.MAX_EPIC_ACTIVE or now-a.epicAt<C.PIECES.EPIC_COOLDOWN) then return reject(p,"LimiteEpica") end
 if blocked(target,d.tamanho) then return reject(p,"CaminhoBloqueado") end
 -- Todas as validacoes passaram: agora modifica o estado.
 if #placed>=C.PIECES.MAX_ACTIVE then local old=table.remove(placed,1) Piece.dissolve(old.model) end
 local m=Piece.spawn(id,target,p)
 a.energy-=d.custo a.last=now a.cooldowns[id]=now if d.epic then a.epicAt=now end
 local entry={model=m,owner=p,cost=d.custo,time=now,expires=now+(d.vidaUtil or C.PIECES.LIFETIME),cf=target,size=d.tamanho,epic=d.epic}
 table.insert(placed,entry) a.lastPiece=entry
 RS.Remotes.PlaceResult:FireClient(p,true,nil,m:GetAttribute("Uid")) RS.Remotes.PieceActivated:FireAllClients(id,target.Position)
 return true,m:GetAttribute("Uid")
end
function B.undo(p)
 if not rate(p) or not active then return end local a=accounts[p] local e=a and a.lastPiece
 if not e or not e.model.Parent or os.clock()-e.time>C.ENERGY.UNDO_WINDOW then return reject(p,"Cooldown") end
 Piece.dissolve(e.model) a.energy=math.min(a.max,a.energy+e.cost*C.ENERGY.UNDO_REFUND) a.lastPiece=nil
end
function B.init()
 RS.Remotes.PlacePiece.OnServerEvent:Connect(B.handlePlace) RS.Remotes.UndoPiece.OnServerEvent:Connect(B.undo)
 Runner.HelperCreated.Event:Connect(B.addHelper)
 Players.PlayerRemoving:Connect(function(p) accounts[p]=nil end)
 Run.Heartbeat:Connect(function(dt)
  if not active then return end local now=os.clock() local elapsed=now-started
  local cycle=math.floor(elapsed/C.ENERGY.SURGE_INTERVAL)
  local surge=cycle>0 and elapsed%C.ENERGY.SURGE_INTERVAL<C.ENERGY.SURGE_DURATION
  if surge and lastSurge~=cycle then
   lastSurge=cycle for p in pairs(accounts) do if p.Parent then RS.Remotes.Toast:FireClient(p,"SURTO DE ENERGIA!","good") RS.Remotes.ScreenFX:FireClient(p,"flash",.12) end end
  end
  local send=now-lastSend>=C.BUILD.SEND_INTERVAL if send then lastSend=now end
  for p,a in pairs(accounts) do
   a.energy=math.min(a.max,a.energy+a.regen*dt*(surge and C.ENERGY.SURGE_MULTIPLIER or 1))
   if send and p.Parent and a.sent~=math.floor(a.energy*10) then
    a.sent=math.floor(a.energy*10) p:SetAttribute("Energy",a.energy) RS.Remotes.EnergyUpdate:FireClient(p,a.energy,a.max)
   end
  end
  for i=#placed,1,-1 do local e=placed[i] if now>=e.expires or not e.model.Parent then Piece.dissolve(e.model) table.remove(placed,i) end end
 end)
end
return B
