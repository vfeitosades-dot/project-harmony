local RS=game:GetService("ReplicatedStorage")
local CS=game:GetService("CollectionService")
local Lighting=game:GetService("Lighting")
local C=require(RS.Modules.Config)
local U=require(RS.Modules.Util)
local Art=require(RS.Modules.MapArt)
local M={} local theme="NeonCidade" local leaderboard=nil
local function model(parent,name) local m=Instance.new("Model") m.Name=name m.Parent=parent return m end
local function part(parent,name,size,pos,color,material)
 return U.makePart({Parent=parent,Name=name,Size=size,Position=pos,Color=color or C.COLORS.BACKGROUND,Material=material or Enum.Material.Plastic})
end
local function sign(parent,text,pos,size,color)
 local p=part(parent,"Placa",size or Vector3.new(25,7,1),pos,C.COLORS.BACKGROUND)
 local g=Instance.new("SurfaceGui") g.Face=Enum.NormalId.Front g.SizingMode=Enum.SurfaceGuiSizingMode.PixelsPerStud g.PixelsPerStud=35 g.Parent=p
 local l=Instance.new("TextLabel") l.Size=UDim2.fromScale(1,1) l.BackgroundTransparency=1 l.Text=text l.TextColor3=color or C.COLORS.TEXT l.TextScaled=true l.Font=Enum.Font.FredokaOne l.Parent=g
 local pad=Instance.new("UIPadding") pad.PaddingLeft=UDim.new(0,12) pad.PaddingRight=UDim.new(0,12) pad.PaddingTop=UDim.new(0,10) pad.PaddingBottom=UDim.new(0,10) pad.Parent=l
 return l
end
local function neon(parent,name,size,pos,color)
 local p=part(parent,name,size,pos,color,Enum.Material.Neon) p.CanCollide=false p.CanTouch=false p.CanQuery=false p.CastShadow=false p:SetAttribute("ThemeNeon",true) return p
end
local function arch(parent,z,text,color)
 for _,x in ipairs({-18,18}) do neon(parent,"Pilar",Vector3.new(1,13,1),C.ARENA.ORIGIN+Vector3.new(x,6,z),color) end
 neon(parent,"Arco",Vector3.new(37,1,1),C.ARENA.ORIGIN+Vector3.new(0,12,z),color)
 sign(parent,text,C.ARENA.ORIGIN+Vector3.new(0,9,z),Vector3.new(28,4,1),color)
end
function M.buildLobby()
 local folder=workspace.Lobby folder:ClearAllChildren()
 local root=model(folder,"Praca") local o=C.LOBBY.ORIGIN
 local floor=part(root,"PracaCircular",Vector3.new(2,60,60),o-Vector3.new(0,1,0),Color3.fromRGB(28,30,60)) floor.Shape=Enum.PartType.Cylinder floor.Orientation=Vector3.new(0,0,90)
 for i=1,36 do local a=i*math.pi/18 local p=neon(root,"Anel",Vector3.new(5.3,.25,.65),o+Vector3.new(math.cos(a)*29,.12,math.sin(a)*29),C.COLORS.CYAN) p.Orientation=Vector3.new(0,-math.deg(a)-90,0) end
 local spawn=Instance.new("SpawnLocation") spawn.Name="LobbySpawn" spawn.Size=Vector3.new(8,1,8) spawn.Position=o+Vector3.new(0,.1,0) spawn.Anchored=true spawn.Neutral=true spawn.Duration=0 spawn.Material=Enum.Material.Neon spawn.Color=C.COLORS.PURPLE spawn.Parent=root
 sign(root,"CONSTRUTOR\nVS CORREDORES",o+Vector3.new(0,13,22),Vector3.new(38,9,1),C.COLORS.CYAN)
 sign(root,"COMO JOGAR\n1 · Corra e salte entre plataformas\n2 · Construa usando energia\n3 · Alcance a chegada!",o+Vector3.new(-17,7,10),Vector3.new(15,10,1))
 leaderboard=sign(root,"TOP 10\nVitorias globais\nDados apos publicar",o+Vector3.new(17,7,10),Vector3.new(14,10,1),C.COLORS.GOLD)
 sign(root,"TESTE COM 2 JOGADORES\nQ · Dash   |   R · Girar   |   Z · Desfazer",o+Vector3.new(0,4,-22),Vector3.new(31,5,1),C.COLORS.TEXT)
 for _,x in ipairs({-22,22}) do
  part(root,"Banco",Vector3.new(8,1.5,3),o+Vector3.new(x,1,-7),C.COLORS.PURPLE)
  for _,z in ipairs({-16,17}) do
   part(root,"Vaso",Vector3.new(3,3,3),o+Vector3.new(x,1,z),C.COLORS.GOLD)
   local tree=part(root,"Planta",Vector3.new(5,6,5),o+Vector3.new(x,5,z),C.COLORS.SUCCESS) tree.Shape=Enum.PartType.Ball tree.CanCollide=false
  end
 end
 Art.lobby()
 require(RS.Modules.WorldContent).lobby()
end
function M.buildArena(newTheme)
 local arena=workspace.Arena arena:ClearAllChildren()
 local o=C.ARENA.ORIGIN
 local start=model(arena,"Start")
 local p=part(start,"Largada",Vector3.new(40,1,24),o-Vector3.new(0,.5,0)) p:SetAttribute("ThemeFloor",true)
 arch(start,0,"LARGADA",C.COLORS.CYAN)
 for i=1,C.MAX_PLAYERS do
  local slot=part(start,"Slot"..i,Vector3.new(2,.1,2),o+Vector3.new(((i-1)%4-1.5)*5,.1,math.floor((i-1)/4)*4-8),C.COLORS.PURPLE,Enum.Material.Neon)
  slot.CanCollide=false slot.CanTouch=false slot.Transparency=.3 slot:SetAttribute("Index",i) CS:AddTag(slot,"SpawnSlot")
 end
 local checkpoints=model(arena,"Checkpoints")
 for i,z in ipairs(C.ARENA.CHECKPOINTS_Z) do
  local cp=model(checkpoints,"CP"..i)
  local base=part(cp,"Base",Vector3.new(20,1,12),o+Vector3.new(0,-.5,z)) base:SetAttribute("ThemeFloor",true) base:SetAttribute("Index",i) CS:AddTag(base,"Checkpoint")
  neon(cp,"Borda",Vector3.new(20,.12,.4),o+Vector3.new(0,.1,z-6),C.COLORS.CYAN)
  part(cp,"Mastro",Vector3.new(.4,9,.4),o+Vector3.new(8,4,z),C.COLORS.TEXT)
  local flag=part(cp,"Bandeira",Vector3.new(3,2,.2),o+Vector3.new(6.3,7,z),C.COLORS.PURPLE) flag.CanCollide=false
  sign(cp,"CHECKPOINT "..i,o+Vector3.new(0,6,z+5),Vector3.new(15,3,.5),C.COLORS.CYAN)
 end
 local finish=model(arena,"Finish")
 p=part(finish,"Plataforma",Vector3.new(40,1,24),o+Vector3.new(0,-.5,C.ARENA.LENGTH)) p:SetAttribute("ThemeFloor",true)
 arch(finish,C.ARENA.LENGTH,"CHEGADA",C.COLORS.GOLD)
 p=part(finish,"Gatilho",Vector3.new(38,8,2),o+Vector3.new(0,4,C.ARENA.LENGTH),C.COLORS.GOLD) p.Transparency=1 p.CanCollide=false CS:AddTag(p,"FinishLine")
 local trophy=part(finish,"Trofeu",Vector3.new(4,4,4),o+Vector3.new(0,6,C.ARENA.LENGTH+7),C.COLORS.GOLD,Enum.Material.Neon) trophy.Shape=Enum.PartType.Ball trophy.CanCollide=false
 U.tween(trophy,TweenInfo.new(4,Enum.EasingStyle.Linear,Enum.EasingDirection.InOut,-1),{Orientation=Vector3.new(0,360,0)})
 local confetti=Instance.new("ParticleEmitter") confetti.Name="Confetti" confetti.Enabled=false confetti.Rate=80 confetti.Lifetime=NumberRange.new(2,4) confetti.Speed=NumberRange.new(12,20) confetti.SpreadAngle=Vector2.new(180,180) confetti.Color=ColorSequence.new(C.COLORS.CYAN,C.COLORS.GOLD) confetti.Parent=trophy
 local walls=model(arena,"Walls")
 for _,x in ipairs({-20.5,20.5}) do p=part(walls,"Parede",Vector3.new(1,200,264),o+Vector3.new(x,99,120)) p.Transparency=1 p.CanTouch=false end
 p=part(walls,"Teto",Vector3.new(40,1,264),o+Vector3.new(0,199,120)) p.Transparency=1 p.CanTouch=false
 p=part(walls,"Queda",Vector3.new(180,1,330),o+Vector3.new(0,C.ARENA.KILL_Y,120)) p.Transparency=1 p.CanCollide=false CS:AddTag(p,"KillPlane")
 for _,x in ipairs({-20,20}) do neon(walls,"Guia",Vector3.new(.35,.3,264),o+Vector3.new(x,-1,120),C.COLORS.CYAN) end
 local cabin=model(arena,"BuilderCabin")
 p=part(cabin,"Vidro",Vector3.new(18,1,18),C.BUILDER_CABIN-Vector3.new(0,.5,0),C.COLORS.PURPLE,Enum.Material.Glass) p.Transparency=.25
 for _,x in ipairs({-8.5,8.5}) do neon(cabin,"Luz",Vector3.new(.4,.3,18),C.BUILDER_CABIN+Vector3.new(x,.1,0),C.COLORS.CYAN) end
 local seat=Instance.new("Seat") seat.Name="Trono" seat.Anchored=true seat.Disabled=true seat.Size=Vector3.new(4,1,4) seat.Position=C.BUILDER_CABIN+Vector3.new(0,1,0) seat.Color=C.COLORS.GOLD seat.Parent=cabin
 local decor=model(arena,"Decor")
 for i=1,28 do
  local z=(i-1)*10 local x=(i%2==0 and 1 or -1)*(35+(i%5)*8)
  p=part(decor,"Ilha",Vector3.new(10+i%4*3,8,12),o+Vector3.new(x,-8-i%3*3,z),C.COLORS.PURPLE) p.CanCollide=false p.CanTouch=false p.CanQuery=false p.CastShadow=false p:SetAttribute("ThemeDecor",true)
  neon(decor,"Farol",Vector3.new(.5,10,.5),o+Vector3.new(x,1,z),C.COLORS.CYAN)
  if i%3==0 then local star=neon(decor,"Estrela",Vector3.new(1,1,1),o+Vector3.new(x*2,40+i,z),C.COLORS.TEXT) star.Shape=Enum.PartType.Ball end
 end
 Art.arena()
 require(RS.Modules.WorldContent).build(newTheme or theme)
 M.setTheme(newTheme or theme)
end
function M.setTheme(value)
 if not C.THEME_DATA[value] then return end theme=value local data=C.THEME_DATA[value]
 for _,p in ipairs(workspace.Arena:GetDescendants()) do if p:IsA("BasePart") then
  if p:GetAttribute("ThemeFloor") then
   U.tween(p,TweenInfo.new(2),{Color=data.floor}) p.Material=value=="Gelo" and Enum.Material.Ice or Enum.Material.Plastic
   p:SetAttribute("Slippery",value=="Gelo") p.CustomPhysicalProperties=value=="Gelo" and PhysicalProperties.new(.7,.05,.5) or nil
  elseif p:GetAttribute("ThemeNeon") then U.tween(p,TweenInfo.new(2),{Color=data.neon})
  elseif p:GetAttribute("ThemeDecor") then U.tween(p,TweenInfo.new(2),{Color=data.floor}) end
 end end
 U.tween(Lighting,TweenInfo.new(2),{Ambient=data.sky,OutdoorAmbient=data.fog,ClockTime=data.ClockTime,Brightness=data.Brightness,FogColor=data.fog,FogEnd=900})
 RS.Remotes.ThemeChanged:FireAllClients(value)
end
function M.resetArena()
 workspace.PiecesActive:ClearAllChildren()
 for _,p in ipairs(CS:GetTagged("Checkpoint")) do local flag=p.Parent:FindFirstChild("Bandeira") if flag then flag.Color=C.COLORS.PURPLE end end
end
function M.getSpawnCFrames(count)
 local out={} for i=1,count do out[i]=CFrame.new(C.ARENA.ORIGIN+Vector3.new(((i-1)%4-1.5)*5,4,math.floor((i-1)/4)*4-8))*CFrame.Angles(0,math.pi,0) end return out
end
function M.getCheckpointCFrame(i)
 local z=C.ARENA.CHECKPOINTS_Z[i] or 0 return CFrame.new(C.ARENA.ORIGIN+Vector3.new(0,4,z))*CFrame.Angles(0,math.pi,0)
end
function M.getLobbySpawn() return CFrame.new(C.LOBBY.ORIGIN+Vector3.new(0,5,-5)) end
function M.getBuilderCabinCFrame() return CFrame.new(C.BUILDER_CABIN+Vector3.new(0,5,0)) end
function M.isInForbiddenZone(pos)
 local z=pos.Z-C.ARENA.ORIGIN.Z
 for _,center in ipairs({0,60,120,180,C.ARENA.LENGTH}) do if math.abs(z-center)<=C.ARENA.FORBIDDEN_RADIUS then return true end end return false
end
function M.isInsideArena(p)
 local v=p-C.ARENA.ORIGIN return math.abs(v.X)<=C.ARENA.WIDTH/2 and v.Z>=0 and v.Z<=C.ARENA.LENGTH and v.Y>=-2 and v.Y<=16
end
function M.getArenaBounds() local o=C.ARENA.ORIGIN return {min=o+Vector3.new(-C.ARENA.WIDTH/2,-2,0),max=o+Vector3.new(C.ARENA.WIDTH/2,16,C.ARENA.LENGTH)} end
function M.randomTheme(exclude) local list={} for _,v in ipairs(C.THEMES) do if v~=exclude then table.insert(list,v) end end return list[math.random(#list)] end
function M.celebrate() local t=workspace.Arena:FindFirstChild("Finish") local e=t and t:FindFirstChild("Confetti",true) if e then e.Enabled=true task.delay(4,function() if e.Parent then e.Enabled=false end end) end end
function M.updateLeaderboard(list)
 if not leaderboard then return end local lines={"TOP 10 · VITORIAS"}
 for i,v in ipairs(list) do table.insert(lines,string.format("%d. #%d · %d",i,v.userId,v.wins)) end leaderboard.Text=table.concat(lines,"\n")
end
function M.init() M.buildLobby() M.buildArena("NeonCidade") end
return M
