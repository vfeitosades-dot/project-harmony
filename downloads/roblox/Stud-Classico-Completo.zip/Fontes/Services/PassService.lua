local Players=game:GetService("Players")
local Marketplace=game:GetService("MarketplaceService")
local Catalog=require(game:GetService("ReplicatedStorage").Modules.PassCatalog)
local S={}
local function cosmetics(p)
 local char=p.Character local root=char and char:FindFirstChild("HumanoidRootPart")
 if not root then return end
 local old=root:FindFirstChild("PassCosmetics") if old then old:Destroy() end
 local folder=Instance.new("Folder") folder.Name="PassCosmetics" folder.Parent=root
 if p:GetAttribute("PassVIP") then
  local gui=Instance.new("BillboardGui") gui.Size=UDim2.fromOffset(140,28) gui.StudsOffset=Vector3.new(0,3.8,0) gui.AlwaysOnTop=true gui.Parent=folder gui.Adornee=root
  local text=Instance.new("TextLabel") text.Size=UDim2.fromScale(1,1) text.BackgroundTransparency=1 text.Text="★ VIP · "..p.DisplayName text.Font=Enum.Font.GothamBold text.TextColor3=Color3.fromRGB(255,204,69) text.TextSize=14 text.Parent=gui
 end
 if p:GetAttribute("PassVIP") or p:GetAttribute("PassNeon") then
  local a=Instance.new("Attachment") a.Position=Vector3.new(0,.7,0) a.Parent=folder
  local b=Instance.new("Attachment") b.Position=Vector3.new(0,-.7,0) b.Parent=folder
  -- Attachments precisam ser filhos de BasePart para seguir o personagem.
  a.Parent=root b.Parent=root a.Name="PassTrailA" b.Name="PassTrailB"
  for _,v in ipairs(root:GetChildren()) do if (v.Name=="PassTrailA" and v~=a) or (v.Name=="PassTrailB" and v~=b) then v:Destroy() end end
  local t=Instance.new("Trail") t.Attachment0=a t.Attachment1=b t.Lifetime=.45 t.MinLength=.1 t.FaceCamera=true
  t.Color=p:GetAttribute("PassNeon") and ColorSequence.new(Color3.fromRGB(39,224,255),Color3.fromRGB(147,87,204)) or ColorSequence.new(Color3.fromRGB(255,204,69)) t.Parent=folder
 end
end
local function refresh(p,onlyId)
 for _,d in ipairs(Catalog) do
  if d.id>0 and (not onlyId or onlyId==d.id) then
   local ok,owned=pcall(Marketplace.UserOwnsGamePassAsync,Marketplace,p.UserId,d.id)
   if ok and p.Parent then p:SetAttribute(d.attribute,owned) end
  end
 end
 if p.Parent then cosmetics(p) end
end
function S.init()
 local function added(p)
  p.CharacterAdded:Connect(function(char) char:WaitForChild("HumanoidRootPart",10) if p.Character==char then cosmetics(p) end end)
  task.spawn(refresh,p)
 end
 Players.PlayerAdded:Connect(added) for _,p in ipairs(Players:GetPlayers()) do added(p) end
 Marketplace.PromptGamePassPurchaseFinished:Connect(function(p,id,purchased)
  if not purchased then return end
  for _,d in ipairs(Catalog) do if d.id==id and id>0 then task.delay(2,function() refresh(p,id) end) break end end
 end)
end
return S
