local Players=game:GetService("Players")
local RS=game:GetService("ReplicatedStorage")
local CS=game:GetService("CollectionService")
local Run=game:GetService("RunService")
local C=require(RS.Modules.Config)
local U=require(RS.Modules.Util)
local Map=require(script.Parent.MapService)
local Score=require(script.Parent.ScoreService)
local R=RS.Remotes
local S={HelperCreated=Instance.new("BindableEvent"),Finished=Instance.new("BindableEvent")}
-- HelperCreated(player); Finished(player,place): eventos internos, somente servidor.
S.HelperCreated.Name="HelperCreated" S.HelperCreated.Parent=script
S.Finished.Name="Finished" S.Finished.Parent=script
local active=false local records={} local connections={} local hooked={} local finishCount=0
local function setRole(p,role) p:SetAttribute("Role",role) R.RoleAssigned:FireClient(p,role) end
local function configure(p,char)
 local h=char:WaitForChild("Humanoid",5) if not h then return end
 h.UseJumpPower=true h.WalkSpeed=C.RUNNER.WALKSPEED h.JumpPower=C.RUNNER.JUMPPOWER
 local rec=records[p]
 if rec and active then
  task.defer(function() if p.Parent and char.Parent then
   if p:GetAttribute("Role")=="Helper" then for _,v in ipairs(char:GetDescendants()) do if v:IsA("BasePart") then v.Transparency=math.max(v.Transparency,.65) end end char:PivotTo(Map.getBuilderCabinCFrame()) local root=U.getCharacterRoot(p) if root then root.Anchored=true end
   elseif rec.finished then char:PivotTo(Map.getLobbySpawn())
   else S.respawnAtCheckpoint(p) S.freeze(p,rec.frozen) end
  end end)
 end
 h.Died:Connect(function()
  if active and S.isAlive(p) then local r=records[p] r.invuln=0 S.damage(p,"Morte",nil) end
 end)
end
function S.allowMotion(p,seconds) local r=records[p] if r then r.motionUntil=os.clock()+seconds end end
function S.freeze(p,value)
 p:SetAttribute("Frozen",value)
 local r=records[p] if r then r.frozen=value end
 local h=p.Character and p.Character:FindFirstChildOfClass("Humanoid") if h then h.WalkSpeed=value and 0 or C.RUNNER.WALKSPEED h.JumpPower=value and 0 or C.RUNNER.JUMPPOWER end
end
function S.isAlive(p) local r=records[p] return active and r~=nil and not r.finished and p.Parent~=nil and p:GetAttribute("Role")=="Runner" and (p:GetAttribute("Lives") or 0)>0 end
function S.getAlive() local out={} for p in pairs(records) do if S.isAlive(p) then table.insert(out,p) end end return out end
function S.getFinishCount() return finishCount end
function S.respawnAtCheckpoint(p)
 if not p.Character then return end local root=U.getCharacterRoot(p)
 if root then root.AssemblyLinearVelocity=Vector3.zero root.AssemblyAngularVelocity=Vector3.zero end
 p.Character:PivotTo(Map.getCheckpointCFrame(p:GetAttribute("CheckpointIndex") or 0))
end
function S.becomeHelper(p)
 setRole(p,"Helper") local r=records[p] if r then r.invuln=math.huge end
 if p.Character then
  p.Character:PivotTo(Map.getBuilderCabinCFrame()+Vector3.new(5,0,0))
  local root=U.getCharacterRoot(p) if root then root.Anchored=true end
  for _,v in ipairs(p.Character:GetDescendants()) do if v:IsA("BasePart") then v.Transparency=math.max(v.Transparency,.65) end end
 end
 R.Toast:FireClient(p,"Voce virou Ajudante! Construa pontes para os corredores.","info") S.HelperCreated:Fire(p)
end
function S.damage(p,pieceId,byBuilder)
 local rec=records[p] local now=os.clock()
 if not S.isAlive(p) or rec.frozen or now<(rec.invuln or 0) then return end
 rec.invuln=now+C.RUNNER.INVULN_TIME
 local lives=math.max(0,(p:GetAttribute("Lives") or C.RUNNER.LIVES)-1)
 p:SetAttribute("Lives",lives) R.LivesUpdate:FireClient(p,lives) R.ScreenFX:FireClient(p,"flash",.35)
 if lives==0 then
  local recent=now-(p:GetAttribute("InteractionAt") or -100)<2
  local interaction=recent and Players:GetPlayerByUserId(p:GetAttribute("InteractionOwner") or 0) or nil
  if not byBuilder and interaction then byBuilder=interaction pieceId=p:GetAttribute("InteractionPiece") end
  Score.registerElimination(p,byBuilder,pieceId)
  if interaction and interaction:GetAttribute("Role")=="Builder" and (p:GetAttribute("InteractionPiece")=="Trampolim" or p:GetAttribute("InteractionPiece")=="PortalTroll") then Score.registerCombo(interaction) end
  R.PlayerEliminated:FireAllClients({userId=p.UserId,pieceId=pieceId,byUserId=byBuilder and byBuilder.UserId})
  S.becomeHelper(p)
 else
  R.Toast:FireClient(p,"Voce perdeu uma vida · "..lives.." restantes","bad")
  S.respawnAtCheckpoint(p)
  local f=Instance.new("ForceField") f.Visible=true f.Parent=p.Character game:GetService("Debris"):AddItem(f,C.RUNNER.INVULN_TIME)
 end
end
local function playerFromHit(hit) local char=hit:FindFirstAncestorOfClass("Model") return char and Players:GetPlayerFromCharacter(char) end
local function contact(obj,tag,p)
  if not p or not S.isAlive(p) then return end local rec=records[p] if rec.frozen then return end
  local root=U.getCharacterRoot(p) if not root then return end
  local rel=obj.CFrame:PointToObjectSpace(root.Position)
  if math.abs(rel.X)>obj.Size.X/2+2 or math.abs(rel.Z)>obj.Size.Z/2+2 or math.abs(rel.Y)>obj.Size.Y/2+6 then return end
  if tag=="KillPlane" then S.damage(p,"Queda")
  elseif tag=="Hazard" then
   local piece=obj:FindFirstAncestorOfClass("Model") or obj
   if piece:GetAttribute("Armed")~=true then return end
   S.damage(p,piece:GetAttribute("PieceId"),Players:GetPlayerByUserId(piece:GetAttribute("OwnerUserId") or 0))
  elseif tag=="Checkpoint" then
   local index=obj:GetAttribute("Index") if type(index)=="number" and index>(p:GetAttribute("CheckpointIndex") or 0) then
    -- Impede saltar checkpoints em sequencia impossivel.
    if index~=(p:GetAttribute("CheckpointIndex") or 0)+1 then return end
    p:SetAttribute("CheckpointIndex",index) local flag=obj.Parent:FindFirstChild("Bandeira") if flag then U.tween(flag,TweenInfo.new(.4),{Color=C.COLORS.SUCCESS}) end
    R.Toast:FireClient(p,"Checkpoint "..index.." salvo!","good") R.PieceActivated:FireClient(p,"checkpoint",obj.Position)
   end
  elseif tag=="FinishLine" then
   if (p:GetAttribute("CheckpointIndex") or 0)<#C.ARENA.CHECKPOINTS_Z then
    if os.clock()>(rec.finishWarnAt or 0) then rec.finishWarnAt=os.clock()+3 R.Toast:FireClient(p,"Passe pelos 3 checkpoints antes de terminar.","warn") end return end
   rec.finished=true finishCount+=1 p:SetAttribute("InRound",false) Score.registerFinish(p,finishCount)
   R.ReachedFinish:FireAllClients(p.UserId,finishCount) R.Toast:FireClient(p,"Chegada! Posicao #"..finishCount,"good") S.Finished:Fire(p,finishCount)
  elseif tag=="FakeCheckpoint" and os.clock()>(rec.fakeAt or 0) then
   rec.fakeAt=os.clock()+2 R.PieceActivated:FireClient(p,"CheckpointFalso",obj.Position) R.Toast:FireClient(p,"Era um checkpoint falso!","warn")
  end
end
local function hook(obj,tag)
 if not obj:IsA("BasePart") or hooked[obj] then return end hooked[obj]=true
 table.insert(connections,obj.Touched:Connect(function(hit) contact(obj,tag,playerFromHit(hit)) end))
end
function S.startRound(runners)
 S.endRound() active=true finishCount=0 records={}
 for _,p in ipairs(runners) do
  p:SetAttribute("InteractionAt",-100)
  records[p]={invuln=0,dashAt=-math.huge,frozen=true,finished=false,speedTime=0}
  p:SetAttribute("Lives",C.RUNNER.LIVES) p:SetAttribute("CheckpointIndex",0) p:SetAttribute("InRound",true)
  R.LivesUpdate:FireClient(p,C.RUNNER.LIVES) S.freeze(p,true)
 end
 for _,tag in ipairs({"Checkpoint","FakeCheckpoint","FinishLine","KillPlane","Hazard"}) do
  for _,obj in ipairs(CS:GetTagged(tag)) do hook(obj,tag) end
  table.insert(connections,CS:GetInstanceAddedSignal(tag):Connect(function(obj) hook(obj,tag) end))
 end
end
function S.endRound()
 active=false for _,conn in ipairs(connections) do conn:Disconnect() end connections={} hooked={}
 for p in pairs(records) do if p.Parent then S.freeze(p,false) end end records={}
end
function S.init()
 local limit=U.rateLimiter(4)
 R.UseDash.OnServerEvent:Connect(function(p)
  if not limit(p) or not S.isAlive(p) then return end local rec=records[p] local now=os.clock()
  if rec.frozen or now-rec.dashAt<C.RUNNER.DASH_COOLDOWN then return end
  local root=U.getCharacterRoot(p) if not root then return end
  rec.dashAt=now rec.motionUntil=now+.8
  local dir=Vector3.new(root.CFrame.LookVector.X,0,root.CFrame.LookVector.Z)
  if dir.Magnitude<.01 then return end dir=dir.Unit
  root.AssemblyLinearVelocity=dir*C.RUNNER.DASH_FORCE+Vector3.new(0,root.AssemblyLinearVelocity.Y,0)
  R.DashCooldown:FireClient(p,C.RUNNER.DASH_COOLDOWN) R.PieceActivated:FireAllClients("Dash",root.Position)
 end)
 local function added(p) p.CharacterAdded:Connect(function(c) configure(p,c) end) if p.Character then task.spawn(configure,p,p.Character) end end
 Players.PlayerAdded:Connect(added) for _,p in ipairs(Players:GetPlayers()) do added(p) end
 Players.PlayerRemoving:Connect(function(p) records[p]=nil end)
 Run.Heartbeat:Connect(function(dt)
  if not active then return end
  for p,rec in pairs(records) do
   if S.isAlive(p) and not rec.frozen then
    local root=U.getCharacterRoot(p)
    if root then
     if root.Position.Y<C.ARENA.ORIGIN.Y+C.ARENA.KILL_Y-2 then S.damage(p,"Queda") end
     if os.clock()>(rec.objectiveAt or 0) then
      rec.objectiveAt=os.clock()+.1
      for _,obj in ipairs(CS:GetTagged("Checkpoint")) do if obj:IsA("BasePart") then contact(obj,"Checkpoint",p) end end
      for _,obj in ipairs(CS:GetTagged("FinishLine")) do if obj:IsA("BasePart") then contact(obj,"FinishLine",p) end end
     end
     local speed=Vector3.new(root.AssemblyLinearVelocity.X,0,root.AssemblyLinearVelocity.Z).Magnitude
     if speed>C.RUNNER.WALKSPEED*3 and os.clock()>(rec.motionUntil or 0) then rec.speedTime+=dt else rec.speedTime=0 end
     if rec.speedTime>1 then rec.speedTime=0 S.respawnAtCheckpoint(p) warn("[Runner] Velocidade irregular: "..p.UserId) end
    end
   end
  end
 end)
end
return S
