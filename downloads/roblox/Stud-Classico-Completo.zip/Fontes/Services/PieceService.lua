local RS=game:GetService("ReplicatedStorage")
local CS=game:GetService("CollectionService")
local Http=game:GetService("HttpService")
local Run=game:GetService("RunService")
local Players=game:GetService("Players")
local Tween=game:GetService("TweenService")
local U=require(RS.Modules.Util)
local C=require(RS.Modules.Config)
local Catalog=require(RS.Modules.PieceCatalog)
local Art=require(RS.Modules.ModelArt)
local P={} local entries={} local clock=0
local danger={Serra=true,Espinhos=true,EspinhosEscondidos=true,Laser=true,Pendulo=true,Lava=true}
function P.spawn(id,cf,owner)
 local d=Catalog.get(id) local m=Art.spawn(id,cf,workspace.PiecesActive)
 local now=os.clock()
 for k,v in pairs({PieceId=id,Uid=Http:GenerateGUID(false),OwnerUserId=owner.UserId,PlacedAt=now,ExpiresAt=now+d.vidaUtil,Armed=false,Epic=d.epic}) do m:SetAttribute(k,v) end
 local block=U.makePart({Name="Colisao",Size=d.tamanho,CFrame=cf,Transparency=1,CanQuery=true,Color=d.cor,Parent=m})
 block.CanTouch=false
 if danger[id] or id=="PortalTroll" or id=="ParedeFantasma" or id=="BombaRelogio" then block.CanCollide=false end
 if id=="BlocoEscorregadio" then block.CustomPhysicalProperties=PhysicalProperties.new(.7,.02,0) end
 if id=="ParedeFantasma" then for _,v in ipairs(m:GetDescendants()) do if v:IsA("BasePart") and v~=block then v.Transparency=.5 end end end
 if id=="BlocoEscorregadio" then for _,v in ipairs(m:GetDescendants()) do if v:IsA("BasePart") and v.Name=="Base" then v.Material=Enum.Material.Ice v.Transparency=.15 end end end
 m.PrimaryPart=block CS:AddTag(m,"Piece")
 local e={m=m,id=id,cf=cf,d=d,at=now,owner=owner,cool={},armedAt=now+C.PIECES.WARNING_TIME}
 e.sawParts={}
 if id=="Serra" then for _,part in ipairs(m:GetDescendants()) do if part:IsA("BasePart") and (part.Name=="Disco de corte" or part.Name=="Dente" or part.Name=="Miolo") then table.insert(e.sawParts,{part=part,cf=part.CFrame}) end end end
 entries[m]=e
 -- Portais tem entrada e saida deterministicas, visiveis e dentro da arena.
 if id=="PortalTroll" then
  local z=math.clamp(cf.Position.Z+16,16,C.ARENA.LENGTH-16)
  e.exit=CFrame.new(cf.Position.X,cf.Position.Y,z)
  local exit=Art.spawn(id,e.exit,m) exit.Name="SaidaPortal"
 end
 return m
end
function P.dissolve(m) entries[m]=nil if m and m.Parent then m:Destroy() end end
local function flash(m,on)
 for _,p in ipairs(m:GetDescendants()) do if p:IsA("BasePart") and p.Name~="Colisao" then p.Transparency=on and .55 or 0 end end
end
function P.init()
 local folder=RS:FindFirstChild("Pieces")
 for _,d in ipairs(Catalog.list()) do if not folder:FindFirstChild(d.id) then Art.spawn(d.id,CFrame.new(),folder) end end
 local Runner=require(script.Parent.RunnerService)
 Run.Heartbeat:Connect(function(dt)
  clock+=dt if clock<.1 then return end local step=clock clock=0
  local now=os.clock() local alive=Runner.getAlive()
  for m,e in pairs(entries) do
   if not m.Parent then entries[m]=nil continue end
   local t=now-e.at local id=e.id
   local armed=now>=e.armedAt and not e.fell
   if id=="EspinhosEscondidos" then armed=armed and (t%5>=2) end
   if id=="Laser" then armed=armed and (t%4>=1.5) end
   m:SetAttribute("Armed",armed)
   if id=="Serra" then for _,r in ipairs(e.sawParts) do r.part.CFrame=r.cf+e.cf.LookVector*(math.sin(t*1.5)*4) end end
   if id=="PlataformaMovel" then m:PivotTo(e.cf*CFrame.new(0,0,math.sin(t*.9)*8))
   elseif id=="PlataformaGiratoria" then m:PivotTo(e.cf*CFrame.Angles(0,t*.55,0))
   elseif id=="Pendulo" then m:PivotTo(e.cf*CFrame.Angles(0,0,math.sin(t*1.8)*.55)) end
   if id=="Laser" or id=="EspinhosEscondidos" then if e.visual~=armed then e.visual=armed flash(m,not armed) end end
   for _,p in ipairs(alive) do
    local root=U.getCharacterRoot(p)
    if not root or not Runner.isAlive(p) or p:GetAttribute("Frozen") then continue end
    local localPos=m.PrimaryPart.CFrame:PointToObjectSpace(root.Position)
    local size=e.d.tamanho
    local near=math.abs(localPos.X)<=size.X/2+1 and math.abs(localPos.Z)<=size.Z/2+1 and localPos.Y>=-size.Y/2-1 and localPos.Y<=size.Y/2+3.5
    if id=="Serra" then near=near and math.abs(localPos.Z+math.sin(t*1.5)*4)<2.7 end
    if id=="Laser" then near=near and localPos.Y<3.2 end
    if id=="Pendulo" then near=near and math.abs(localPos.Y+2.2)<3.2 end
    if id=="PortalTroll" and e.exit then
     local v=e.exit:PointToObjectSpace(root.Position)
     if math.abs(v.X)<3 and math.abs(v.Z)<3 and math.abs(v.Y)<6 then near=true e.reverse=true else e.reverse=false end
    end
    if not near or not armed then continue end
    if danger[id] then Runner.damage(p,id,e.owner)
    elseif id=="DegrauFalso" and not e.falling then
     e.falling=true task.delay(.4,function() if m.Parent then e.fell=true for _,v in ipairs(m:GetDescendants()) do if v:IsA("BasePart") then v.CanCollide=false Tween:Create(v,TweenInfo.new(.4),{Transparency=1}):Play() end end end end)
    elseif id=="Esteira" then Runner.allowMotion(p,1) local v=root.AssemblyLinearVelocity+e.cf.LookVector*18*step local horizontal=Vector3.new(v.X,0,v.Z) if horizontal.Magnitude>36 then horizontal=horizontal.Unit*36 end root.AssemblyLinearVelocity=horizontal+Vector3.new(0,v.Y,0)
    elseif now>(e.cool[p] or 0) then
     e.cool[p]=now+(id=="Ventilador" and .15 or 1)
     if id=="Trampolim" or id=="PortalTroll" or id=="Ventilador" or id=="MarteloEmpurrao" then p:SetAttribute("InteractionOwner",e.owner.UserId) p:SetAttribute("InteractionAt",now) p:SetAttribute("InteractionPiece",id) end
     if id=="Trampolim" or id=="PortalTroll" or id=="MarteloEmpurrao" then RS.Remotes.PieceActivated:FireAllClients(id,root.Position) end
     if id=="Trampolim" then Runner.allowMotion(p,2) root.AssemblyLinearVelocity=Vector3.new(root.AssemblyLinearVelocity.X,75,root.AssemblyLinearVelocity.Z)
     elseif id=="Ventilador" or id=="MarteloEmpurrao" then Runner.allowMotion(p,2) root.AssemblyLinearVelocity=e.cf.LookVector*(id=="Ventilador" and 35 or 55)+Vector3.new(0,20,0)
     elseif id=="PortalTroll" then
      Runner.allowMotion(p,2) p.Character:PivotTo((e.reverse and e.cf or e.exit)+Vector3.new(0,4,0))
     elseif id=="CheckpointFalso" then RS.Remotes.Toast:FireClient(p,"Checkpoint falso! Seu progresso continua salvo.","warn")
     end
    end
   end
   if id=="BombaRelogio" and t>=5 and not e.exploded then
    e.exploded=true RS.Remotes.PieceActivated:FireAllClients("explosion",e.cf.Position)
    for _,p in ipairs(alive) do local r=U.getCharacterRoot(p) if r and (r.Position-e.cf.Position).Magnitude<12 then Runner.damage(p,id,e.owner) end end
    P.dissolve(m)
   end
  end
 end)
end
return P
