local Players=game:GetService("Players")
local RS=game:GetService("ReplicatedStorage")
local C=require(RS.Modules.Config)
local U=require(RS.Modules.Util)
local Data=require(script.Parent.DataService)
local Score=require(script.Parent.ScoreService)
local Map=require(script.Parent.MapService)
local Runner=require(script.Parent.RunnerService)
local Builder=require(script.Parent.BuilderService)
local R=RS.Remotes
local S={onStateChanged=Instance.new("BindableEvent")}
S.onStateChanged.Name="StateChanged" S.onStateChanged.Parent=script
local state="WAITING" local timeLeft=0 local round=0 local builder=nil local participants={} local previous=nil local theme="NeonCidade" local grace=nil
local function packet() return {state=state,timeLeft=timeLeft,round=round,builderUserId=builder and builder.UserId,theme=theme} end
local function emit() R.RoundState:FireAllClients(packet()) end
local function setState(value,seconds) state=value timeLeft=seconds or 0 emit() S.onStateChanged:Fire(value) end
local function role(p,value) if p.Parent then p:SetAttribute("Role",value) R.RoleAssigned:FireClient(p,value) end end
local function teleport(p,cf) if p.Character and p.Character:FindFirstChild("HumanoidRootPart") then p.Character:PivotTo(cf) end end
local function present()
 local list={} for _,p in ipairs(participants) do if p.Parent==Players then table.insert(list,p) end end return list
end
local function eligible()
 local list={} for _,p in ipairs(Players:GetPlayers()) do
  local h=p.Character and p.Character:FindFirstChildOfClass("Humanoid")
  if #list<C.MAX_PLAYERS and h and h.Health>0 and Data.get(p) then table.insert(list,p) end
 end return list
end
local function cancelled() return not builder or builder.Parent~=Players or #present()<C.MIN_PLAYERS end
local function reset()
 Builder.endRound() Runner.endRound() Map.resetArena() grace=nil
 for _,p in ipairs(Players:GetPlayers()) do
  role(p,"Lobby") p:SetAttribute("InRound",false) p:SetAttribute("Lives",0) p:SetAttribute("Energy",0) p:SetAttribute("MaxEnergy",0)
  if p.Character then
   local root=U.getCharacterRoot(p) if root then root.Anchored=false end
   p:SetAttribute("Frozen",false)
   for _,v in ipairs(p.Character:GetDescendants()) do if v:IsA("BasePart") and v.Name~="HumanoidRootPart" then v.Transparency=0 end end
   local h=p.Character:FindFirstChildOfClass("Humanoid") if h then h.WalkSpeed=C.RUNNER.WALKSPEED h.UseJumpPower=true h.JumpPower=C.RUNNER.JUMPPOWER end
  end teleport(p,Map.getLobbySpawn())
 end
 participants={} builder=nil
end
function S.getState() return state end
function S.getBuilder() return builder end
function S.getParticipants() return present() end
function S.getTimeLeft() return timeLeft end
local function cycle()
 setState("WAITING",0)
 while #eligible()<C.MIN_PLAYERS do emit() task.wait(1) end
 local candidates=eligible()
 if #candidates>=3 and previous then local filtered={} for _,p in ipairs(candidates) do if p.UserId~=previous then table.insert(filtered,p) end end candidates=filtered end
 builder=U.weightedPick(candidates,function(p) local d=Data.get(p) return 1/(1+(d and d.stats.timesBuilder or 0)) end)
 setState("INTERMISSION",C.TIMES.INTERMISSION)
 for t=C.TIMES.INTERMISSION,1,-1 do
  timeLeft=t emit() if #eligible()<C.MIN_PLAYERS or not builder.Parent then return end task.wait(1)
 end
 participants=eligible() if not table.find(participants,builder) then return end round+=1 previous=builder.UserId
 theme=Map.randomTheme(theme) Map.resetArena() Map.buildArena(theme)
 local runners={} local slots=Map.getSpawnCFrames(#participants)
 for _,p in ipairs(participants) do
  p:SetAttribute("InRound",true)
  if p==builder then role(p,"Builder") teleport(p,Map.getBuilderCabinCFrame()) local root=U.getCharacterRoot(p) if root then root.Anchored=true end
  else role(p,"Runner") table.insert(runners,p) teleport(p,slots[#runners]) end
 end
 Score.startRound(participants) Runner.startRound(runners)
 setState("PREPARING",C.TIMES.PREPARING)
 for t=C.TIMES.PREPARING,1,-1 do timeLeft=t emit() if cancelled() then return end if t<=3 then R.Toast:FireAllClients(tostring(t),"info") end task.wait(1) end
 setState("RUNNING",C.TIMES.RUNNING) grace=nil Builder.startRound(builder)
 for _,p in ipairs(runners) do Runner.freeze(p,false) end R.Toast:FireAllClients("GO! O construtor pode colocar plataformas.","good")
 local deadline=os.clock()+C.TIMES.RUNNING local nextSurvival=os.clock()+5 local winner="Builder"
 while true do
  if cancelled() and not grace and Runner.getFinishCount()==0 then R.Toast:FireAllClients("Rodada cancelada: faltam participantes.","warn") return end
  local now=os.clock()
  if Runner.getFinishCount()>0 and not grace then grace=now+C.FINISH_GRACE end
  if grace then winner="Runners" end
  if (grace and now>=grace) or now>=deadline or #Runner.getAlive()==0 then break end
  timeLeft=math.ceil((grace and math.min(grace,deadline) or deadline)-now) emit()
  if now>=nextSurvival then Score.tickSurvival(Runner.getAlive()) nextSurvival=now+5 end
  task.wait(1)
 end
 Builder.endRound() Runner.endRound() setState("ENDING",C.TIMES.ENDING)
 if winner=="Runners" then Map.celebrate() end Score.finishRound(winner,{})
 for t=C.TIMES.ENDING,1,-1 do timeLeft=t emit() task.wait(1) end
end
function S.init()
 local function added(p)
  p:SetAttribute("Role",state=="WAITING" and "Lobby" or "Spectator") p:SetAttribute("Lives",0) p:SetAttribute("InRound",false) p:SetAttribute("Points",0)
  p.CharacterAdded:Connect(function() task.wait(.25) if p.Parent then
   if p:GetAttribute("Role")=="Builder" then teleport(p,Map.getBuilderCabinCFrame()) local root=U.getCharacterRoot(p) if root then root.Anchored=true end elseif not p:GetAttribute("InRound") then teleport(p,Map.getLobbySpawn()) end
  end end)
 end
 Players.PlayerAdded:Connect(added) for _,p in ipairs(Players:GetPlayers()) do added(p) end
 local limiter=U.rateLimiter(2)
 R.ReadyForData.OnServerEvent:Connect(function(p) if limiter(p) then R.RoundState:FireClient(p,packet()) R.RoleAssigned:FireClient(p,p:GetAttribute("Role") or "Lobby") R.ThemeChanged:FireClient(p,theme) end end)
 Runner.Finished.Event:Connect(function() if state=="RUNNING" and not grace then grace=os.clock()+C.FINISH_GRACE end end)
 task.spawn(function()
  while true do
   local ok,err=xpcall(cycle,debug.traceback) if not ok then warn("[RoundService] "..tostring(err)) R.Toast:FireAllClients("Reiniciando rodada.","warn") end
   setState("RESET",C.TIMES.RESET) reset() task.wait(C.TIMES.RESET)
  end
 end)
end
return S
