local Players=game:GetService("Players")
local DSS=game:GetService("DataStoreService")
local RS=game:GetService("ReplicatedStorage")
local Run=game:GetService("RunService")
local Http=game:GetService("HttpService")
local C=require(RS.Modules.Config)
local U=require(RS.Modules.Util)
local Settings=require(RS.Modules.Settings)
local D={}
local defaults={version=1,coins=0,xp=0,level=1,stats={winsRunner=0,winsBuilder=0,rounds=0,eliminations=0,timePlayed=0,bestPlace=0,timesBuilder=0},settings=Settings.DEFAULTS,owned={trails={},effects={},cabins={},emotes={"Emote1"}},equipped={},tutorialDone=false}
local cache,meta,ready={},{},{}
local store=DSS:GetDataStore("PlayerData_v1")
local session=Http:GenerateGUID(false)
local R=RS:WaitForChild("Remotes")
local memoryOnly=Run:IsStudio() and game.GameId==0
local function reconcile(old,template)
 local out=type(old)=="table" and U.deepCopy(old) or {}
 for k,v in pairs(template) do if type(v)=="table" then out[k]=reconcile(out[k],v) elseif type(out[k])~=type(v) then out[k]=v end end
 out._session=nil return out
end
local function retry(fn)
 for i=1,C.DATA.RETRIES do local ok,result=pcall(fn) if ok then return true,result end if i<C.DATA.RETRIES then task.wait(2^(i-1)) end end
 return false,nil
end
local function push(p)
 if p.Parent and cache[p] then R.SettingsLoad:FireClient(p,cache[p].settings) R.StatsUpdate:FireClient(p,{stats=cache[p].stats,coins=cache[p].coins,xp=cache[p].xp,level=cache[p].level}) end
end
local function load(p)
 local data,loaded=nil,false
 if not memoryOnly then
  local ok,result=retry(function()
   return store:UpdateAsync("Player_"..p.UserId,function(old)
    if type(old)=="table" and type(old._session)=="table" and old._session.id~=session and (old._session.expires or 0)>os.time() then return nil end
    local new=reconcile(old,defaults) new._session={id=session,expires=os.time()+C.DATA.SESSION_TTL} return new
   end)
  end)
  if ok and type(result)=="table" then data=result loaded=true end
 end
 if not p.Parent then
  if loaded then retry(function() return store:UpdateAsync("Player_"..p.UserId,function(old) if old and old._session and old._session.id==session then old._session=nil return old end return nil end) end) end
  return
 end
 cache[p]=reconcile(data,defaults) cache[p].settings=Settings.validate(cache[p].settings)
 meta[p]={noSave=not loaded,busy=false,leaving=false,joined=os.clock()}
 if ready[p] then push(p) end
 if not loaded and not memoryOnly then R.Toast:FireClient(p,"Dados temporarios: esta sessao nao sera salva.","warn") end
end
function D.get(p) return cache[p] end
function D.waitForData(p,timeout) local endAt=os.clock()+(timeout or 25) repeat if cache[p] then return cache[p] end task.wait(.1) until not p.Parent or os.clock()>endAt return nil end
function D.update(p,fn)
 if not cache[p] then return false end
 local copy=U.deepCopy(cache[p]) local ok,err=pcall(fn,copy)
 if not ok then warn("[DataService] "..tostring(err)) return false end cache[p]=copy return true
end
function D.save(p,release)
 local m=meta[p] if not m or m.noSave or m.busy then return false end m.busy=true
 local data=U.deepCopy(cache[p]) data.stats.timePlayed+=math.floor(os.clock()-m.joined) m.joined=os.clock() cache[p].stats.timePlayed=data.stats.timePlayed
 local accepted=false
 local ok=retry(function()
  accepted=false
  return store:UpdateAsync("Player_"..p.UserId,function(old)
   if not old or not old._session or old._session.id~=session then return nil end
   local snapshot=U.deepCopy(data)
   if not release then snapshot._session={id=session,expires=os.time()+C.DATA.SESSION_TTL} end
   accepted=true return snapshot
  end)
 end)
 m.busy=false
 if ok and not accepted then m.noSave=true if p.Parent then R.Toast:FireClient(p,"Outra sessao assumiu os dados. Esta sessao nao sera salva.","warn") end end
 if not ok and p.Parent and not m.warned then m.warned=true R.Toast:FireClient(p,"Falha temporaria ao salvar. Tentaremos novamente.","warn") end
 if ok and accepted then m.warned=false end
 return ok and accepted
end
function D.addCoins(p,n) if D.update(p,function(d) d.coins=math.max(0,d.coins+math.round(n)) end) then push(p) end end
function D.addXp(p,n)
 if D.update(p,function(d)
  d.xp=math.max(0,d.xp+math.round(n)) local level=1 local need=100 local remaining=d.xp
  while remaining>=need do remaining-=need level+=1 need=100+(level-1)*50 end d.level=level
 end) then push(p) end
end
function D.setSettings(p,s) if D.update(p,function(d) d.settings=Settings.validate(s) end) then push(p) end end
function D.isPersistent(p) return meta[p] and not meta[p].noSave end
function D.init()
 local readyLimit=U.rateLimiter(2) local settingsLimit=U.rateLimiter(2) local getLimit=U.rateLimiter(3)
 R.ReadyForData.OnServerEvent:Connect(function(p) if readyLimit(p) then ready[p]=true push(p) end end)
 R.SaveSettings.OnServerEvent:Connect(function(p,s) if settingsLimit(p) and type(s)=="table" then D.setSettings(p,s) end end)
 R.GetPlayerData.OnServerInvoke=function(p)
  if not getLimit(p) then return nil end local d=cache[p] if not d then return nil end
  return {stats=U.deepCopy(d.stats),settings=U.deepCopy(d.settings),coins=d.coins,level=d.level,xp=d.xp,owned=U.deepCopy(d.owned)}
 end
 Players.PlayerAdded:Connect(function(p) task.spawn(load,p) end)
 for _,p in ipairs(Players:GetPlayers()) do task.spawn(load,p) end
 Players.PlayerRemoving:Connect(function(p)
  local m=meta[p] if m then m.leaving=true while m.busy do task.wait(.1) end D.save(p,true) end
  cache[p]=nil meta[p]=nil ready[p]=nil
 end)
 task.spawn(function() while true do task.wait(C.DATA.AUTOSAVE) for p,m in pairs(meta) do if p.Parent and not m.leaving then task.spawn(D.save,p,false) end end end end)
 game:BindToClose(function()
  local count=0
  for p,m in pairs(meta) do if not m.leaving then count+=1 task.spawn(function() while m.busy do task.wait(.1) end D.save(p,true) count-=1 end) end end
  local deadline=os.clock()+25 while count>0 and os.clock()<deadline do task.wait(.1) end
 end)
end
return D
