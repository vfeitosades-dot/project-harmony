-- Construtor vs Corredores · base das etapas 01–05.
local RS=game:GetService("ReplicatedStorage")
local SoundService=game:GetService("SoundService")
local function folder(parent,name) local x=parent:FindFirstChild(name) if not x then x=Instance.new("Folder") x.Name=name x.Parent=parent end return x end
local remotes=folder(RS,"Remotes") local count=0
for _,name in ipairs({"RoundState","RoleAssigned","EnergyUpdate","LivesUpdate","DashCooldown","PlaceResult","PlayerEliminated","ReachedFinish","RoundResult","Toast","ThemeChanged","PieceActivated","ScreenFX","SettingsLoad","StatsUpdate","EmoteBroadcast","PlacePiece","UndoPiece","UseDash","SaveSettings","Emote","ReadyForData","BuyCosmetic"}) do
 if not remotes:FindFirstChild(name) then local r=Instance.new("RemoteEvent") r.Name=name r.Parent=remotes count+=1 end
end
if not remotes:FindFirstChild("GetPlayerData") then local r=Instance.new("RemoteFunction") r.Name="GetPlayerData" r.Parent=remotes count+=1 end
for _,name in ipairs({"Lobby","Arena","PiecesActive"}) do folder(workspace,name) end
for _,name in ipairs({"Pieces","Effects"}) do folder(RS,name) end
local master=SoundService:FindFirstChild("Master") or Instance.new("SoundGroup") master.Name="Master" master.Parent=SoundService
for _,name in ipairs({"Music","SFX","UI"}) do local g=master:FindFirstChild(name) or Instance.new("SoundGroup") g.Name=name g.Parent=master end
print("[Main] Remotes: "..count.." criados")
local services=script.Parent:WaitForChild("Services")
for _,name in ipairs({"MapService","DataService","ScoreService","RunnerService","PieceService","BuilderService","AntiExploitService","ReplayService","PassService","CharacterService","CosmeticService","RoundService"}) do
 local mod=services:FindFirstChild(name)
 if mod then local ok,result=pcall(require,mod) if ok and type(result)=="table" and result.init then local success,err=pcall(result.init) if not success then warn("[Main] "..name..": "..tostring(err)) end elseif not ok then warn("[Main] "..name..": "..tostring(result)) end end
end
