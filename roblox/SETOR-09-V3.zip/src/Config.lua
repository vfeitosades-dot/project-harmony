return {
    Title="SETOR 09", Version="3.0", WalkSpeed=11, SprintSpeed=17, Health=100,
    FlashlightRange=60, FlashlightBrightness=6.5, FlashlightAngle=48,
    FlashlightSpillRange=38, FlashlightSpillBrightness=1.35, FlashlightSpillAngle=88,
    CameraSway=.65, CameraBob=.2,
    FixedCode="", InteractDistance=8,
    EnableScare=true,
    AmbientSound="", FlashlightSound="", PickupSound="", ScareSound="",
    DoorSound="", PrySound="", FootstepSound="",
}
