-- V3: malha criada no Blender, convertida e embarcada no proprio pacote.
-- Sem MeshIds externos. Movimento em lote para reduzir custo por frame.
local V={}
function V.Flashlight(parent)
    local library=script.Parent:WaitForChild("AssetLibrary")
    local model=library:WaitForChild("FlashlightV3"):Clone()
    model.Name="Setor09_FlashlightV3"
    local parts={Objects={},Offsets={},Frames={},Emissives={}}
    for _,p in ipairs(model:GetDescendants()) do
        if p:IsA("BasePart") then
            p.Anchored=true p.CanCollide=false p.CanTouch=false p.CanQuery=false p.CastShadow=false
            table.insert(parts.Objects,p) table.insert(parts.Offsets,p.CFrame)
            if p.Name=="LED" or p.Name=="BatteryLED" then table.insert(parts.Emissives,{Part=p,Color=p.Color,Material=p.Material}) end
        end
    end
    model.Parent=parent
    local emitter=Instance.new("Part") emitter.Name="Emitter" emitter.Size=Vector3.new(.02,.02,.02)
    emitter.Transparency=1 emitter.Anchored=true emitter.CanCollide=false emitter.CanTouch=false emitter.CanQuery=false emitter.CastShadow=false emitter.Parent=model
    local function beam(name,brightness,angle,range)
        local l=Instance.new("SpotLight") l.Name=name l.Face=Enum.NormalId.Front
        l.Color=Color3.fromRGB(246,241,218) l.Brightness=brightness l.Angle=angle l.Range=range l.Shadows=true l.Parent=emitter return l
    end
    local core=beam("FocusedLED",6.5,48,60)
    local spill=beam("PeripheralLight",1.35,88,38)
    local fill=Instance.new("PointLight") fill.Name="NearFill" fill.Range=6 fill.Brightness=.14 fill.Color=Color3.fromRGB(229,234,211) fill.Shadows=true fill.Parent=emitter
    return model,parts,core,{spill,fill}
end
function V.Power(parts,enabled)
    if parts.LastEnabled==enabled then return end parts.LastEnabled=enabled
    for _,v in ipairs(parts.Emissives) do
        v.Part.Material=enabled and v.Material or Enum.Material.SmoothPlastic
        v.Part.Color=enabled and v.Color or Color3.fromRGB(25,34,28)
    end
end
function V.Pose(parts,cf)
    for i,offset in ipairs(parts.Offsets) do parts.Frames[i]=cf*offset end
    workspace:BulkMoveTo(parts.Objects,parts.Frames,Enum.BulkMoveMode.FireCFrameChanged)
end
return V
