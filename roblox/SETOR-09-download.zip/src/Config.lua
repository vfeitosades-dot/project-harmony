return {
    Title="SETOR 09", Version="2.0", WalkSpeed=11, SprintSpeed=17, Health=100,
    FlashlightRange=60, FlashlightBrightness=7.2, FlashlightAngle=48,
    FlashlightSpillRange=38, FlashlightSpillBrightness=1.6, FlashlightSpillAngle=94,
    CameraSway=.65, CameraBob=.2,
    FixedCode="", InteractDistance=8,
    EnableScare=true,
    AmbientSound="", FlashlightSound="", PickupSound="", ScareSound="",
    DoorSound="", PrySound="", FootstepSound="",
}
