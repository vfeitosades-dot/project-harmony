local V={}
function V.Part(parent,name,size,offset,color,material)
    local p=Instance.new("Part") p.Name=name p.Size=size p.CFrame=offset
    p.Color=color p.Material=material or Enum.Material.Metal
    p.Anchored=true p.CanCollide=false p.CanTouch=false p.CanQuery=false p.CastShadow=false
    p.TopSurface=Enum.SurfaceType.Smooth p.BottomSurface=Enum.SurfaceType.Smooth p.Parent=parent
    return p
end

local design={{Name="BatteryHousing",Size=Vector3.new(1.08,0.34,0.34),Offset=CFrame.new(0,0,0.05)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(34,39,41),Material=Enum.Material.Metal,Shape=Enum.PartType.Cylinder},
{Name="RearSeal",Size=Vector3.new(0.045,0.37,0.37),Offset=CFrame.new(0,0,0.6)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(13,17,18),Material=Enum.Material.SmoothPlastic,Shape=Enum.PartType.Cylinder},
{Name="TailCap",Size=Vector3.new(0.13,0.39,0.39),Offset=CFrame.new(0,0,0.68)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(71,77,76),Material=Enum.Material.Metal,Shape=Enum.PartType.Cylinder},
{Name="TailButton",Size=Vector3.new(0.035,0.24,0.24),Offset=CFrame.new(0,0,0.765)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(18,21,22),Material=Enum.Material.SmoothPlastic,Shape=Enum.PartType.Cylinder},
{Name="TailKnurl",Size=Vector3.new(0.045,0.045,0.1),Offset=CFrame.new(0.191,0.0,0.68)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(0.0)),Color=Color3.fromRGB(111,115,108),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="TailKnurl",Size=Vector3.new(0.045,0.045,0.1),Offset=CFrame.new(0.17646099070965576,0.07309253558173215,0.68)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(22.5)),Color=Color3.fromRGB(111,115,108),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="TailKnurl",Size=Vector3.new(0.045,0.045,0.1),Offset=CFrame.new(0.1350573952066306,0.13505739520663057,0.68)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(45.0)),Color=Color3.fromRGB(111,115,108),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="TailKnurl",Size=Vector3.new(0.045,0.045,0.1),Offset=CFrame.new(0.07309253558173216,0.17646099070965576,0.68)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(67.5)),Color=Color3.fromRGB(111,115,108),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="TailKnurl",Size=Vector3.new(0.045,0.045,0.1),Offset=CFrame.new(1.1695376931857223e-17,0.191,0.68)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(90.0)),Color=Color3.fromRGB(111,115,108),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="TailKnurl",Size=Vector3.new(0.045,0.045,0.1),Offset=CFrame.new(-0.07309253558173213,0.17646099070965576,0.68)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(112.5)),Color=Color3.fromRGB(111,115,108),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="TailKnurl",Size=Vector3.new(0.045,0.045,0.1),Offset=CFrame.new(-0.13505739520663057,0.1350573952066306,0.68)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(135.0)),Color=Color3.fromRGB(111,115,108),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="TailKnurl",Size=Vector3.new(0.045,0.045,0.1),Offset=CFrame.new(-0.17646099070965576,0.07309253558173218,0.68)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(157.5)),Color=Color3.fromRGB(111,115,108),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="TailKnurl",Size=Vector3.new(0.045,0.045,0.1),Offset=CFrame.new(-0.191,2.3390753863714447e-17,0.68)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(180.0)),Color=Color3.fromRGB(111,115,108),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="TailKnurl",Size=Vector3.new(0.045,0.045,0.1),Offset=CFrame.new(-0.1764609907096558,-0.07309253558173213,0.68)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(202.5)),Color=Color3.fromRGB(111,115,108),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="TailKnurl",Size=Vector3.new(0.045,0.045,0.1),Offset=CFrame.new(-0.1350573952066306,-0.13505739520663057,0.68)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(225.0)),Color=Color3.fromRGB(111,115,108),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="TailKnurl",Size=Vector3.new(0.045,0.045,0.1),Offset=CFrame.new(-0.07309253558173226,-0.17646099070965574,0.68)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(247.5)),Color=Color3.fromRGB(111,115,108),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="TailKnurl",Size=Vector3.new(0.045,0.045,0.1),Offset=CFrame.new(-3.5086130795571666e-17,-0.191,0.68)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(270.0)),Color=Color3.fromRGB(111,115,108),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="TailKnurl",Size=Vector3.new(0.045,0.045,0.1),Offset=CFrame.new(0.07309253558173219,-0.17646099070965574,0.68)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(292.5)),Color=Color3.fromRGB(111,115,108),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="TailKnurl",Size=Vector3.new(0.045,0.045,0.1),Offset=CFrame.new(0.13505739520663054,-0.1350573952066306,0.68)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(315.0)),Color=Color3.fromRGB(111,115,108),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="TailKnurl",Size=Vector3.new(0.045,0.045,0.1),Offset=CFrame.new(0.17646099070965574,-0.07309253558173226,0.68)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(337.5)),Color=Color3.fromRGB(111,115,108),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="GripRing",Size=Vector3.new(0.025,0.375,0.375),Offset=CFrame.new(0,0,-0.39)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(23,28,29),Material=Enum.Material.SmoothPlastic,Shape=Enum.PartType.Cylinder},
{Name="GripRing",Size=Vector3.new(0.025,0.375,0.375),Offset=CFrame.new(0,0,-0.325)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(23,28,29),Material=Enum.Material.SmoothPlastic,Shape=Enum.PartType.Cylinder},
{Name="GripRing",Size=Vector3.new(0.025,0.375,0.375),Offset=CFrame.new(0,0,-0.26)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(23,28,29),Material=Enum.Material.SmoothPlastic,Shape=Enum.PartType.Cylinder},
{Name="GripRing",Size=Vector3.new(0.025,0.375,0.375),Offset=CFrame.new(0,0,-0.195)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(23,28,29),Material=Enum.Material.SmoothPlastic,Shape=Enum.PartType.Cylinder},
{Name="GripRing",Size=Vector3.new(0.025,0.375,0.375),Offset=CFrame.new(0,0,-0.13)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(23,28,29),Material=Enum.Material.SmoothPlastic,Shape=Enum.PartType.Cylinder},
{Name="GripRing",Size=Vector3.new(0.025,0.375,0.375),Offset=CFrame.new(0,0,-0.065)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(23,28,29),Material=Enum.Material.SmoothPlastic,Shape=Enum.PartType.Cylinder},
{Name="GripRing",Size=Vector3.new(0.025,0.375,0.375),Offset=CFrame.new(0,0,0.0)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(23,28,29),Material=Enum.Material.SmoothPlastic,Shape=Enum.PartType.Cylinder},
{Name="GripRing",Size=Vector3.new(0.025,0.375,0.375),Offset=CFrame.new(0,0,0.065)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(23,28,29),Material=Enum.Material.SmoothPlastic,Shape=Enum.PartType.Cylinder},
{Name="GripRing",Size=Vector3.new(0.025,0.375,0.375),Offset=CFrame.new(0,0,0.13)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(23,28,29),Material=Enum.Material.SmoothPlastic,Shape=Enum.PartType.Cylinder},
{Name="GripRing",Size=Vector3.new(0.025,0.375,0.375),Offset=CFrame.new(0,0,0.19499999999999995)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(23,28,29),Material=Enum.Material.SmoothPlastic,Shape=Enum.PartType.Cylinder},
{Name="GripRing",Size=Vector3.new(0.025,0.375,0.375),Offset=CFrame.new(0,0,0.26)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(23,28,29),Material=Enum.Material.SmoothPlastic,Shape=Enum.PartType.Cylinder},
{Name="GripRing",Size=Vector3.new(0.025,0.375,0.375),Offset=CFrame.new(0,0,0.32500000000000007)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(23,28,29),Material=Enum.Material.SmoothPlastic,Shape=Enum.PartType.Cylinder},
{Name="GripRing",Size=Vector3.new(0.025,0.375,0.375),Offset=CFrame.new(0,0,0.39)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(23,28,29),Material=Enum.Material.SmoothPlastic,Shape=Enum.PartType.Cylinder},
{Name="GripRing",Size=Vector3.new(0.025,0.375,0.375),Offset=CFrame.new(0,0,0.45499999999999996)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(23,28,29),Material=Enum.Material.SmoothPlastic,Shape=Enum.PartType.Cylinder},
{Name="GripRail",Size=Vector3.new(0.04,0.035,0.78),Offset=CFrame.new(0.18,0.0,0.06)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color=Color3.fromRGB(42,47,47),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="GripRail",Size=Vector3.new(0.04,0.035,0.78),Offset=CFrame.new(0.12727922061357855,0.12727922061357855,0.06)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(45)),Color=Color3.fromRGB(42,47,47),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="GripRail",Size=Vector3.new(0.04,0.035,0.78),Offset=CFrame.new(1.1021821192326179e-17,0.18,0.06)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(90)),Color=Color3.fromRGB(42,47,47),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="GripRail",Size=Vector3.new(0.04,0.035,0.78),Offset=CFrame.new(-0.12727922061357855,0.12727922061357855,0.06)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(135)),Color=Color3.fromRGB(42,47,47),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="GripRail",Size=Vector3.new(0.04,0.035,0.78),Offset=CFrame.new(-0.18,2.2043642384652358e-17,0.06)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(180)),Color=Color3.fromRGB(42,47,47),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="GripRail",Size=Vector3.new(0.04,0.035,0.78),Offset=CFrame.new(-0.12727922061357858,-0.12727922061357855,0.06)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(225)),Color=Color3.fromRGB(42,47,47),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="GripRail",Size=Vector3.new(0.04,0.035,0.78),Offset=CFrame.new(-3.306546357697853e-17,-0.18,0.06)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(270)),Color=Color3.fromRGB(42,47,47),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="GripRail",Size=Vector3.new(0.04,0.035,0.78),Offset=CFrame.new(0.12727922061357852,-0.12727922061357858,0.06)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(315)),Color=Color3.fromRGB(42,47,47),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="CopperAccent",Size=Vector3.new(0.035,0.39,0.39),Offset=CFrame.new(0,0,-0.49)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(175,113,51),Material=Enum.Material.Metal,Shape=Enum.PartType.Cylinder},
{Name="HeatSink",Size=Vector3.new(0.042,0.47,0.47),Offset=CFrame.new(0,0,-0.55)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(61,68,69),Material=Enum.Material.Metal,Shape=Enum.PartType.Cylinder},
{Name="HeatSink",Size=Vector3.new(0.042,0.488,0.488),Offset=CFrame.new(0,0,-0.615)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(61,68,69),Material=Enum.Material.Metal,Shape=Enum.PartType.Cylinder},
{Name="HeatSink",Size=Vector3.new(0.042,0.506,0.506),Offset=CFrame.new(0,0,-0.68)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(61,68,69),Material=Enum.Material.Metal,Shape=Enum.PartType.Cylinder},
{Name="HeatSink",Size=Vector3.new(0.042,0.524,0.524),Offset=CFrame.new(0,0,-0.7450000000000001)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(61,68,69),Material=Enum.Material.Metal,Shape=Enum.PartType.Cylinder},
{Name="HeatSink",Size=Vector3.new(0.042,0.5419999999999999,0.5419999999999999),Offset=CFrame.new(0,0,-0.81)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(61,68,69),Material=Enum.Material.Metal,Shape=Enum.PartType.Cylinder},
{Name="HeadBody",Size=Vector3.new(0.32,0.58,0.58),Offset=CFrame.new(0,0,-0.93)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(28,34,35),Material=Enum.Material.Metal,Shape=Enum.PartType.Cylinder},
{Name="ReflectorStep",Size=Vector3.new(0.08,0.64,0.64),Offset=CFrame.new(0,0,-1.1)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(115,124,120),Material=Enum.Material.Metal,Shape=Enum.PartType.Cylinder},
{Name="Gasket",Size=Vector3.new(0.025,0.62,0.62),Offset=CFrame.new(0,0,-1.16)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(10,14,14),Material=Enum.Material.SmoothPlastic,Shape=Enum.PartType.Cylinder},
{Name="ReflectorCone",Size=Vector3.new(0.018,0.5,0.5),Offset=CFrame.new(0,0,-1.18)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(166,177,171),Material=Enum.Material.Metal,Shape=Enum.PartType.Cylinder},
{Name="ReflectorCone",Size=Vector3.new(0.018,0.459,0.459),Offset=CFrame.new(0,0,-1.162)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(161,172,166),Material=Enum.Material.Metal,Shape=Enum.PartType.Cylinder},
{Name="ReflectorCone",Size=Vector3.new(0.018,0.418,0.418),Offset=CFrame.new(0,0,-1.144)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(156,167,161),Material=Enum.Material.Metal,Shape=Enum.PartType.Cylinder},
{Name="ReflectorCone",Size=Vector3.new(0.018,0.377,0.377),Offset=CFrame.new(0,0,-1.126)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(151,162,156),Material=Enum.Material.Metal,Shape=Enum.PartType.Cylinder},
{Name="ReflectorCone",Size=Vector3.new(0.018,0.33599999999999997,0.33599999999999997),Offset=CFrame.new(0,0,-1.1079999999999999)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(146,157,151),Material=Enum.Material.Metal,Shape=Enum.PartType.Cylinder},
{Name="ReflectorCone",Size=Vector3.new(0.018,0.295,0.295),Offset=CFrame.new(0,0,-1.0899999999999999)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(141,152,146),Material=Enum.Material.Metal,Shape=Enum.PartType.Cylinder},
{Name="ReflectorCone",Size=Vector3.new(0.018,0.254,0.254),Offset=CFrame.new(0,0,-1.072)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(136,147,141),Material=Enum.Material.Metal,Shape=Enum.PartType.Cylinder},
{Name="ReflectorCone",Size=Vector3.new(0.018,0.21299999999999997,0.21299999999999997),Offset=CFrame.new(0,0,-1.0539999999999998)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(131,142,136),Material=Enum.Material.Metal,Shape=Enum.PartType.Cylinder},
{Name="Lens",Size=Vector3.new(0.012,0.51,0.51),Offset=CFrame.new(0,0,-1.199)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(189,219,220),Material=Enum.Material.Glass,Shape=Enum.PartType.Cylinder},
{Name="LED",Size=Vector3.new(0.024,0.085,0.085),Offset=CFrame.new(0,0,-1.211)*CFrame.Angles(math.rad(0),math.rad(90),math.rad(0)),Color=Color3.fromRGB(255,246,209),Material=Enum.Material.Neon,Shape=Enum.PartType.Cylinder},
{Name="BezelNotch",Size=Vector3.new(0.07,0.07,0.085),Offset=CFrame.new(0.285,0.0,-1.19)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color=Color3.fromRGB(103,112,108),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="BezelNotch",Size=Vector3.new(0.07,0.07,0.085),Offset=CFrame.new(1.745121688784978e-17,0.285,-1.19)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(90)),Color=Color3.fromRGB(103,112,108),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="BezelNotch",Size=Vector3.new(0.07,0.07,0.085),Offset=CFrame.new(-0.285,3.490243377569956e-17,-1.19)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(180)),Color=Color3.fromRGB(103,112,108),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="BezelNotch",Size=Vector3.new(0.07,0.07,0.085),Offset=CFrame.new(-5.2353650663549345e-17,-0.285,-1.19)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(270)),Color=Color3.fromRGB(103,112,108),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="SwitchPlate",Size=Vector3.new(0.19,0.045,0.31),Offset=CFrame.new(0,0.197,-0.2)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color=Color3.fromRGB(92,100,95),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="SwitchRubber",Size=Vector3.new(0.14,0.045,0.21),Offset=CFrame.new(0,0.236,-0.2)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color=Color3.fromRGB(20,24,24),Material=Enum.Material.SmoothPlastic,Shape=Enum.PartType.Block},
{Name="SwitchLED",Size=Vector3.new(0.03,0.012,0.055),Offset=CFrame.new(0.04,0.262,-0.23)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color=Color3.fromRGB(131,205,174),Material=Enum.Material.Neon,Shape=Enum.PartType.Block},
{Name="SideClip",Size=Vector3.new(0.028,0.06,0.66),Offset=CFrame.new(0.205,0.04,0.2)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color=Color3.fromRGB(121,126,115),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="SerialPlate",Size=Vector3.new(0.012,0.12,0.43),Offset=CFrame.new(-0.192,0,0.12)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color=Color3.fromRGB(105,119,108),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="SerialEtch",Size=Vector3.new(0.014,0.015,0.22),Offset=CFrame.new(-0.201,0.04,0.1)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color=Color3.fromRGB(31,41,37),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="SerialEtch",Size=Vector3.new(0.014,0.015,0.22),Offset=CFrame.new(-0.201,0.015,0.1)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color=Color3.fromRGB(31,41,37),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="SerialEtch",Size=Vector3.new(0.014,0.015,0.22),Offset=CFrame.new(-0.201,-0.010000000000000002,0.1)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color=Color3.fromRGB(31,41,37),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="SerialEtch",Size=Vector3.new(0.014,0.015,0.22),Offset=CFrame.new(-0.201,-0.03500000000000001,0.1)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color=Color3.fromRGB(31,41,37),Material=Enum.Material.Metal,Shape=Enum.PartType.Block},
{Name="GlovePalm",Size=Vector3.new(0.31,0.28,0.32),Offset=CFrame.new(0.03,-0.23,0.09)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color=Color3.fromRGB(45,42,35),Material=Enum.Material.Fabric,Shape=Enum.PartType.Block},
{Name="Finger",Size=Vector3.new(0.075,0.16,0.13),Offset=CFrame.new(-0.105,-0.11,0.1)*CFrame.Angles(math.rad(-14),math.rad(0),math.rad(0)),Color=Color3.fromRGB(58,54,44),Material=Enum.Material.Fabric,Shape=Enum.PartType.Block},
{Name="KnucklePad",Size=Vector3.new(0.063,0.065,0.08),Offset=CFrame.new(-0.105,-0.035,0.1)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color=Color3.fromRGB(32,34,30),Material=Enum.Material.SmoothPlastic,Shape=Enum.PartType.Block},
{Name="Finger",Size=Vector3.new(0.075,0.16,0.13),Offset=CFrame.new(-0.03,-0.11,0.1)*CFrame.Angles(math.rad(-14),math.rad(0),math.rad(0)),Color=Color3.fromRGB(58,54,44),Material=Enum.Material.Fabric,Shape=Enum.PartType.Block},
{Name="KnucklePad",Size=Vector3.new(0.063,0.065,0.08),Offset=CFrame.new(-0.03,-0.035,0.1)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color=Color3.fromRGB(32,34,30),Material=Enum.Material.SmoothPlastic,Shape=Enum.PartType.Block},
{Name="Finger",Size=Vector3.new(0.075,0.16,0.13),Offset=CFrame.new(0.045,-0.11,0.1)*CFrame.Angles(math.rad(-14),math.rad(0),math.rad(0)),Color=Color3.fromRGB(58,54,44),Material=Enum.Material.Fabric,Shape=Enum.PartType.Block},
{Name="KnucklePad",Size=Vector3.new(0.063,0.065,0.08),Offset=CFrame.new(0.045,-0.035,0.1)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color=Color3.fromRGB(32,34,30),Material=Enum.Material.SmoothPlastic,Shape=Enum.PartType.Block},
{Name="Finger",Size=Vector3.new(0.075,0.16,0.13),Offset=CFrame.new(0.11999999999999998,-0.11,0.1)*CFrame.Angles(math.rad(-14),math.rad(0),math.rad(0)),Color=Color3.fromRGB(58,54,44),Material=Enum.Material.Fabric,Shape=Enum.PartType.Block},
{Name="KnucklePad",Size=Vector3.new(0.063,0.065,0.08),Offset=CFrame.new(0.11999999999999998,-0.035,0.1)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color=Color3.fromRGB(32,34,30),Material=Enum.Material.SmoothPlastic,Shape=Enum.PartType.Block},
{Name="Thumb",Size=Vector3.new(0.12,0.22,0.14),Offset=CFrame.new(0.2,-0.14,0.0)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(-24)),Color=Color3.fromRGB(55,51,42),Material=Enum.Material.Fabric,Shape=Enum.PartType.Block},
{Name="Wrist",Size=Vector3.new(0.29,0.27,0.24),Offset=CFrame.new(0.03,-0.28,0.37)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color=Color3.fromRGB(42,43,35),Material=Enum.Material.Fabric,Shape=Enum.PartType.Block},
{Name="Cuff",Size=Vector3.new(0.38,0.34,0.18),Offset=CFrame.new(0.06,-0.3,0.53)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color=Color3.fromRGB(28,34,31),Material=Enum.Material.Fabric,Shape=Enum.PartType.Block},
{Name="Sleeve",Size=Vector3.new(0.39,0.37,0.83),Offset=CFrame.new(0.17,-0.35,1.0)*CFrame.Angles(math.rad(0),math.rad(12),math.rad(0)),Color=Color3.fromRGB(62,70,58),Material=Enum.Material.Fabric,Shape=Enum.PartType.Block},
{Name="CuffStitch",Size=Vector3.new(0.32,0.016,0.02),Offset=CFrame.new(0.06,-0.118,0.48)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color=Color3.fromRGB(119,118,91),Material=Enum.Material.Fabric,Shape=Enum.PartType.Block},
{Name="CuffStitch",Size=Vector3.new(0.32,0.016,0.02),Offset=CFrame.new(0.06,-0.118,0.535)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color=Color3.fromRGB(119,118,91),Material=Enum.Material.Fabric,Shape=Enum.PartType.Block},
{Name="CuffStitch",Size=Vector3.new(0.32,0.016,0.02),Offset=CFrame.new(0.06,-0.118,0.59)*CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color=Color3.fromRGB(119,118,91),Material=Enum.Material.Fabric,Shape=Enum.PartType.Block}}
function V.Flashlight(parent)
    local model=Instance.new("Model") model.Name="Setor09_Flashlight_V2" model.Parent=parent
    local parts={}
    for _,d in ipairs(design) do
        local p=V.Part(model,d.Name,d.Size,d.Offset,d.Color,d.Material)
        p.Shape=d.Shape
        if d.Name=="Lens" then p.Transparency=0.6 end
        table.insert(parts,{p=p,cf=d.Offset})
    end
    local emitter=V.Part(model,"Emitter",Vector3.new(.02,.02,.02),CFrame.new(0,0,-1.25),Color3.new()) emitter.Transparency=1
    table.insert(parts,{p=emitter,cf=CFrame.new(0,0,-1.25)})
    local function beam(name,brightness,angle,range,shadows)
        local l=Instance.new("SpotLight") l.Name=name l.Face=Enum.NormalId.Front l.Color=Color3.fromRGB(255,242,214)
        l.Brightness=brightness l.Angle=angle l.Range=range l.Shadows=shadows l.Parent=emitter return l
    end
    local core=beam("Hotspot",7.2,48,60,true)
    local spill=beam("Spill",1.6,94,38,true)
    local fill=Instance.new("PointLight") fill.Name="NearFill" fill.Color=Color3.fromRGB(236,226,202) fill.Brightness=.22 fill.Range=7 fill.Shadows=true fill.Parent=emitter
    return model,parts,core,{spill,fill}
end
function V.Pose(parts,cf)
    for _,v in ipairs(parts) do v.p.CFrame=cf*v.cf end
end
return V
