local Players=game:GetService("Players")
local RS=game:GetService("ReplicatedStorage")
local Tween=game:GetService("TweenService")
local kit=script.Parent
if RS:FindFirstChild("Setor09") then warn("SETOR 09 duplicado: remova uma copia.") return end
local C=require(kit.Config)
local map=kit:WaitForChild("Labirinto")
local net=Instance.new("Folder") net.Name="Setor09" net.Parent=RS
kit.Config:Clone().Parent=net kit.Visuals:Clone().Parent=net
local action=Instance.new("RemoteEvent") action.Name="Action" action.Parent=net
local event=Instance.new("RemoteEvent") event.Name="Event" event.Parent=net
local rng=Random.new()
local code=C.FixedCode
if type(code)~="string" or not code:match("^%d%d%d$") then code=string.format("%03d",rng:NextInteger(0,999)) end
local exit=map.Exit
local state={}
local boards=3
local codeOpen,keyOpen,doorOpen=false,false,false
local doorParts={}
for _,v in ipairs(exit.Door:GetDescendants()) do
    if v:IsA("BasePart") then
        v.Anchored=false v.Massless=true
        local w=Instance.new("WeldConstraint") w.Part0=exit.Door w.Part1=v w.Parent=v
        table.insert(doorParts,v)
    end
end
local function living(p)
    local char=p.Character
    local h=char and char:FindFirstChildOfClass("Humanoid")
    local root=char and char:FindFirstChild("HumanoidRootPart")
    if h and root and h.Health>0 then return char,h,root end
end
local function near(p,part)
    local _,_,root=living(p)
    return root and (root.Position-part.Position).Magnitude<=C.InteractDistance+2
end
local function send(p,kind,payload) event:FireClient(p,kind,payload) end
local function sync(p)
    local s=state[p] if not s then return end
    send(p,"State",{key=s.key,crowbar=s.crowbar,clue=s.clue,code=s.clue and code or "",
        boards=boards,keyOpen=keyOpen,codeOpen=codeOpen,doorOpen=doorOpen,escaped=s.escaped})
end
local function syncAll() for p in pairs(state) do sync(p) end end
local function message(p,t) send(p,"Message",t) end
local function tryDoor()
    if doorOpen or not keyOpen or not codeOpen or boards>0 then return end
    doorOpen=true
    event:FireAllClients("DoorOpened",true)
    task.delay(1.8,function() exit.Door.CanCollide=false end)
    Tween:Create(exit.Door,TweenInfo.new(1.8,Enum.EasingStyle.Sine),{CFrame=exit.Door.CFrame*CFrame.new(0,11,0)}):Play()
    exit.ExitLamp.Color=Color3.fromRGB(125,224,171)
    local exitLight=exit.ExitLamp:FindFirstChildOfClass("PointLight")
    if exitLight then exitLight.Color=exit.ExitLamp.Color end
    for p in pairs(state) do message(p,"A saída abriu. Vá até o fim do corredor.") end
    syncAll()
end
local function prompt(part,label,object,hold,callback)
    local pr=Instance.new("ProximityPrompt") pr.ActionText=label pr.ObjectText=object
    pr.HoldDuration=hold or 0 pr.MaxActivationDistance=C.InteractDistance
    pr.Style=Enum.ProximityPromptStyle.Custom
    pr.RequiresLineOfSight=true pr.KeyboardKeyCode=Enum.KeyCode.E pr.Parent=part
    pr.Triggered:Connect(function(p) if state[p] and near(p,part) then callback(p,pr) end end)
    return pr
end
prompt(map.Key.PickupPoint,"Pegar chave","CHAVE DE SERVIÇO",0.4,function(p)
    if state[p].key then return end state[p].key=true sync(p) send(p,"Pickup","Key") message(p,"Chave encontrada. Procure a fechadura da saída.")
end)
prompt(map.Crowbar.PickupPoint,"Pegar pé de cabra","FERRAMENTA",0.4,function(p)
    if state[p].crowbar then return end state[p].crowbar=true sync(p) send(p,"Pickup","Crowbar") message(p,"Pé de cabra encontrado. Agora você pode remover as tábuas.")
end)
prompt(map.Note.PickupPoint,"Ler bilhete","REGISTRO DE MANUTENÇÃO",0.2,function(p)
    state[p].clue=true sync(p) send(p,"Note",code)
end)
prompt(exit.Keypad,"Usar teclado","TRAVA ELETRÔNICA",0,function(p)
    if codeOpen then message(p,"Trava eletrônica já liberada.") return end
    send(p,"Keypad",true)
end)
prompt(exit.Lock,"Usar chave","FECHADURA",0.8,function(p,pr)
    if keyOpen then message(p,"Fechadura já aberta.") return end
    if not state[p].key then message(p,"Você precisa encontrar a chave de serviço.") return end
    keyOpen=true pr.Enabled=false message(p,"Fechadura aberta.") syncAll() tryDoor()
end)
local boardList=exit.Boards:GetChildren()
table.sort(boardList,function(a,b) return a.Name<b.Name end)
for _,b in ipairs(boardList) do
    prompt(b,"Arrancar tábua","TÁBUAS PREGADAS",1.1,function(p,pr)
        if not state[p].crowbar then message(p,"As tábuas estão pregadas. Encontre um pé de cabra.") return end
        if b:GetAttribute("Removed") then return end
        b:SetAttribute("Removed",true) pr.Enabled=false b.CanCollide=false
        boards=boards-1
        local final=b.CFrame*CFrame.new(0,-4,-2)*CFrame.Angles(0,0,0.7)
        for _,v in ipairs(b:GetDescendants()) do
            if v:IsA("BasePart") then
                local relative=b.CFrame:ToObjectSpace(v.CFrame)
                v.CanCollide=false v.CanQuery=false
                Tween:Create(v,TweenInfo.new(.55),{CFrame=final*relative,Transparency=1}):Play()
            end
        end
        Tween:Create(b,TweenInfo.new(0.55),{CFrame=b.CFrame*CFrame.new(0,-4,-2)*CFrame.Angles(0,0,0.7),Transparency=1}):Play()
        send(p,"Pry",true) message(p,"Tábua removida. Restam "..boards..".") syncAll() tryDoor()
    end)
end
local function install(p)
    local pg=p:WaitForChild("PlayerGui",15)
    if pg and not pg:FindFirstChild("Setor09Controller") then
        local holder=Instance.new("ScreenGui") holder.Name="Setor09Controller" holder.ResetOnSpawn=false
        kit.HorrorClient:Clone().Parent=holder holder.Parent=pg
    end
end
local function onChar(p,char)
    local h=char:WaitForChild("Humanoid",10)
    if h then h.MaxHealth=C.Health h.Health=C.Health h.WalkSpeed=C.WalkSpeed h.JumpPower=0 h.JumpHeight=0 end
    sync(p)
end
local function added(p)
    if state[p] then return end
    state[p]={key=false,crowbar=false,clue=false,escaped=false,scared=false,last=0,codeLast=0}
    p.CharacterAdded:Connect(function(char) onChar(p,char) end)
    if p.Character then task.spawn(onChar,p,p.Character) end
    task.spawn(install,p)
end
Players.PlayerAdded:Connect(added)
Players.PlayerRemoving:Connect(function(p) state[p]=nil end)
for _,p in ipairs(Players:GetPlayers()) do added(p) end
local function worldFlashlight(p,enabled)
    local char=p.Character local head=char and char:FindFirstChild("Head") if not head then return end
    local l=head:FindFirstChild("Setor09WorldLight")
    if not l then l=Instance.new("SpotLight") l.Name="Setor09WorldLight" l.Face=Enum.NormalId.Front l.Range=40 l.Angle=70 l.Brightness=2.4 l.Shadows=true l.Parent=head end
    l.Enabled=enabled
end
action.OnServerEvent:Connect(function(p,kind,data)
    local s=state[p] if not s or type(kind)~="string" then return end
    local now=os.clock() if now-s.last<0.08 then return end s.last=now
    if kind=="Sync" then sync(p) return end
    local _,h=living(p) if not h then return end
    if kind=="Code" then
        if now-s.codeLast<1 or not near(p,exit.Keypad) then return end s.codeLast=now
        if codeOpen then return end
        if type(data)~="string" or not data:match("^%d%d%d$") then return end
        if not s.clue then message(p,"Encontre e leia o bilhete antes de tentar a combinação.") return end
        if data~=code then send(p,"WrongCode",true) message(p,"Código incorreto.") return end
        codeOpen=true
        local display=exit:FindFirstChild("Display") if display then display.Color=Color3.fromRGB(83,218,134) end
        send(p,"ClosePanel",true) message(p,"Código aceito. Trava eletrônica liberada.") syncAll() tryDoor()
    elseif kind=="Sprint" then h.WalkSpeed=data==true and C.SprintSpeed or C.WalkSpeed
    elseif kind=="Light" then worldFlashlight(p,data==true) end
end)
local lighting=game:GetService("Lighting")
lighting.ClockTime=0 lighting.Brightness=0 lighting.Ambient=Color3.fromRGB(23,27,29)
lighting.OutdoorAmbient=Color3.fromRGB(8,10,13) lighting.EnvironmentDiffuseScale=0.35 lighting.EnvironmentSpecularScale=0.65
lighting.FogColor=Color3.fromRGB(9,13,15) lighting.FogStart=35 lighting.FogEnd=120
local color=Instance.new("ColorCorrectionEffect") color.Name="Setor09Grade" color.Brightness=0 color.Contrast=0.1 color.Saturation=-0.18 color.TintColor=Color3.fromRGB(230,239,228) color.Parent=lighting
local bloom=Instance.new("BloomEffect") bloom.Name="Setor09Bloom" bloom.Intensity=.12 bloom.Size=12 bloom.Threshold=1.7 bloom.Parent=lighting
local accumulator=0
-- Estado compartilhado das travas; inventario individual preservado ao reaparecer.
game:GetService("RunService").Heartbeat:Connect(function(dt)
    accumulator=accumulator+dt if accumulator<0.35 then return end accumulator=0
    for p,s in pairs(state) do
        local _,_,root=living(p)
        if root then
            if not s.escaped and doorOpen and (root.Position-map.EscapeZone.Position).Magnitude<7 then
                s.escaped=true sync(p) send(p,"Win",true)
            end
            if C.EnableScare and not s.scared and (root.Position-map.ScarePoint.Position).Magnitude<9 then
                s.scared=true send(p,"Scare",map.ScarePoint.Position)
            end
        end
    end
end)
print("SETOR 09 pronto. F5 para jogar. F lanterna, E interagir, Shift correr.")
