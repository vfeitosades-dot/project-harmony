local Players=game:GetService("Players")
local RS=game:GetService("ReplicatedStorage")
local Run=game:GetService("RunService")
local Input=game:GetService("UserInputService")
local Tween=game:GetService("TweenService")
local Debris=game:GetService("Debris")
local p=Players.LocalPlayer
local net=RS:WaitForChild("Setor09")
local C=require(net.Config) local V=require(net.Visuals)
local action=net.Action local event=net.Event
local kit=workspace:WaitForChild("Setor09_Kit") local map=kit:WaitForChild("Labirinto")
local s={key=false,crowbar=false,clue=false,boards=3,keyOpen=false,codeOpen=false}
local on=true local modal=false local busyUntil=0 local messageUntil=0 local codeInput=""
local CAS=game:GetService("ContextActionService")
CAS:BindActionAtPriority("Setor09ModalMovement",function()
    return modal and Enum.ContextActionResult.Sink or Enum.ContextActionResult.Pass
end,false,3000,Enum.KeyCode.W,Enum.KeyCode.A,Enum.KeyCode.S,Enum.KeyCode.D,Enum.KeyCode.Space,Enum.KeyCode.LeftShift)
local vm,parts,light,extraLights local focused=false local swayX,swayY=0,0 local scareUntil=0 local pryAt=-10
local gui=Instance.new("ScreenGui") gui.Name="Setor09HUD" gui.IgnoreGuiInset=true gui.ResetOnSpawn=false gui.Parent=p:WaitForChild("PlayerGui")
local ivory=Color3.fromRGB(218,219,195) local amber=Color3.fromRGB(195,151,74)
local function box(parent,size,pos,color,trans)
    local f=Instance.new("Frame") f.Size=size f.Position=pos f.BackgroundColor3=color or Color3.fromRGB(14,19,18)
    f.BackgroundTransparency=trans or 0 f.BorderSizePixel=0 f.Parent=parent return f
end
local function label(parent,value,size,pos,textSize,color)
    local l=Instance.new("TextLabel") l.Text=value l.Size=size l.Position=pos l.BackgroundTransparency=1
    l.Font=Enum.Font.Gotham l.TextSize=textSize or 16 l.TextColor3=color or ivory
    l.TextXAlignment=Enum.TextXAlignment.Left l.TextWrapped=true l.Parent=parent return l
end
local title=label(gui,"S E T O R   0 9   /   II",UDim2.fromOffset(280,35),UDim2.fromOffset(30,24),24)
label(gui,"ALA DE MANUTENÇÃO / SUBSOLO",UDim2.fromOffset(330,20),UDim2.fromOffset(30,61),11,amber)
local tasks=label(gui,"",UDim2.fromOffset(340,118),UDim2.fromOffset(30,100),14)
tasks.TextYAlignment=Enum.TextYAlignment.Top
local inventory=label(gui,"",UDim2.new(1,-60,0,32),UDim2.new(0,30,1,-85),14,amber)
label(gui,"WASD  MOVER      SHIFT  CORRER      F  LANTERNA      BOTÃO DIREITO  FOCAR      E  INTERAGIR      TAB  BILHETE",UDim2.new(1,-60,0,28),UDim2.new(0,30,1,-43),11)
local dot=box(gui,UDim2.fromOffset(3,3),UDim2.new(0.5,-1,0.5,-1),ivory,0.1)
local msg=label(gui,"Encontre uma forma de abrir a saída.",UDim2.new(0.7,0,0,65),UDim2.fromScale(0.15,0.73),18)
msg.TextXAlignment=Enum.TextXAlignment.Center messageUntil=os.clock()+7
local shade=box(gui,UDim2.fromScale(1,1),UDim2.fromScale(0,0),Color3.new(),1) shade.ZIndex=8
-- Bordas graduadas para uma vinheta leve, sem imagem externa.
for _,side in ipairs({"Top","Bottom","Left","Right"}) do
    local horizontal=side=="Top" or side=="Bottom"
    local b=box(gui,horizontal and UDim2.fromScale(1,0.12) or UDim2.fromScale(0.10,1),UDim2.fromScale(side=="Right" and 0.9 or 0,side=="Bottom" and 0.88 or 0),Color3.new(),0.35)
    local gr=Instance.new("UIGradient") gr.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,0.15),NumberSequenceKeypoint.new(1,1)})
    gr.Rotation=side=="Top" and 90 or (side=="Bottom" and -90 or (side=="Left" and 0 or 180)) gr.Parent=b
end
local overlay=box(gui,UDim2.fromScale(1,1),UDim2.fromScale(0,0),Color3.new(),0.28) overlay.ZIndex=20 overlay.Visible=false
local blocker=Instance.new("TextButton") blocker.Size=UDim2.fromScale(1,1) blocker.BackgroundTransparency=1 blocker.Text="" blocker.Modal=true blocker.ZIndex=20 blocker.Parent=overlay
local panel=box(overlay,UDim2.fromOffset(430,510),UDim2.new(0.5,-215,0.5,-255),Color3.fromRGB(20,26,24)) panel.ZIndex=21
local scale=Instance.new("UIScale") scale.Parent=panel
local heading=label(panel,"TRAVA / ACESSO",UDim2.new(1,-40,0,40),UDim2.fromOffset(20,18),23,amber) heading.ZIndex=22
local display=label(panel,"_ _ _",UDim2.new(1,-40,0,90),UDim2.fromOffset(20,65),42) display.TextXAlignment=Enum.TextXAlignment.Center display.ZIndex=22
local note=label(panel,"",UDim2.new(1,-56,0,270),UDim2.fromOffset(28,90),22) note.TextSize=19 note.Size=UDim2.new(1,-56,0,310) note.TextYAlignment=Enum.TextYAlignment.Top note.ZIndex=22 note.Visible=false
local buttons={}
local function button(value,x,y,callback)
    local b=Instance.new("TextButton") b.Size=UDim2.fromOffset(106,54) b.Position=UDim2.fromOffset(x,y)
    b.BackgroundColor3=Color3.fromRGB(39,46,41) b.BorderSizePixel=0 b.Text=value b.Font=Enum.Font.GothamBold b.TextSize=22 b.TextColor3=ivory b.ZIndex=22 b.Parent=panel
    b.Activated:Connect(callback) table.insert(buttons,b) return b
end
local function refreshDisplay() display.Text=codeInput..string.rep("_",3-#codeInput) end
local function enterDigit(d) if #codeInput<3 then codeInput=codeInput..d refreshDisplay() end end
for i=1,9 do local d=tostring(i) button(d,41+((i-1)%3)*121,171+math.floor((i-1)/3)*64,function() enterDigit(d) end) end
button("LIMPAR",41,363,function() codeInput="" refreshDisplay() end).TextSize=14
button("0",162,363,function() enterDigit("0") end)
button("OK",283,363,function() if #codeInput==3 then action:FireServer("Code",codeInput) end end)
local function close() modal=false overlay.Visible=false end
local closeButton=button("FECHAR",41,440,close) closeButton.Size=UDim2.fromOffset(348,44) closeButton.TextSize=14
local interaction=box(gui,UDim2.fromOffset(360,64),UDim2.new(.5,-180,.64,0),Color3.fromRGB(13,20,18),.12)
interaction.Visible=false
local interactionLabel=label(interaction,"",UDim2.new(1,-28,0,38),UDim2.fromOffset(14,4),14)
interactionLabel.TextXAlignment=Enum.TextXAlignment.Center
local track=box(interaction,UDim2.new(1,-28,0,3),UDim2.fromOffset(14,49),Color3.fromRGB(45,56,48))
local fill=box(track,UDim2.fromScale(0,1),UDim2.fromScale(0,0),amber)
local currentPrompt=nil local holdStarted=nil
local introSeen=false
local fixtureLights={}
for _,v in ipairs(map.Fixtures:GetDescendants()) do
    if v:IsA("PointLight") and v.Parent.Name=="LampLens" then
        table.insert(fixtureLights,{light=v,brightness=v.Brightness,phase=#fixtureLights*1.71})
    end
end
local PPS=game:GetService("ProximityPromptService")
PPS.PromptShown:Connect(function(pr)
    currentPrompt=pr holdStarted=nil interaction.Visible=not modal
    interactionLabel.Text="[ E ]  "..pr.ActionText.."  /  "..pr.ObjectText
end)
PPS.PromptHidden:Connect(function(pr) if currentPrompt==pr then currentPrompt=nil holdStarted=nil interaction.Visible=false end end)
PPS.PromptButtonHoldBegan:Connect(function(pr) if pr==currentPrompt then holdStarted=os.clock() end end)
PPS.PromptButtonHoldEnded:Connect(function(pr) if pr==currentPrompt then holdStarted=nil end end)
local panelMode=""
local function open(mode)
    modal=true panelMode=mode overlay.Visible=true codeInput="" refreshDisplay()
    for _,b in ipairs(buttons) do b.Visible=mode=="Keypad" or b==closeButton end
    display.Visible=mode=="Keypad" note.Visible=mode~="Keypad"
    heading.Text=mode=="Keypad" and "TRAVA / 3 DÍGITOS" or (mode=="Win" and "VOCÊ SAIU" or (mode=="Intro" and "SETOR 09 / SUBSOLO" or "REGISTRO / 09"))
    closeButton.Text=mode=="Intro" and "ENTRAR NO SETOR" or "FECHAR"
    focused=false
    action:FireServer("Sprint",false)
    if mode=="Note" then
        note.Text="Se alguém encontrar isto:\n\nA combinação do portão é\n\n"..(s.code or "???").."\n\nA chave e a ferramenta ficaram em outros corredores. Não fique aqui."
    elseif mode=="Intro" then note.Text="A manutenção abandonou este lugar.\n\nO portão ainda tem três travas.\n\nAche o registro, a chave de serviço e uma ferramenta para as tábuas.\n\nF: lanterna   /   E: interagir\nBotão direito: concentrar o feixe"
    elseif mode=="Win" then note.Text="As três travas cederam.\n\nVocê escapou do Setor 09.\n\nMas o que estava lá embaixo continua lá."
    end
end
local function audio(id,loop)
    if not id or id=="" then return end
    local a=Instance.new("Sound") a.SoundId=id a.Volume=0.35 a.Looped=loop or false a.Parent=game:GetService("SoundService") a:Play()
    if not loop then Debris:AddItem(a,6) end
end
local function build()
    if vm then vm:Destroy() end
    vm,parts,light,extraLights=V.Flashlight(workspace.CurrentCamera)
    light.Range=C.FlashlightRange light.Angle=C.FlashlightAngle light.Brightness=C.FlashlightBrightness light.Enabled=on
    extraLights[1].Range=C.FlashlightSpillRange extraLights[1].Angle=C.FlashlightSpillAngle extraLights[1].Brightness=C.FlashlightSpillBrightness
end
local function toggle()
    on=not on if light then light.Enabled=on end action:FireServer("Light",on) audio(C.FlashlightSound)
end
local function hidePickup(name)
    local m=map:FindFirstChild(name) if not m then return end
    for _,v in ipairs(m:GetDescendants()) do
        if v:IsA("BasePart") and not v.Name:match("^Table") and not v.Name:match("^Bench") then v.LocalTransparencyModifier=1 end
        if v:IsA("ProximityPrompt") then v.Enabled=false end
    end
end
event.OnClientEvent:Connect(function(kind,data)
    if kind=="State" then s=data if s.key then hidePickup("Key") end if s.crowbar then hidePickup("Crowbar") end
    elseif kind=="Message" then msg.Text=data messageUntil=os.clock()+4
    elseif kind=="Pickup" then hidePickup(data) audio(C.PickupSound)
    elseif kind=="Note" then s.code=data open("Note")
    elseif kind=="Keypad" then open("Keypad")
    elseif kind=="ClosePanel" then close()
    elseif kind=="WrongCode" then codeInput="" refreshDisplay() display.TextColor3=Color3.fromRGB(222,92,76) task.delay(0.5,function() display.TextColor3=ivory end)
    elseif kind=="DoorOpened" then audio(C.DoorSound)
    elseif kind=="Pry" then pryAt=os.clock() audio(C.PrySound)
    elseif kind=="Win" then open("Win")
    elseif kind=="Scare" then
        scareUntil=os.clock()+1.15 audio(C.ScareSound)
        msg.Text="... você ouviu isso?" messageUntil=os.clock()+4
    end
end)
Input.InputBegan:Connect(function(i,processed)
    if processed then return end
    if modal then
        if i.KeyCode==Enum.KeyCode.Escape or i.KeyCode==Enum.KeyCode.Tab then close() return end
        if panelMode=="Keypad" then
            local names={Zero="0",One="1",Two="2",Three="3",Four="4",Five="5",Six="6",Seven="7",Eight="8",Nine="9",KeypadZero="0",KeypadOne="1",KeypadTwo="2",KeypadThree="3",KeypadFour="4",KeypadFive="5",KeypadSix="6",KeypadSeven="7",KeypadEight="8",KeypadNine="9"}
            if names[i.KeyCode.Name] then enterDigit(names[i.KeyCode.Name]) end
            if i.KeyCode==Enum.KeyCode.Backspace then codeInput=codeInput:sub(1,-2) refreshDisplay() end
            if i.KeyCode==Enum.KeyCode.Return and #codeInput==3 then action:FireServer("Code",codeInput) end
        end
        return
    end
    if i.UserInputType==Enum.UserInputType.MouseButton2 then focused=true
    elseif i.KeyCode==Enum.KeyCode.F then toggle()
    elseif i.KeyCode==Enum.KeyCode.Tab and s.clue then open("Note")
    elseif i.KeyCode==Enum.KeyCode.LeftShift then action:FireServer("Sprint",true) end
end)
Input.InputEnded:Connect(function(i) if i.UserInputType==Enum.UserInputType.MouseButton2 then focused=false end if i.KeyCode==Enum.KeyCode.LeftShift then action:FireServer("Sprint",false) end end)
Input.WindowFocusReleased:Connect(function() focused=false action:FireServer("Sprint",false) end)
local function character(char)
    close() p.CameraMode=Enum.CameraMode.LockFirstPerson
    local h=char:WaitForChild("Humanoid",10)
    if h then workspace.CurrentCamera.CameraSubject=h end
    task.wait(0.3) action:FireServer("Sync") task.wait(0.12) action:FireServer("Light",on)
    if not introSeen then introSeen=true open("Intro") end
end
p.CharacterAdded:Connect(character)
if p.Character then task.spawn(character,p.Character) end
p.CameraMode=Enum.CameraMode.LockFirstPerson
build() audio(C.AmbientSound,true)
action:FireServer("Sync")
-- O feixe segue a camera; braco e lanterna oscilam de forma sutil.
Run:BindToRenderStep("Setor09",Enum.RenderPriority.Camera.Value+3,function(dt)
    dt=math.min(dt,0.05)
    local cam=workspace.CurrentCamera if not cam then return end
    if not vm or vm.Parent~=cam then build() end
    local char=p.Character local h=char and char:FindFirstChildOfClass("Humanoid")
    local root=char and char:FindFirstChild("HumanoidRootPart")
    local alive=h~=nil and h.Health>0
    Input.MouseBehavior=(modal or not alive) and Enum.MouseBehavior.Default or Enum.MouseBehavior.LockCenter
    Input.MouseIconEnabled=modal or not alive dot.Visible=not modal and alive
    local moving=root and Vector3.new(root.AssemblyLinearVelocity.X,0,root.AssemblyLinearVelocity.Z).Magnitude or 0
    local now=os.clock() local md=Input:GetMouseDelta() local a=1-math.exp(-dt*9)
    swayX=swayX+(math.clamp(md.X,-20,20)*0.0015*(C.CameraSway or 1)-swayX)*a
    swayY=swayY+(math.clamp(md.Y,-20,20)*0.0015*(C.CameraSway or 1)-swayY)*a
    local bob=math.sin(now*7)*0.025*(C.CameraBob or 1)*math.min(1,moving/11)*(focused and .3 or 1)
    local pry=math.max(0,1-(now-pryAt)/0.7)
    local cf=cam.CFrame*CFrame.new(focused and .38 or .46,-0.40+bob,focused and -.90 or -.75)*CFrame.Angles(-swayY,-swayX,math.rad(pry*18))
    if modal or not alive then cf=cf*CFrame.new(0,-100,0) end
    V.Pose(parts,cf)
    -- Luz nasce junto a camera para nao atravessar a parede com a ponta do modelo.
    local emitter=light.Parent
    emitter.CFrame=cam.CFrame*CFrame.new(0,-.04,-.14)
    local scare=now<scareUntil
    light.Enabled=on and alive and not modal and not (scare and math.floor(now*9)%2==0)
    for _,l in ipairs(extraLights or {}) do l.Enabled=light.Enabled end
    light.Brightness=focused and 10 or C.FlashlightBrightness
    light.Angle=focused and 30 or C.FlashlightAngle
    if extraLights then extraLights[1].Brightness=focused and .8 or C.FlashlightSpillBrightness end
    -- Evita uma segunda luz local emitida pela cabeca.
    local head=char and char:FindFirstChild("Head") local worldLight=head and head:FindFirstChild("Setor09WorldLight")
    if worldLight then worldLight.Enabled=false end
    shade.BackgroundTransparency=scare and 0.30 or 1
    for _,v in ipairs(fixtureLights) do
        v.light.Brightness=v.brightness*(scare and .35 or (.94+.06*math.sin(now*3.8+v.phase)))
    end
    local wantedFov=focused and 67 or ((moving>12 and not modal) and 74 or 70)
    cam.FieldOfView=cam.FieldOfView+(wantedFov-cam.FieldOfView)*a
    local function check(v) return v and "[OK] " or "[  ] " end
    tasks.Text=check(s.clue).."Encontrar código de 3 números\n"..check(s.codeOpen).."Liberar teclado\n"..check(s.keyOpen).."Destrancar com a chave\n"..check(s.boards==0).."Remover tábuas ("..(3-(s.boards or 3)).."/3)"
    if s.doorOpen then tasks.Text="[OK] SISTEMAS LIBERADOS\nATRAVESSE A SAÍDA" end
    inventory.Text="LANTERNA "..(on and (focused and "FOCO" or "LIGADA") or "DESLIGADA").."    |    CHAVE "..(s.key and "SIM" or "—").."    |    PÉ DE CABRA "..(s.crowbar and "SIM" or "—")
    msg.Visible=now<messageUntil and not modal
    interaction.Visible=currentPrompt~=nil and not modal and alive
    local fraction=holdStarted and currentPrompt and math.clamp((now-holdStarted)/math.max(.01,currentPrompt.HoldDuration),0,1) or 0
    fill.Size=UDim2.fromScale(fraction,1)
    if currentPrompt and not alive then currentPrompt=nil end
    scale.Scale=math.min(1,(cam.ViewportSize.X-30)/430,(cam.ViewportSize.Y-30)/510)
    panel.Position=UDim2.new(0.5,-215*scale.Scale,0.5,-255*scale.Scale)
end)
